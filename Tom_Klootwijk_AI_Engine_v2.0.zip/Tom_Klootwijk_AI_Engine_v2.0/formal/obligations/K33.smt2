; K33: Origin reflection does not alter a scalar occupancy value
; Manuscript: L3. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const f Real)
(declare-const fr Real)
(assert (not (=> (= f fr) (= (<= f 0) (<= fr 0)))))
(check-sat)
(get-proof)
