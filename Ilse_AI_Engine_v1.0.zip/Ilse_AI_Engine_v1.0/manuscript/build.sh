#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v pdflatex >/dev/null || { echo "A LaTeX distribution with pdflatex is required." >&2; exit 1; }
mkdir -p .build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build Ilse_AI_Engine.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build Ilse_AI_Engine.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build Ilse_AI_Engine.tex
cp .build/Ilse_AI_Engine.pdf ../Ilse_AI_Engine.pdf
