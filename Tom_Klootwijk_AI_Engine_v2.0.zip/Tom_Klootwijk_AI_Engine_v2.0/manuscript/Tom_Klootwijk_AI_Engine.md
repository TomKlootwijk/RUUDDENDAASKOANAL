# Tom Klootwijk AI Engine
## Unified Seed–Field Theorem and Theory of Consciousness

**Author: Tom Klootwijk**  
**NL200678942 · 10-07-1990**  
Version 2.0.0 · 11 September 2026

> Editable reading edition. The LaTeX/PDF version controls typography and equation numbering. This private author-attributed research manuscript includes the personal details supplied by the requester.

# Abstract and author statement {#abstract-and-author-statement .unnumbered}

This author edition reunifies the supplied seed--field manuscript, its intermediate theorem-and-kernel revision, the double-arc addendum, the original conversation notes, and the new eighteen-page corpus. The engine is attributed to **Tom Klootwijk**, with the supplied identifier **NL200678942** and date string **10-07-1990**. The earlier alternate perspective designation is not the authorship of this edition. Attribution records the user's requested author designation; it is not independent identity verification, a priority determination or a claim that the underlying standard mathematics was invented here.

The resulting Klootwijk Seed--Field Engine (KSFE), continuing the corpus's Klootwijk Seed--Field Framework (KSFF), has one unified composition theorem and twelve supporting lemmas. The master theorem establishes deterministic finite replay, correct geometric set membership, nonnegative conserved chemical mass under declared closed-system assumptions, bounded recurrent and memory states, and an exact integer one-bit prefix certificate. A conditional frame-covariance clause and explicit limits on semantic inference prevent changes of representation from being mistaken for discoveries about physical reality.

The new corpus's reaction--diffusion, molecular "sieve", growth feedback and infinite-axis language are given distinct mathematical roles. The ambient space is not created by local distance fields. A vector field is an ambient geometric object; a log-polar chart is a coordinate representation; a signed boundary field selects a local material region; and a finite graph supplies a computable approximation. A conservative remapping operator accounts for mass when the represented region changes. Reversible two-species conversion is implemented as a minimal reaction law, not as a genome or a model of actual cellular chemistry.

The supplied narrative contains inconsistent event-time formulas and unsupported assertions about genetic editing, geometric chirality, quantum behavior and consciousness. These are retained in a page-specific source audit, rather than silently rewritten as established facts. Both actual angular variants of the toy polynomial are implemented. A limited external primary-source check is distinguished from source-derived content. No human data, neural recordings, biological experiments or hardware measurements are supplied or invented.

The package includes editable manuscript sources, the numerical kernel, seed files, tests, solver obligations and logs, numerical results, original input sources, provenance records and checksums. **99 regression tests pass; 34 algebraic counterexample queries return UNSAT in Z3.** These are checks of declared program examples and mathematical fragments. The full theorem is supported by a written proof, not a complete proof-assistant verification of every Python execution.

**Research hypothesis:** history-dependent coupling among generated boundaries, material processes, modality-specific observations, recurrent internal activity and memory may explain aspects of conscious organization. The theorem establishes properties of the proposed model. It does not establish that the model is conscious, that its variables are sufficient for consciousness, or that a scalar distance field is identical to bodily, digital or spiritual reality.

**Reading key.** [**\[S\]**]  source account; [**\[D\]**]  definition or explicit modeling choice; [**\[T\]**]  proved mathematical consequence under assumptions; [**\[H\]**]  empirical hypothesis; [**\[I\]**]  interpretation; [**\[U\]**]  unsupported by the supplied evidence; [**\[E\]**]  separately identified external context.

**Suggested route.** Sections 2--5 define the objects. Section 6 states the unified theorem. Section 7 gives its supporting proofs. Sections 8--10 explain consciousness scope, executed verification and tests that could challenge the theory. Appendix A resolves source claims without treating conversational assertions as observations.

# Corpus, continuity and the revised claim

## The five-source record

\@lY@ Record & Role in this edition\
C0 & Original supplied Markdown conversation: the SDF/operator chain, log-polar lookup, parity, IPD/ITD, photonic proposals, cell and memory analogies.\
C1 & Original 28-page seed--field research manuscript: complete seeds, L-systems, metric distinctions, event-time normalization and empirical limits.\
C2 & Twelve-page double-arc addendum: paired arcs, shared baseline, clipping, hinge, coordinate lookup and perceptual narratives.\
C3 & Intermediate 25-page theorem-and-kernel revision: symbolic $XX/XY$ seeds, eighteen component theorems, geometry utilities, recurrence and verification infrastructure.\
C4 & New eighteen-page author-named corpus: word operators, paired curves, reaction--diffusion, membranes, remeshing, closed-system claims and ambient infinite axes.\

C0, C1, C2 and C4 are archived as source records. C3's supplied PDF and ZIP are hash-referenced in the provenance manifest; their earlier author-facing branding is not reissued as the current manuscript. Selected numerical routines and tests are adapted from C3 and re-executed here. Earlier reported test counts or solver outcomes are not treated as new verification results. References to opaque file aliases inside C4 are not assumed to be independently accessible documents.

## Preserving the corpus's conceptual progression

[**\[S\]**]  C4 starts with "parings", then paired S-curves, $S$, $T$, a double mirrored arch and competing DNA, cryptographic and scanning-tunneling interpretations (pp. 1--7). It links this to KSFF, L-system words and capsule fields (pp. 7--9), then to chiral symbols and narrative interpretation (pp. 9--12). It introduces fertilization and $XX/XY$ language (p. 12), develops reaction--diffusion and masked Laplacians (pp. 13--15), and finally discusses genetic editing, membranes, conservation, ambient vectors and log-radius infinity (pp. 15--18).

This progression is the basis of the present formalization. Its individual statements have different evidential status. The assistant responses reproduced in the corpus are not experiments, and repeated agreement is not a proof. In particular, a source reference to the earlier engine does not establish that the referenced engine already implemented the later reaction--diffusion claims.

[**\[D\]**]  This edition preserves the pipeline while introducing the missing contracts: the alphabet and interpreter; a geometric metric; the field's sign convention; control-volume closure; transport and reaction laws; a positive numerical step; conservative mass transfer under changed geometry; a bounded memory update; and a distinction between analog input, dyadic input, pulse output and parity metadata. Each added choice is visible in the configuration or versioned code.

## What is unified, and what is not identified

The unification is compositional: different mathematical objects have compatible input and output types. A word is not a concentration. A concentration is not a distance. An orientation determinant is not a parity checksum. A genome is not the two-character label $XY$, and a personal identifier is not a numerical seed.

The proposed consciousness account uses the whole history-dependent loop as an explanatory unit. It is not the proposition that one arc, one bit, one membrane crossing or one matrix transform independently explains subjective experience. A theory can be mathematically precise while its physical interpretation remains a hypothesis.

# The complete seed and its word operators

## A reproducible seed specification

[**\[D\]**]  Let a complete seed be $$\Sigma=(\mathcal A,p,w_0,P,\mathcal I,\Theta,\mathcal G,\mathcal Q,\mathcal R,
\mu_0,z_0,m_0,\mathcal E,\mathcal C,\mathcal V,\mathcal B).$$ Here $\mathcal A$ is the alphabet, $p$ the ordered pair, $w_0$ the axiom, $P$ the parallel grammar and $\mathcal I$ its interpreter. $\Theta$ specifies geometric and chart parameters; $\mathcal G$ specifies the grid and domain-change rule; $\mathcal Q$ specifies transport and gates; $\mathcal R$ specifies reactions. The initial chemical mass is $\mu_0$, the fast state is $z_0$, and memory is $m_0$. $\mathcal E$ records the input/probe law and pseudorandom convention, $\mathcal C$ the coding convention, $\mathcal V$ implementation and arithmetic versions, and $\mathcal B$ finite budgets.

A random integer alone does not specify this object. The archive includes complete default parameter files and realized-matrix fingerprints. A checksum identifies a byte sequence; it does not establish scientific truth or cryptographic security of an output channel. The author name, identifier and date are documentary fields and do not alter the numerical model.

## Symbolic pairings and growth

[**\[D\]**]  Use $\mathcal A=\{X,Y,+,-,[,]\}$ with $$P(X)=X[+X]Y,\qquad P(Y)=Y[-Y]X,$$ and identity productions on brackets and turns. For $p=(a,b)\in\{X,Y\}^2$ set $$w_0(p)=[a][b],\qquad w_g=P^g(w_0).$$ Every production at a generation is applied to the old word in parallel. It is not repeated substitution into newly generated symbols during the same generation. This is a stipulated grammar inherited from C3, not a DNA sequence or a law of human development. Parallel rewriting and turtle interpretation are standard L-system constructions; that outside mathematical context does not validate this grammar biologically. [\[C3, Sec. 2; E1\]]

Both $X$ and $Y$ emit a forward segment. The $+$ and $-$ tokens turn by $\pm\delta$. A bracket saves or restores pose; the step at stack depth $d$ is $\ell\beta^d$. The complete default interpreter uses $\ell=0.12$, $\delta=\pi/7$, $\beta=0.72$, upward initial heading and the embedding $(x,y)\mapsto(x,y+0.10)$. The v2 embedding scale is explicitly $1.0$, rather than silently inheriting the smaller intermediate demonstrator scale.

Define $e(X)=0$, $e(Y)=1$, $q(a,b)=e(a)\oplus e(b)$, and $\kappa(a,b)$ as the sorted pair. The ordered records $XY$ and $YX$ remain different seeds even though their canonical pair and parity coincide. The optional mixing function draws one token from each pair under four equally weighted draws. It is a symbolic sampling law; it does not model fertilization or infer a person's characteristics.

## The meaning of "all words as SDF operators"

[**\[S\]**]  C4, pp. 8--9, asks whether the L-system operator is the set of operators of all words as SDF notation. The mathematically supported connection is a composition of maps, not an identity of those objects: $$\mathcal A^* \xrightarrow{P} \mathcal A^*
\xrightarrow{\mathcal I_{\Theta}} \mathsf{Geometry}
\xrightarrow{\mathcal D} \mathsf{BoundaryFields}.$$ $\mathcal A^*$ is the set of finite words. The rewrite operator $P$ acts on words. Each interpreted token acts on a turtle state with pose, stack and emitted primitives. If $\tau_w$ denotes that state transformation, then $$\tau_{uv}=\tau_v\circ\tau_u$$ where both sides are defined. The interpreter has a domain condition: unmatched brackets or unknown tokens are invalid. Concatenation preserves state-transform composition; it is not generally addition, minimum or multiplication of scalar distance functions.

The generated field family is $$\mathcal F_{\Sigma}=\{\mathcal D(\mathcal I_{\Theta}(P^g(w_0))):g\leq g_{\max}\}.$$ It is a specified family, not the class of all possible SDFs, words, organisms or conscious states. Distinct words may emit overlapping geometry. Distinct seeds can consequently have the same sampled mask or output, as the included initial $XX/XY$ example demonstrates.

![The declared $XX$ grammar at generation four. The zero contour bounds the union of the two arc strokes, baseline and interpreted capsules after ground clipping. This is simulated geometry, not a chromosome, neural structure or recorded biological growth.](figures/geometry_xx.png)

# Ambient space, local fields and coordinate hinges

## Infinite axes without eliminating coordinates

[**\[D\]**]  A coordinate-independent starting point is a Riemannian manifold $(M,g)$ with vector field $v_t\in\Gamma(TM)$. The reference implementation uses the unbounded Euclidean ambient space $M=\mathbb{R}^2$ and its ordinary metric. Local geometry may select a material region $\Omega_t\subset M$ without creating $M$ or creating its vector field. This preserves the final emphasis of C4, pp. 17--18: local hinges and boundaries are not the whole ambient space.

A vector field assigns a tangent vector to each relevant point. It is not itself an axis. An axis is a chosen direction or a coordinate line; an eigenvector additionally requires a specified operator $A$ and a relation $Av=\lambda v$. A direction does not become an eigenvector solely by being used for sound localization. No physical attenuation law follows from the eigenvalue of an unspecified frame matrix.

The numerical model uses a finite window $B\subset M$ and a grid in that window. The field and ambient velocity law have mathematical definitions outside it, but the software does not represent infinitely many coordinates or infinite resolution. The requested "infinity as axis" is retained as ambient domain and limiting behavior, not as an assertion that finite memory computes an infinite object exactly.

## Capsule and double-arc boundary fields

For a segment from $a_j$ to $b_j$ with radius $r_j>0$, define $$\begin{aligned}
\lambda_j(x)&=\operatorname{clamp}_{[0,1]}
\frac{(x-a_j)\cdot(b_j-a_j)}{\left\lVert b_j-a_j\right\rVert^2},\\
d_j(x)&=\left\lVert x-a_j-\lambda_j(x)(b_j-a_j)\right\rVert-r_j.
\end{aligned}$$ When $a_j=b_j$, use $d_j(x)=\left\lVert x-a_j\right\rVert-r_j$. The nondegenerate expression is the signed distance of a capsule. The composite $$F_G(x)=\min_j d_j(x),\qquad \Omega_G=\{x:F_G(x)\leq0\}$$ represents the exact union membership. Its negative values need not be exact distances to the boundary of an overlapping union. This distinction, already present in the revised manuscripts, must not be erased by C4's repeated use of "exact SDF" for the entire composite. [\[C1; C3; C4, pp. 9, 13--14\]]

For the addendum's arches, use centerline $$A=\{R(\sin\theta,\cos\theta):|\theta|\leq\alpha\},\quad
A_{\pm}=A\pm(h,0),\quad 0<\alpha\leq\pi/2.$$ Let $B_0$ be the horizontal segment from $(-h-R,0)$ to $(h+R,0)$. Using unsigned centerline distances $d_A,d_{B_0}$, the clipped stroke field is $$F_M(x)=\max\{\min[d_{A_-}(x)-r,\ d_{A_+}(x)-r,
 d_{B_0}(x)-r],-y\}.$$ The default combined engine field is $$F_{g,m}(x)=\max\{\min[F_M(x;m),F_{G_g}(x)],-y\},\qquad
r(m)=r_*+\gamma\tanh(m_1),\quad r_*>|\gamma|.$$ The finite word and fixed memory state determine this field. The half-space uses the convention "inside at zero". It clips to $y\geq0$; it does not by itself create a Klein bottle or a physical membrane.

The addendum's coordinate fold $x\mapsto |x|-h$ is not used as an unconditional replacement for an explicit union. It is valid under a suitable lateral-containment condition, such as $h\geq R\sin\alpha$. Outside that regime the nearest branch can be the apparently farther arc. The code retains the fold only as a comparison routine and tests a counterexample. [\[C2, pp. 1--3; C3, T7\]]

## Reflection, chirality and sign are different operations

Let $J=\operatorname{diag}(-1,1)$ and let $R_\theta$ be the usual planar rotation. Then $J^2=I$, $\det J=-1$, $\det R_\theta=1$, and $$JR_\theta J=R_{-\theta}.$$ These identities formalize the paired rotor language as geometry. For a reflected set $J\Omega$, its distance field obeys $d_{J\Omega}(Jx)=d_\Omega(x)$: reflection does not change inside into outside. A symmetric double-arc field satisfies $F_M(Jx)=F_M(x)$, so its occupancy bit is preserved rather than flipped.

The field sign, orientation sign, geometric set difference and payload parity therefore require separate variables. A $45$-degree rotation is still an isometry. C4's claims that historical symbolism or such a rotation mathematically forces constructive or destructive dynamics are not consequences of these equations. This is a limitation of the geometric inference, not a historical theory. [\[C4, pp. 9--11\]]

The circle centers $(\pm h,0)$ satisfy intersecting-circle equations $x=0$, $y^2=R^2-h^2$. When $h=R$, their tangency point is $(0,0)$, not $(0,R)$. A tangent contact or a nondifferentiable minimum need not be a sign-changing crossing, a quantum event or a topological singularity. The addendum's hinge diagram and its stated coordinate are audited separately. [\[C2, pp. 8--9\]]

## The logarithmic radial axis and its metric

For reference length $r_0>0$, the log-polar representation of the punctured plane is $$\rho=\log(r/r_0),\quad \theta\in S^1,\qquad
x=r_0e^\rho(\cos\theta,\sin\theta).$$ Thus $\rho\in\mathbb{R}$ corresponds to $r\in(0,\infty)$; $r\downarrow0$ means $\rho\to-\infty$, and $r\to\infty$ means $\rho\to\infty$. The origin is not a finite coordinate of this chart. The angular seam is a representation choice; $S^1$ is not an interval with unrelated endpoints.

The Euclidean metric pulls back to $$ds^2=r_0^2e^{2\rho}(d\rho^2+d\theta^2).$$ Consequently, a Euclidean distance field evaluated through the inverse chart is a scalar field with the same membership semantics; it is not generally an exact distance in the flat $(\rho,\theta)$ metric. Coordinate compression does not prove perceptual calibration, physical time dilation or infinite near-origin numerical detail.

The optional lookup table stores sampled Cartesian field values on a finite annulus. For a 1-Lipschitz field and convex bilinear weights $w_j$, its query error is bounded by $$\left|\sum_jw_jF(p_j)-F(p)\right|
\leq\sum_jw_j\left\lVert p_j-p\right\rVert\leq\max_j\left\lVert p_j-p\right\rVert.$$ The numerical kernel rejects queries outside the chart domain. It does not replace an origin singularity with an unannounced epsilon and call the result an exact chart. A Klein-bottle quotient would need explicit identifications and metric compatibility; it is not implemented in the present engine.

# Paired time roots: preserving both corpus variants

## The polynomial actually determines the roots

[**\[S\]**]  C0 and the original normalized event example use $\sin^2\theta$ in the second factor. C4, p. 8, prints $\sin^2(\theta/2)$ in that factor but gives a root with denominator $\sin\theta$. C4, p. 6, also reproduces earlier differently scaled exponential envelopes. These are not one consistent equation.

[**\[D\]**]  Preserve the two explicit polynomial variants as $$\label{eq:toy}
F_\kappa(\rho,\theta)=
\left[\rho^2-\cos^2(\theta/2)\right]
\left[\rho^2\sin^2(\kappa\theta)-\phi_-^2\right],
\quad \kappa\in\{1,\tfrac12\},$$ where $\phi_-=(\sqrt5-1)/2$ is dimensionless. $F_\kappa$ is an auxiliary implicit polynomial, not the capsule-union SDF $F_G$, not an established Klein-bottle equation, and not an experimentally determined biological surface.

For a fixed angle and $\sin(\kappa\theta_0)\ne0$, the algebraic radial roots are $$\rho_{1,\pm}=\pm\cos(\theta_0/2),\qquad
\rho_{2,\pm}=\pm\frac{\phi_-}{\sin(\kappa\theta_0)}.$$ These are sets of candidate roots with multiplicities; coincidences need not yield four distinct events. At exact $\sin(\kappa\theta_0)=0$, the second factor is the nonzero constant $-\phi_-^2$, and its finite roots are absent.

## Dimensionally consistent event time

Declare a radial path $r(t)=c_s(t-t_0)>0$, with $c_s$ in length/time and $r_0$ in length. Substitution gives $$\label{eq:times}
T_{j,\pm}=t_0+\frac{r_0}{c_s}\exp(\rho_{j,\pm}).$$ The exponent is dimensionless. A factor with dimensions of inverse speed cannot be inserted into the exponent unless an additional normalization has been explicitly defined. The reciprocal symmetry is in normalized delay: $$\tau_{j,\pm}=\frac{c_s(T_{j,\pm}-t_0)}{r_0},\qquad
\tau_{j,+}\tau_{j,-}=1.$$ Thus the branches mirror in log time; they are not automatically reflected across an ordinary linear time baseline. The "double mirrored arch" phrase can describe this representation, but does not make a DNA helix, membrane crossing or all physical time an immutable geometric arch.

The root API retains log-delay when exponentiation overflows or underflows. It distinguishes an exact zero denominator from a near-singular unresolved denominator. For general moving fields, solve $f(t)=F(x(t),t)=0$ with a justified bracket or another specified method. Bisection bounds the error after $n$ halvings by the retained half-width; sign sampling alone does not find all tangencies. Where derivatives exist, $$\frac{d}{dt}F(x(t),t)=\nabla_xF\cdot\dot x+\partial_tF.$$ No zero-latency hardware event follows from a mathematical root. The reference growth trigger is a sampled concentration predicate; the auxiliary polynomial roots are diagnostic queries and are not silently used as fertilization times or growth laws.

# Reaction, diffusion and the membrane-like graph

## The continuous template and its closure assumptions

[**\[S\]**]  C4, pp. 13--14, proposes an L-system-generated spatial region carrying reaction--diffusion with advection: $$\label{eq:pde}
\partial_t c_k+\nabla\cdot(c_kv)=D_k\Delta c_k+\mathcal R_k(c).$$ [**\[D\]**]  This equation needs a domain, initial state, reaction law, flux convention, units and boundary motion. A specified geometry alone does not determine those quantities. Write material flux $J_k=c_kv-D_k\nabla c_k$. For a fixed closed domain, require $J_k\cdot n=0$. With advection present, $\nabla c_k\cdot n=0$ alone is not enough unless the normal advective flux also vanishes.

For a moving boundary with velocity $w$, the no-transfer condition relative to that boundary is $(J_k-c_kw)\cdot n=0$. Reynolds transport then gives, for conserved weights $\ell_k$, $$\frac{d}{dt}\int_{\Omega(t)}\sum_k\ell_k c_k\,dx
=\int_{\Omega(t)}\sum_k\ell_k\mathcal R_k(c)\,dx
-\int_{\partial\Omega(t)}\sum_k\ell_k(J_k-c_kw)\cdot n\,dS.$$ Conservation follows only after the right-hand side is controlled. An open membrane, external feeding or a nonconservative reaction gives an explicit source term instead. This is a declared model boundary condition, not a proof that the universe or a living organism is a closed system. [\[C4, pp. 16--17\]]

## Finite masked diffusion without invented smooth normals

Let $V_h$ be grid nodes within the simulation window, $h$ the spacing, and $$I_n=\{i\in V_h:F_{g_n,m_n}(x_i)\leq0\}$$ the active mask used at that update. For undirected active-neighbor conductances $w_{ij}=w_{ji}\geq0$, define $$(L_hc)_i=\sum_{j\sim i}w_{ij}(c_j-c_i).$$ With $w_{ij}=1/h^2$, a node with four interior neighbors has the standard five-point stencil. Removing exterior edges changes the diagonal from $-4/h^2$ to minus the sum of the retained weights. This is the precise finite counterpart of the corpus's "return the removed coefficient to the diagonal" instruction.

It yields zero graph flux across absent edges, exact row and column sums of zero in real arithmetic, and no need to evaluate $\nabla F/\left\lVert \nabla F\right\rVert$. The latter expression can fail at ties, corners or zero gradients of a composite field. A staircase graph boundary is not the exact curved-boundary Neumann problem, and no continuum convergence rate is asserted without a separate analysis.

## Ambient swirl, gates and directed transport

The implemented ambient field is the illustrative law $$v(x,y)=\omega(-y,x),\qquad (x,y)\in\mathbb{R}^2.$$ It exists independently of $I_n$. At an edge $i\to j$, use the upwind rate $$a_{i\to j}=g_{ij}\left[\frac{D}{h^2}+
\max\left(\frac{v((x_i+x_j)/2)\cdot(x_j-x_i)}{h^2},0\right)\right].$$ The interface gate $g_{ij}\in[0,1]$ multiplies rates on edges crossing $x=0$; elsewhere it is one. In the default feedback law, $$g_{ij}=g_*+\gamma_g\tanh(m_2),\quad
0\leq g_*-|\gamma_g|\leq g_*+|\gamma_g|\leq1.$$ This is a formal permeability-like control, not a physical identification of a molecular valve with a vortex. The corpus does not supply the molecular variables or measurements needed for that identity.

Use a column generator $Q$ on node masses: $Q_{ji}=a_{i\to j}$, $Q_{ii}=-\sum_{j\ne i}a_{i\to j}$. Thus off-diagonal entries are nonnegative and $\mathbf{1}^TQ=0$. Suppressing exterior edges is a declared closed graph boundary. In a general directed graph, a uniform concentration need not remain uniform even though total mass is conserved; this must not be confused with the symmetric diffusion-only case.

## Positive transport, reactions and domain changes

Let $\mu_i=V_i c_i$ be represented mass; the reference grid uses equal areas $V_i=h^2$. For a substep $\delta t$ satisfying $$\delta t\max_i(-Q_{ii})\leq1,$$ $P_Q=I+\delta t Q$ is nonnegative and column-stochastic. The implementation substeps to a stricter target of $0.9$. It applies the nonnegative sparse transition matrix directly and does not conceal a negative concentration by clipping it to zero.

The reference reaction is reversible conversion $U\rightleftarrows V$ with rates $a,b\geq0$ and equal conserved simulation-mass units: $$\begin{pmatrix}u'\\v'\end{pmatrix}
=\begin{pmatrix}1-\delta t a&\delta t b\\
\delta t a&1-\delta t b\end{pmatrix}
\begin{pmatrix}u\\v\end{pmatrix},\qquad
\delta t\max(a,b)\leq1.$$ This local matrix is also column-stochastic. Other reactions require new positivity, stoichiometry and balance conditions; periodic-table language alone does not specify them.

If memory or growth changes the domain, old mass must not simply be discarded. Define a remap $\Pi_n$ from old active nodes to new active nodes with $$(\Pi_n)_{ij}\geq0,\qquad \mathbf{1}^T\Pi_n=\mathbf{1}^T.$$ For unequal cell volumes the concentration rule is $c'=V_{n+1}^{-1}\Pi_nV_nc$. The reference rule keeps mass on retained nodes and transfers removed-node mass to the nearest new active node; exact numerical ties use the smallest node index. Newly activated nodes start with zero mass unless receiving this transfer. This can concentrate material and is not a high-order moving-boundary solver. It is a simple, explicit mass-conserving policy. Empty domains are rejected rather than assigned an invented destination.

## The growth trigger and step ordering

At a stored graph-boundary node, define $\chi_i=u_i/(u_i+v_i)$ when the denominator is positive and zero otherwise. The growth score is the maximum $\chi_i$ on those nodes. A rewrite is permitted when that score exceeds the seed threshold, the minimum dwell count has elapsed and the generation budget has not been exhausted. It executes once, not infinitely often at a threshold.

One step proceeds as follows: evaluate the growth predicate on the stored state; choose the current generation; compile its memory-dependent field; remap the old mass into the new mask; apply positive transport and local reaction; compute bounded observations; update fast state and memory; encode a pulse and frame parity; store the new mask and state. The newly updated memory is used in the next compilation. This explicit one-step ordering resolves the otherwise ambiguous simultaneous feedback in the conversational account. It is a model choice, not an observed biochemical clock.

# The unified seed--field composition theorem

## Admissibility conditions

Call a seed admissible for $N$ steps when the following contracts hold. The grammar and interpreter are deterministic, all words needed through $g_{\max}$ fit the finite budget, geometric scales remain positive, and every compiled active mask is nonempty. Coordinates, rates, input probes and states are finite. The source record, realized pseudorandom law, arithmetic conventions and all tie rules are specified.

At every accepted step, remapping is nonnegative and column-stochastic; transport is generated by nonnegative edge rates with zero column sums and is substepped to $\delta t\max(-Q_{ii})\leq1$; and reaction is nonnegative and conserves the declared total mass. The default reversible conversion satisfies those conditions. The initial mass is nonnegative with total $M_0$, and $z_0,m_0\in[-1,1]^d$.

Observations $y_n\in[-1,1]^d$ drive $$\begin{aligned}
\label{eq:recurrence}
z_{n+1}&=(1-\alpha)z_n+\alpha\tanh(Az_n+Bm_n+Cy_n),\\
m_{n+1}&=(1-\eta)m_n+\eta\tanh(Dz_n+Ey_n),
\quad 0<\alpha,\eta\leq1,
\end{aligned}$$ with componentwise $\tanh$. The codec uses $D_c=2^b$, $k_n\in\{0,\ldots,D_c\}$, $r_0=0$ and $$\label{eq:codec}
q_n=\mathbf{1}[r_n+k_n\geq D_c],\qquad r_{n+1}=r_n+k_n-D_cq_n.$$ $D_c$ is the codec denominator, not a diffusion coefficient or the recurrent matrix $D$. Parity is computed on the declared payload and stored separately from the material dynamics.

**Unified Theorem U1** (Unified seed--field composition). For an admissible complete seed and any $N$ accepted finite updates, the declared operator composition defines one unique history. It has the following guarantees.

**(a) Replay and type separation.** Identical complete seed, input history and arithmetic conventions yield identical states, generated words and outputs. Documentary labels that do not enter the laws cannot alter that history.

**(b) Geometric semantics.** At each fixed generation and memory state, the compiled field is 1-Lipschitz in the chosen Euclidean spatial metric and its nonpositive set is exactly the declared union/intersection of strokes and ground half-space. This does not assert a globally exact interior signed distance for an overlapping composite.

**(c) Material invariants.** The chemical state remains nonnegative and its total declared mass is $M_0$ through transport, reaction and domain changes. For a fixed realized sequence of the same stochastic matrices, the chemical transition is nonexpansive in mass $\ell^1$ norm.

**(d) Bounded recurrence.** The fast state and memory remain in $[-1,1]^d$, including when the field, masks, transport coefficients and growth decisions change within the admissibility conditions.

**(e) One-bit certificate.** Every output is a bit, $0\leq r_n<D_c$, and for every prefix of length $n$, $$\sum_{j=0}^{n-1}q_j-\sum_{j=0}^{n-1}\frac{k_j}{D_c}
=-\frac{r_n}{D_c}\in(-1,0].$$ Appending XOR parity produces an even-parity frame. This is a coding invariant, not proof of geometric topology or immunity to all transmission errors.

**(f) Conditional covariance.** Rigidly transforming the entire geometry, metric representation, probes, velocity and gate specification preserves the corresponding continuous scalar observations. At the discrete level, an exact node relabeling preserves the history when all graph matrices, remaps, data and tie policies transform consistently. A fixed raster need not be invariant under an arbitrary rotation.

Proof. The grammar, interpreter and all finite state updates are deterministic on their specified domains. Composition and induction establish (a). Each primitive distance is 1-Lipschitz, and finite minima and maxima preserve a common Lipschitz bound and the required closed-set membership identities, giving (b).

For (c), express one material update on stacked species masses as $$\mu_{n+1}=R_n\,\operatorname{diag}(P^U_n,P^V_n)
\,\operatorname{diag}(\Pi_n,\Pi_n)\mu_n.$$ Each factor, including any repeated positive substeps, is a nonnegative column-stochastic matrix. A product of such matrices is again nonnegative and column-stochastic. Hence positivity and $\mathbf{1}^T\mu_n=M_0$ follow by induction. For any fixed such product $K$, $\left\lVert Kx\right\rVert_1\leq\left\lVert x\right\rVert_1$; apply this to the difference of two mass states using the same realized factors.

For (d), every component of each next state is a convex combination of a number in $[-1,1]$ and a $\tanh$ value in that interval. The result is independent of the size of the driving matrices so long as their evaluations are defined. For (e), $0\leq r_n+k_n<2D_c$ gives a binary $q_n$ and a residual in $[0,D_c)$. Summation of Eq. (34) gives the prefix identity. XOR of the payload XOR with itself gives even parity.

For (f), Euclidean isometries preserve distances and consistently transformed vector projections. Discrete permutation covariance follows by conjugating state-transition matrices and applying the corresponding input and output permutations. Consistent remap and tie-policy transformation is essential. The twelve supporting lemmas supply the individual identities and delimit their scope. None of these operations introduces an empirical statement about consciousness. ◻

## What this theorem deliberately does not imply

U1 is an invariant-and-composition theorem. It does not claim global contraction of the full hybrid system, unique patterns for different seeds, continuum convergence, biological validity or universal physical closure. State-dependent gates, masks and threshold decisions mean that two nearby initial states may select different matrices; the fixed-matrix nonexpansiveness clause cannot then be applied across them without further estimates. A conserved total also prevents unrestricted contraction across initial states with different total mass.

Admissibility is a mathematical premise, not a claim that all arbitrary parameter files succeed. The implementation rejects unsupported grammar changes, invalid domains and scales, nonfinite values, negative masses, invalid generators and exceeded budgets. Floating-point execution can differ from exact real arithmetic. The numerical tests and exact integer codec checks address specified examples; they do not prove every floating-point program path.

# Twelve supporting lemmas and proofs

**Lemma L1** (Word algebra, pairing and finite replay). Pair exchange preserves pair parity and canonicalization. Symbol exchange $X\leftrightarrow Y$, together with $+\leftrightarrow-$, is an involution commuting with the grammar. At generation $g$, $$N_X+N_Y=2\,3^g,\quad N_X-N_Y=N_X(0)-N_Y(0),\quad |w_g|=5\,3^g+1.$$ With reflected initial pose, the exchanged word emits the reflected segment sequence. Complete deterministic initialization and transitions imply unique finite replay.

Proof. XOR is addition in $\mathbb{F}_2$, and sorting a pair is exchange-invariant and idempotent. Inspection of the two productions gives $P(Jw)=J(Pw)$, where this $J$ denotes token exchange. The count vector is multiplied by $\left(\begin{smallmatrix}2&1\\1&2\end{smallmatrix}\right)$; its sum triples and its difference is unchanged. Initially $|w_0|=6$. Each draw token is replaced by six tokens, so $|w_{g+1}|-|w_g|=5(2\,3^g)$, yielding the stated formula. Turn reversal under spatial reflection, with stack save/restore, proves interpreter covariance by induction on tokens. Induction on deterministic time steps proves replay. These statements do not make the seed-to-output map injective. ◻

**Lemma L2** (Set semantics, Lipschitz closure and the conditional fold). Finite minima encode closed-set unions, maxima encode intersections, and finite min/max compositions of 1-Lipschitz fields are 1-Lipschitz. For the paired arcs, a near-side fold is valid when the translated right arc lies wholly in $x\geq0$; $h\geq R\sin\alpha$ suffices. Composite membership does not imply exact interior signed distance.

Proof. $\min(f,g)\leq0$ iff $f\leq0$ or $g\leq0$; the analogous maximum gives "and". If both $f$ and $g$ change by at most $e$ between two points, their minimum and maximum also change by at most $e$. Induction proves the finite statement. For a query $x\geq0$ and any right-arc point with horizontal coordinate $u\geq0$, $(x-u)^2\leq(x+u)^2$, so the corresponding reflected point is never closer. Taking minima proves the fold in that regime.

For a counterexample outside it, take $R=1$, $h=0.5$, $\alpha=\pi/2$, thickness $0.1$ and query $(0.5,0)$. The explicit union field is $-0.1$ but the fold gives $0.9$. For a separate metric counterexample, two unit disks centered at $(\pm0.5,0)$ give minimum signed distance $-0.5$ at the origin, while the actual signed distance to the union boundary is $-\sqrt{3}/2$. Correct membership and a Lipschitz bound therefore do not imply exact negative distance magnitude. Conservative distance reasoning is standard context, not a consciousness result. [\[E2\]] ◻

**Lemma L3** (Rigid hinges preserve geometry, not a forced bit flip). For Euclidean isometry $T(x)=Qx+b$, $Q^TQ=I$, $d_{T\Omega}(Tx)=d_\Omega(x)$. A reflection can reverse orientation while preserving occupancy. A global change of frame preserves consistently transformed observations; arbitrary resampling on a fixed Cartesian raster is a separate operation.

Proof. $\left\lVert Tx-Ty\right\rVert=\left\lVert Q(x-y)\right\rVert=\left\lVert x-y\right\rVert$. Taking the infimum over the set or its boundary preserves distances, and the bijection preserves interior membership. Orientation is determined by $\det Q$, while occupancy depends on membership; neither determines the other. Covariance of vector projections follows by transforming both vectors by $Q$. A grid after an arbitrary rotation is usually not the original node set, so no exact raster permutation is supplied by the continuous identity alone. ◻

**Lemma L4** (Chart metric, event roots and bracket error). The log-polar metric and roots in Sections 3--4 follow from the declared coordinate and trajectory maps. A sign-changing continuous function on a finite bracket has a zero in it; $n$ bisections reduce bracket width by $2^{-n}$. A tangent zero need not be detected by opposite-sign tests.

Proof. Differentiate $x=r_0e^\rho(\cos\theta,\sin\theta)$: the two coordinate derivatives are orthogonal with equal length $r_0e^\rho$, giving the metric. In Eq. (17), a product vanishes exactly when a factor does. Solving those factors yields the stated $\rho$ roots, with no second-factor root when its sine coefficient is zero. Substitution into $\rho=\log(c_s(t-t_0)/r_0)$ gives Eq. (19). Exponent pairs multiply to one in normalized delay. The intermediate value theorem preserves a root-containing sign bracket, and each chosen half has half its width. The example $f(t)=(t-a)^2$ proves why a zero need not change sign. ◻

**Lemma L5** (Closed graph transport and dissipative diffusion). A finite column generator $Q$ with nonnegative off-diagonal entries and zero column sums gives a nonnegative column-stochastic $P=I+\delta t Q$ whenever $\delta t\max(-Q_{ii})\leq1$. It preserves mass, nonnegativity and is nonexpansive in $\ell^1$. For symmetric diffusion, $$x^TL_hx=-\sum_{\{i,j\}\in E}w_{ij}(x_i-x_j)^2\leq0.$$

Proof. The step bound makes every diagonal of $P$ nonnegative; off-diagonals already are. Its columns sum to one. Therefore $P\mu\geq0$ for $\mu\geq0$ and $\mathbf{1}^TP\mu=\mathbf{1}^T\mu$. For any signed vector $x$, the triangle inequality gives $\sum_i|\sum_jP_{ij}x_j|\leq\sum_j|x_j|\sum_iP_{ij}=\left\lVert x\right\rVert_1$. For symmetric edge weights, collect the contributions of the two endpoints of each edge in $x^TL_hx$ to obtain $-w_{ij}(x_i-x_j)^2$. Constants lie in the kernel; disconnected components supply additional constant modes. ◻

**Lemma L6** (Positive, locally conservative reaction). The reversible conversion step of Section 5 preserves $u_i+v_i$ at each node and maps nonnegative pairs to nonnegative pairs under the stated step bound. Products of such substeps have the same properties.

Proof. All four reaction-matrix entries are nonnegative and each column sums to one. Matrix multiplication therefore preserves the nonnegative cone and the left invariant $(1,1)$. A product of column-stochastic nonnegative matrices remains in that class. If arbitrary nonlinear reactions are substituted, these premises must be re-established; the theorem is not inherited merely by naming a reaction function. ◻

**Lemma L7** (Conservative geometry changes). A nonnegative column-stochastic remap $\Pi$ preserves nonnegative total mass across domains of different sizes. With cell-volume matrices $V,V'$, $c'=(V')^{-1}\Pi Vc$ preserves integrated concentration. Deleting outside samples without transferring their mass is not this operation.

Proof. Let $\mu=Vc$. Then $\mu'=\Pi\mu\geq0$ and $\mathbf{1}^T\mu'=\mathbf{1}^T\mu$. The concentration formula is just the positive diagonal change of representation. In the nearest-node implementation, each old node's mass has one destination, including itself when retained; each remap column contains one unit entry. A finite index tie rule makes the result deterministic. An arbitrary relabeling must transform that priority rule as well, or tie covariance can fail. ◻

**Lemma L8** (Bounded state and mutable memory). The recurrent laws in Eq. (32) leave the cube $[-1,1]^{2d}$ invariant. More generally, if $m_{n+1}=(1-\eta)m_n+\eta\psi_n$ with $\left\lVert \psi_n\right\rVert_\infty\leq B$, then $$\left\lVert m_n\right\rVert_\infty\leq(1-\eta)^n\left\lVert m_0\right\rVert_\infty+
[1-(1-\eta)^n]B.$$

Proof. Each scalar $\tanh$ lies between $-1$ and $1$. A convex combination of values in that interval stays in it. For the more general bound, repeatedly substitute the affine recurrence and bound its geometric series. Memory in this model is a mutable state variable whose influence can decay or change. Boundedness neither implies permanent storage nor identifies the physical substrate of human memory. ◻

**Lemma L9** (One-bit error, parity and Hadamard structure). The integer accumulator satisfies U1(e). If input coverage $a_n\in[0,1]$ is rounded to $k_n/D_c$ by nearest-half-up, then in ideal real arithmetic $$\left|\sum_{j<n}q_j-\sum_{j<n}a_j\right|
<1+\frac{n}{2D_c}.$$ Parity is addition modulo two. The normalized Walsh--Hadamard transform is a real orthogonal involution, not a one-bit XOR reduction.

Proof. The residual induction and telescoping identity are given in U1. The rounding error of each input is at most $1/(2D_c)$; add these errors to the strict dyadic prefix bound. The implementation's integer certificate is exact for its emitted $k_n$ values; the separate conversion from arbitrary floating-point coverage remains part of numerical arithmetic.

For set indicators, $\mathbf{1}_{A\triangle B}=\mathbf{1}_A\oplus\mathbf{1}_B$ pointwise. Appending the XOR of a finite payload makes total parity zero. Odd numbers of flipped bits are detected; even numbers can evade this check. This does not recover lost distances or encrypt a payload.

For binary indices $a,b\in\mathbb{F}_2^r$, set $H_{ab}=(-1)^{a\cdot b}$. Distinct rows sum to zero in their inner product by pairing indices on a differing bit; identical rows have squared norm $2^r$. Thus $HH^T=2^rI$ and $U=2^{-r/2}H$ is orthogonal with $U^2=I$. The parity appears inside an exponent that defines real matrix entries. The complete transform retains dimensions and accepts asymmetric vectors; it does not imply a quantum electron-memory mechanism. ◻

**Lemma L10** (Observational and semantic non-identification). An interpretation label absent from the transition and observation laws cannot change observable histories under identical numerical inputs. A finite occupancy record does not identify the full field, and model traces alone do not select an unmeasured consciousness ontology.

Proof. If the label does not enter any map, equal states and inputs produce equal next states and outputs regardless of label. Induction proves equality of histories. Likewise, two different positive values have the same outside bit; finitely many such signs leave infinitely many compatible field assignments. The numerical invariants therefore cannot identify an interpretation that has not been linked to distinct observations. This proves a measurement limitation, not the falsity or truth of any spiritual interpretation. ◻

**Lemma L11** (Conditional recurrent contraction). For a fixed generation, common prescribed probes and no state-dependent chemistry difference, suppose the observation law has memory Lipschitz constant $L_y$. In the joint infinity norm, a sufficient contraction factor for Eq. (32) is $$\begin{aligned}
q=\max\{&1-\alpha+\alpha(\left\lVert A\right\rVert_\infty+\left\lVert B\right\rVert_\infty+\left\lVert C\right\rVert_\infty L_y),\\
&1-\eta+\eta(\left\lVert D\right\rVert_\infty+\left\lVert E\right\rVert_\infty L_y)\}.
\end{aligned}$$ If $q<1$, two such trajectories contract by at most $q$ per step. This is not an unconditional contraction claim for the hybrid growth/transport system.

Proof. $\tanh$ is 1-Lipschitz. Subtract the state equations, apply the induced matrix infinity norm, and bound both state differences by their joint maximum. The resulting two nonnegative row bounds give $q$. Iteration gives $q^n$ times initial separation. A fixed-point conclusion additionally needs a time-independent self-map. If masks, gates, chemistry or trigger decisions change differently between the trajectories, the observation bound used in this argument is not supplied. The retained auxiliary geometry-only model has $L_y=0.04$ and $q=0.94464$; that numeric factor must not be transferred to the v2 coupled chemical loop. ◻

**Lemma L12** (Perturbation margins and limits of pattern claims). For finite sample sites $p_i$, if $\epsilon<\min_i|F(p_i)|$ and $|\widetilde F(p_i)-F(p_i)|\leq\epsilon$, then the two sampled masks coincide. In the fixed, symmetric diffusion-only graph with positive reversible reaction rates and nonnegative diffusivities, the two-species reaction has no diffusion-driven growing eigenmode.

Proof. A perturbation smaller than the distance of a scalar sample from zero cannot change its sign, proving the mask claim. If a sample lies exactly on the boundary, its margin is zero and the claim gives no protection. Consequently, a seed-bit change does not necessarily change topology or a pattern.

For a Laplacian eigenmode with $L_hx=-\lambda x$, $\lambda\geq0$, the reaction--diffusion mode matrix is $$M_\lambda=\begin{pmatrix}-a-D_U\lambda&b\\a&-b-D_V\lambda\end{pmatrix}.$$ Its trace is negative and its determinant is $(aD_V+bD_U)\lambda+D_UD_V\lambda^2\geq0$. The eigenvalues therefore have nonpositive real parts. The zero spatial mode has a conserved direction. This minimal model can redistribute an initial pattern and react to geometry changes, but it is not evidence that a seed necessarily generates self-organized Turing patterns. That stronger corpus statement would require a different reaction law and an instability analysis. [\[C4, pp. 14--15\]] ◻

# Consciousness across bodily, digital and spiritual domains

## The candidate explanatory bridge

[**\[H\]**]  The proposed bridge is that some organization of conscious experience may depend on a recurrent, memory-modified model of embodied boundaries, where physical transport and sensing constrain the available information and action. The mathematical state is an explicit surrogate for such organization. Its suitability must be judged by predictions about observations, not by the visual resemblance of a simulated arch or branch to anatomy.

Let $h_n$ be the model history and let $\widehat r_n=\mathcal O_\vartheta(h_n)$ be a prospective readout of a predeclared report or task measure. A fitted relationship between $h_n$ and measured reports would be an empirical bridge hypothesis; it is not part of U1. The supplied corpus contains no paired reports, sensor measurements or fitted $\vartheta$, so the delivered kernel exports synthetic state features, not a calibrated consciousness score.

A useful unified account must explain which operations matter, under which interventions, and beyond which comparison models. One cannot infer that consciousness exists whenever U1's invariants hold: a nonnegative conservative transport calculation with bounded memory is already enough to satisfy many clauses, regardless of any proposed subjective interpretation.

## Bodily sensing: separate interfaces, shared geometry

[**\[D\]**]  Retained toy sensing interfaces make dimensional distinctions explicit. For eye-origin baseline $d_{\mathrm{IPD}}>0$, $$e_{L,R}=o\mp\tfrac12 d_{\mathrm{IPD}}\hat x.$$ For point receivers at $r_L,r_R$, a source $s$ and specified constant speed $c_s$, $$\mathrm{ITD}=\frac{\left\lVert s-r_R\right\rVert-\left\lVert s-r_L\right\rVert}{c_s},\qquad
|\mathrm{ITD}|\leq\frac{\left\lVert r_R-r_L\right\rVert}{c_s}.$$ The last inequality is the reverse triangle inequality. Eye separation is a length, while this idealized arrival difference is a time. IPD does not uniquely determine ear separation, a person's acoustic transfer function, gaze direction or vestibular response. The code provides geometric interfaces, not physiological calibration. "IDT" remains insufficiently specified in the corpus and is not silently assigned a new operator.

The chemical layer could motivate a future body-boundary model, but it is not already one. The supplied materials do not give membrane transport coefficients, receptor kinetics, neural transduction, cell mechanics or a measurement procedure for molecular valves. The new "sieve" is therefore represented by a gate and a domain boundary as a modeling analogy. A biological realization would require independent calibration and tests of those assignments.

## Genetic pairings and unsupported biological reductions

[**\[S; U\]**]  C4, p. 12, treats fertilization as a deterministic time root and a one-bit $XX/XY$ collapse; pp. 15--16 assert that local genetic editing is invalidated by mirrored geometry. Neither conclusion is established by the equations or the supplied evidence. The symbolic alphabet is not the genome, a model's boundary event does not specify a biochemical mechanism, and neither parenthood nor human development is reduced to a scalar computational bottleneck by this theorem.

[**\[E\]**]  A limited external check is directly relevant to the source's denial of DNA cutting: Jinek and colleagues experimentally reported RNA-guided Cas9 cleavage of double-stranded target DNA. That primary result contradicts the assertion that mirrored DNA geometry makes such cutting fictitious. It does not imply that all editing is simple, unconstrained or explained by this engine. [\[E3\]]

There is also a purely mathematical error in the corpus's argument. Removing or changing one primitive leaves a finite min-field defined when at least one primitive remains; cutting a symmetric shape may break symmetry without making all geometry undefined. The Hadamard transform is invertible on all input vectors of its declared size, not only symmetric ones. The accompanying tests exhibit both facts. Molecular transport, chemistry and environmental context can matter without implying that a supported DNA-cleavage mechanism is impossible.

## Digital scope

[**\[D\]**]  The engine is an inspectable research kernel: it performs finite rewriting, geometry evaluation, graph assembly, mass transfer, transport, reaction, recurrent updates and coding. The title "AI Engine" is the author's system name; no trained language model, general agent, brain emulation or consciousness detector is included. The code uses real-valued numerical arrays internally. A one-bit output does not make every internal variable a bit.

The binary spatial hierarchy and log-polar lookup are retained utilities, not a universal replacement for computation. Geometry evaluation is still an operation with resource costs. No acoustic driver, surveillance function, biological protocol, optical hardware or harmful-stimulus generator is provided. Optical implementation and processing latency remain engineering proposals; no propagation path, device characterization or measured latency is supplied.

## Spiritual scope and the "story around the operators"

[**\[I\]**]  Spiritual language may describe felt unity, significance, connectedness, purpose or transcendence in first-person terms. These are interpretive categories carried forward from the earlier manuscript, not measured fields introduced into the transport equations. A report about such experience can become an observable variable with an appropriate study design. Its metaphysical interpretation is a separate question.

C4, pp. 11--12, explicitly distinguishes operators from the stories used to interpret them. L10 formalizes the narrow numerical consequence: changing a narrative label that does not enter the laws cannot change their outputs. This does not prove that human meaning is unreal or that a spiritual interpretation is false. It prevents the same trace from being presented as independent confirmation of incompatible unmeasured ontologies.

No geometric proof assigns moral value to $XX/XY$ pairings, rotation direction, a person's ancestry or a historical symbol. No asserted equivalence between an SDF hinge and a soul, wormhole, charge--parity boundary or quantum collapse enters U1.

# Executable kernel and recorded verification

## Defaults and concrete observations

The default configurations use a $61\times31$ Cartesian grid, $h=0.08$, total window $[-2.4,2.4]\times[-0.16,2.24]$, and 120 steps of $\Delta t=0.04$. Geometry starts at generation one and may reach generation four. The dwell count is 30 and the growth-score threshold is $0.55$. Diffusivities are $D_U=0.05$, $D_V=0.025$, swirl coefficient $\omega=0.06$, and conversion rates $a=0.24$, $b=0.12$. All are uncalibrated simulation units.

The initial concentration law is explicit in code: a small positive background and a Gaussian enrichment for each species, restricted to the active mask and multiplied by $h^2$ to obtain mass. Both sample configurations initially represent the same total mass. Their early sampled fields coincide; later generated geometry and boundary scores can diverge.

Three prescribed moving probes produce the field feature $-\tanh F$. The actual bounded observation is $$y_{n,\ell}=0.6[-\tanh F(x_{n,\ell})]+0.4(2f_U-1),\quad
f_U=\frac{\sum_i u_i}{\sum_i(u_i+v_i)},$$ with $f_U=1/2$ when total mass is zero. This is a dimensionless mixture chosen for the demonstrator, not a claim that concentration and distance are the same quantity. The fast and memory matrices are seeded PCG64 realizations with declared row-sum norms $0.35,0.15,0.40,0.30,0.20$. The final pulse coverage is $a_n=(1+\operatorname{mean}z_{n+1})/2$. A frame contains the three occupancy bits, one pulse and one even-parity bit.

\@Yrr@ Executed default quantity & $XX$ & $XY$\
Number of steps & 120 & 120\
Initial mass & 0.4004597981 & 0.4004597981\
Largest absolute total-mass drift & $1.832\times10^{-15}$ & $1.832\times10^{-15}$\
Smallest represented mass & 0 & 0\
Growth-event steps & 31, 61, 91 & 31, 61\
Final generation & 4 & 3\
Final active nodes & 317 & 293\
Maximum substep exit-rate product & 0.697 & 0.697\
Largest absolute fast-state component & 0.0663562 & 0.0663562\
Largest absolute memory component & 0.0151681 & 0.0151681\
Lowest dyadic prefix error & $-0.898881$ & $-0.908356$\
All exact integer codec certificates & Pass & Pass\
All recorded frames have even parity & Pass & Pass\

The default $XY$ trace does not reach generation four because its later boundary-score predicate is not satisfied. This is a disclosed simulation outcome, not a claim of superiority or biological difference between token pairs. The cover and same-generation geometry figures deliberately show generation-four compiled geometry; the final transport fields show the actual reached generation. Their captions are not interchangeable.

![Final $XY$ concentration in the active finite graph. The mass is transported and locally converted without an external source. This transient result is not evidence of a biological morphogen, tissue development or self-organized Turing instability.](figures/transport_xy.png)

![Observed floating-point drift relative to the common initial mass. The mathematical invariant is exact in real arithmetic; the run is finite-precision. The archive contains the scalar mass at every step.](figures/mass_conservation.png)

## Written proof, solver checks and executable tests

**Written layer.** U1 and L1--L12 supply assumptions, statements and proofs. Infinite induction, metric arguments, differential formulas and semantic non-identification are not completely encoded in a proof assistant. The mathematical contribution of this edition is the explicit composition, closure assumptions, counterexamples and correspondence to the kernel, not a priority claim for its standard component identities.

**Solver layer.** The package contains 34 standalone SMT-LIB negated identities or implications. Z3 version 4.13.3.0 returned `unsat` for all 34 and produced proof logs. K01--K20 adapt the intermediate algebra checks; K21--K34 add conservation, positivity, remapping, integer coding and perturbation fragments. The official solver and its encoding are within the trust boundary; no independent small-kernel replay of the proof logs is claimed. The solver-method reference is external documentation, not an audit of this package. [\[E4\]]

**Execution layer.** 99 regression tests pass in the recorded environment: 55 adapted component tests and 44 new tests. These cover geometry, the invalid fold, reflection, coordinates, LUT certificates, event roots and near-singular cases, graph sums, diffusion energy, positive substeps, mass-preserving remap, reaction, exact integer coding, state bounds, input nonmutation, configuration validation and same-environment replay. A fixed-point codec test checks all $5^4=625$ length-four input words at denominator four. Separate random-prefix tests check 5,000 dyadic inputs. Tests are finite examples and do not turn floating-point code into a universally verified implementation.

The auxiliary full-angle and half-angle event roots at the disclosed test angle have maximum polynomial residual $3.73\times10^{-17}$. A 1,000-query LUT test has maximum observed error $0.0640730$ with zero violations of its conservative corner-distance certificate. The retained geometry-only recurrent test has bound $q=0.94464$ and step-180 separation $1.308\times10^{-7}$ against a $3.531\times10^{-5}$ envelope. These auxiliary numbers are not biological findings or global hybrid-system guarantees.

![Every recorded prefix satisfies the dyadic accumulator certificate. The certificate concerns the quantized $k_n/2^{16}$ input, not recovery of the full original field or perfect transmission of every frame.](figures/codec_prefix.png)

## Implementation map and reproduction

\@lY@ File & Main responsibility\
`kernel/core.py` & Pair algebra, grammar, turtle, primitive and composite fields, lookup, bisection, sensing, parity, Hadamard and auxiliary recurrence.\
`kernel/spatial.py` & Capsule bounding-volume hierarchy with exhaustive-query comparison tests.\
`kernel/transport.py` & Finite grid, masked graph, directed rates, positive transport, reversible reaction and conservative remapping.\
`kernel/events.py` & Both actual corpus polynomial variants, dimensionally normalized times and singularity/overflow status.\
`kernel/coding.py` & Exact integer dyadic accumulator and prefix certificate.\
`kernel/unified.py` & Strict v2 seed schema, geometry/chemistry/memory loop, growth predicate, pulse and parity frame.\
`kernel/demo.py` & Disclosed runs, numerical files, fingerprints and figures.\

Run from the extracted package root:

    python verify_package.py
    python -m pip install -r requirements.txt
    python -m unittest discover -s tests -v
    python -m kernel.demo
    python formal/check.py
    bash manuscript/build.sh

For a single configuration, use `python -m kernel.demo –config config/seed_xy.json –out rerun_xy`. The full reproduction record uses Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8 on Linux. A LaTeX installation is required for PDF rebuilding; Z3 is needed for the optional solver rerun. The checker supports an installed executable or the official C library. No font, solver binary or scientific paper is redistributed as a dependency.

Run the checksum verifier before regenerating outputs. Rebuilt figures or PDFs may have different timestamps and bytes, even when numerical results agree. Same-environment replay refers to the defined numerical experiment, not to cross-platform bitwise identity of all artifacts. The configuration fingerprint records realized matrices; the archive checksum manifest records code and source bytes.

# Research tests and extension gates

## Tests of the computational theory

[**\[H\]**]  A first research phase can remain entirely numerical. Compare the complete loop against a frozen-geometry version, a frozen-memory version, a geometry-free graph matched on node count, and a transport-free version. Predeclare a downstream task and scoring rule; match parameter counts and computational budgets. The present demonstrations do not carry out this predictive comparison and should not be described as evidence that the full architecture is necessary.

For geometry sensitivity, perturb the interpreter angle or stroke radius and record field error, mask changes, connectivity, transport spectrum and output differences. L12 predicts mask invariance under a positive sampled margin; it also specifies when that prediction is unavailable. The failure criterion is a certified-margin case whose exact target changes sign, or a numerical violation beyond a declared rounding allowance.

For the material layer, test closed graphs and explicit open-boundary sources separately. Closed-run mass must satisfy the conservation tolerance; an open-run ledger must explain every change by prescribed transfer or reaction. Test shrinking as well as growing domains. Positivity should be checked before any postprocessing. Higher-order remapping or continuum claims require a grid-refinement study and appropriate reference solutions, neither of which is supplied by the current invariant theorem.

## Tests of an empirical consciousness bridge

[**\[H\]**]  A later empirical study would need a defined behavioral or first-person outcome, measured inputs, data provenance, fitted parameters, appropriate consent and oversight, and matched alternatives. A useful hypothesis is not simply that a model can fit reports, but that a specified boundary/memory interaction predicts held-out observations or intervention effects better than the controls.

Bodily, digital and spiritual measures must not be conflated. A latency, task response, confidence rating and report of felt unity are different observables. Their scales, coding rules and uncertainty would have to be stated before interpreting a common latent feature. No personal identifier or $XX/XY$ token is a proxy for consciousness level. No clinical, neurological or genetic diagnosis should be inferred from these demonstrations.

The empirical bridge would fail for its declared task if a matched non-boundary model predicts equally well or better, if the predicted intervention signature does not occur, or if success depends on retrospective relabeling of outcomes. Failure would challenge that bridge hypothesis; it would not invalidate the standard algebra in U1. Conversely, correct algebra does not rescue a failed empirical explanation.

## Conditions for future kernel extensions

A new growth grammar must define and validate its interpreter rather than being silently ignored by configuration loading. A new reaction law must provide positivity and balance conditions. A new coordinate quotient must provide its metric and seam rules. A moving-domain continuum solver must account for relative boundary flux and demonstrate numerical convergence. A photonic or biological implementation must provide a realization map, measurements and error/latency characterization. A consciousness readout must specify observations and discriminating tests.

The existing proofs are reusable where their assumptions remain true. They are not a license to transfer every conclusion to a larger system with different state types or dynamics.

# Source-to-formalization audit

The complete machine-readable audit is `docs/claim_audit.csv`. The following register records the principal decisions, including conflicts and unsupported inferences. It preserves the distinction between a source assertion, an added model and a supported conclusion. "Not established" refers to the supplied evidence or a stated mathematical implication, not to a blanket rejection of the author's research program.

P.10P.24P.57 ID & Source location & Disposition in the author edition\
A01 & C0; C1; C3 & The seed--field/operator-chain scope is retained. Standard component mathematics is not claimed as a new physical law.\
A02 & C3, Sec. 2 & The explicit $X/Y$ grammar, pair algebra and brackets are retained; v2 parameters and code paths are made explicit.\
A03 & C4, pp. 1--3 & S-curve shape does not establish a cryptographic pairing. No finite-field pairing or cryptographic security claim is implemented.\
A04 & C4, pp. 3--4 & STM, Ohm's law and the Miller algorithm are not connected by a supplied derivation or apparatus. This chain is not a theorem premise.\
A05 & C4, pp. 5--8 & A program run is not a "physical proof" of the engine's proposed ontology. Verification targets are stated independently.\
A06 & C4, p. 6 & Earlier exponential envelopes have incompatible scaling. This edition declares a path and units before deriving time.\
A07 & C4, p. 8 & The half-angle second polynomial factor and full-angle root conflict. Both $\kappa=1/2$ and $\kappa=1$ are preserved as distinct models.\
A08 & C0; C1; C4, p. 8 & Positive exponential branches are reciprocal in normalized delay, not necessarily linearly mirrored time curves.\
A09 & C4, pp. 8--9 & "All words as SDF operators" is typed as rewrite, interpreter and field compilation. Reachable words need not represent every field.\
A10 & C2, pp. 1--3 & Explicit two-arc union and baseline are retained. Conditional folding is tested rather than universally assumed.\
A11 & C2, p. 2 & A query-coordinate fold denotes a preimage when used to define a set; the forward-image notation is not silently adopted.\
A12 & C2, pp. 2--3; C4, p. 14 & A min of exact primitive SDFs is sign-correct but not generally an exact interior union distance. The distinction is retained.\
A13 & C2, pp. 7--9 & A baseline clip, orientation marker and event-time root are separate operations. The hinge diagram supplies no physical parity law.\
A14 & C2, p. 8 & For the stated centers, the tangent-circle hinge is $(0,0)$ when spacing equals radius. The claimed $(0,R)$ coordinate is not used.\
A15 & C4, pp. 9--10 & Rotor direction does not determine the field's inside/outside sign. Reflected occupancy is preserved for reflected geometry.\
A16 & C4, pp. 10--11 & Historical symbolism and a $45$-degree rotation do not mathematically cause generative balance or collapse. Rotation remains an isometry.\
A17 & C4, pp. 11--12 & The distinction between operators and interpretive stories is retained as a semantic non-identification result, not a verdict on meaning.\
A18 & C4, p. 12 & Fertilization is not established as the toy exponential event or quantum collapse. $XX/XY$ remain declared symbolic seeds.\
A19 & C4, pp. 12, 15 & Parenthood is not mathematically reduced to a time sink or a scalar bottleneck. The kernel makes no such human classification.\
A20 & C4, p. 13 & The generic reaction--diffusion--advection template is retained. Reaction laws, boundary conditions and material units are added explicitly.\
A21 & C4, pp. 13--14 & A no-flux condition with advection concerns total relative flux. A Neumann gradient condition alone is insufficient in general.\
A22 & C4, p. 14 & Removing outside stencil edges and updating the diagonal is implemented as a closed finite graph. Curved-boundary exactness is not claimed.\
A23 & C4, p. 14 & The normalized gradient can fail at nonsmooth composite locations. The finite graph does not require a universal smooth SDF normal.\
A24 & C4, pp. 14--15 & A seed change need not invert topology or uniquely reshape every pattern. A sampled-margin lemma and noninjective examples are provided.\
A25 & C4, p. 15 & Curvature alone does not create a mass sink in a closed diffusion graph. Connectivity can restrict transport without destroying mass.\
A26 & C4, pp. 14--15 & Turing patterns are not guaranteed by a seed or a Laplacian. The minimal reversible reaction has no diffusion-driven growing mode under L12.\
A27 & C4, p. 13 & Concentration-triggered growth is implemented as a sampled threshold with dwell and generation caps, not as instantaneous exact biological timing.\
A28 & C4, pp. 15--16 & The claim that CRISPR cutting is fictitious is unsupported by the formalism and contradicted by the limited primary-source check E3.\
A29 & C4, p. 16 & A local geometric edit can break symmetry without invalidating the whole field. A nonempty edited capsule union is explicitly tested.\
A30 & C4, p. 16 & Hadamard transforms do not reject asymmetric inputs. Their real orthogonal/invertible character is proved and tested.\
A31 & C4, pp. 16--17 & A "sieve" becomes a declared permeability-like interface. No molecular equivalence, ion-channel model or membrane measurement is supplied.\
A32 & C4, p. 17 & "Valves are vortices" is not established as a physical identity. Ambient swirl and edge permeability are separate model inputs.\
A33 & C4, p. 17 & Periodic-table or bond language does not specify $\mathcal R$. The implemented $U\rightleftarrows V$ law is an added, minimal conservative choice.\
A34 & C4, p. 17 & Physical reality's closure is not proved. The theorem uses an explicit closed control-volume assumption; open systems need source and flux terms.\
A35 & C4, pp. 17--18 & The ambient field exists independently of local geometry. A vector field is a section of the tangent bundle, not literally an infinite axis.\
A36 & C4, p. 18 & Log-radius covers all finite real values on the punctured plane. The origin is excluded and the software window remains finite.\
A37 & C0; C2; C4 & A frame is not automatically an eigenbasis; an operator must be specified. No attenuation law is inferred from an arbitrary frame eigenvalue.\
A38 & C0; C2, pp. 4--6 & Log-polar lookup and spatial indexing are finite approximations and acceleration proposals. No universal zero-cost query is asserted.\
A39 & C0; C3 & IPD length and ITD time have separate interfaces. "IDT" remains undefined for implementation purposes.\
A40 & C0; C2, pp. 5--6 & Occupancy, pulse-density coding, Bernoulli thresholding, bit serialization and parity are distinct. Internal float arrays are not erased by one-bit output.\
A41 & C0; C2 & XOR with arbitrary noise is not a universal fidelity improvement. No blue-noise spectrum or guaranteed perceptual benefit is claimed.\
A42 & C0; C2, pp. 8--9 & No wormhole, charge--parity boundary, electron tunneling law or quantum collapse is derived from an SDF hinge or jitter.\
A43 & C0; C2, pp. 10--12 & The asserted deterministic migraine/nausea pathways are not implemented or validated. No diagnosis, exposure recommendation or clinical safety claim follows.\
A44 & C2, p. 11 & The vestibular sketch's inconsistent label placement is not used as anatomical evidence. Model figures are not physiological diagrams.\
A45 & C0; C1; C3 & Memory is modeled as a bounded, mutable state with feedback, not necessarily permanent etching or mitosis. Biological substrate claims remain hypotheses.\
A46 & C0; C1; C3 & Spiritual interpretation remains distinct from measured physical variables. L10 states the limit of an unobserved label.\
A47 & C3; present update & The old tests and algebra fragments are adapted and rerun. New transport, reaction, remap and coding checks are separately recorded.\
A48 & Present update & The full formalization is attributed to Tom Klootwijk as requested. Personal attribution is documentary, not a numerical or physical parameter.\

# Notation and proof-to-code index

\@lY@ Symbol & Meaning and restriction\
$\Sigma$ & Complete versioned seed specification, including input and numerical conventions.\
$p,w_g,P$ & Ordered token pair, generation word and parallel rewriting operator.\
$M,g,v$ & Ambient manifold, metric and vector field; the implementation uses Euclidean $\mathbb{R}^2$.\
$F_G,F_M,F_{g,m}$ & Capsule, double-arc and combined boundary fields; sign-correct composites.\
$F_\kappa$ & Separate auxiliary polynomial with full- or half-angle second factor.\
$\rho,\theta,r_0$ & Log-radius, circular angle and positive reference length.\
$\phi_-$ & $(\sqrt5-1)/2$, a dimensionless toy-geometry parameter.\
$T,t_0,c_s$ & Event time, reference time and declared propagation speed.\
$\mu,c,V$ & Represented mass, concentration and cell-volume conversion.\
$Q,L_h,\Pi,R_n$ & Directed column generator, symmetric graph Laplacian, remap and reaction matrix.\
$z,m,y$ & Fast state, slower memory and bounded model observations.\
$D_c,k,q,r$ & Dyadic codec denominator, integer input, output pulse and integer residual.\
$J,R_\theta$ & Reflection and rotation; not a physical charge--parity operation.\

P.12P.39P.40 Result & Mathematical focus & Supporting executable material\
U1 & Composition and invariant set & Written proof; all component tests; complete $XX/XY$ traces.\
L1 & Pair, grammar, counts and replay & K01--K05; grammar and replay tests.\
L2 & Set semantics and field bounds & K06--K10; distance, fold and membership counterchecks.\
L3 & Rigid covariance, sign distinction & K11, K33; reflection and graph-permutation tests.\
L4 & Charts, roots and bisection & K17 fragment; both root variants and chart tests.\
L5 & Transport positivity and conservation & K21--K24; graph, substep, energy and $\ell^1$ tests.\
L6 & Reversible reaction & K25 and K24 algebra; local reaction tests.\
L7 & Conservative remapping & K26--K27; shrinking, expanding, support and tie tests.\
L8 & Bounded recurrence and memory & K19 fragment; both recurrent test suites.\
L9 & Integer codec, parity, Hadamard & K12--K15, K18, K28--K29; exhaustive short codec words and other coding tests.\
L10 & Interpretive and sign non-identification & K16, K34 fragments; author-field independence and asymmetric-input tests.\
L11 & Conditional contraction & K20 fragment; separate fixed-input geometry-only recurrence.\
L12 & Margins and pattern limitations & K30--K32; mode-spectrum and noninjective-seed tests.\

The registry does not imply that every analytic clause is encoded by its listed algebra fragment. In particular, arbitrary-dimensional inductions, manifold statements, PDE templates and empirical bridge hypotheses are not solver-certified by the small finite identities.

# References and reference scope

Original conversation notes, supplied as Pasted markdown.md. Conceptual source, not experimental evidence.\
Archived as `sources/original_notes.md`.

Tom Klootwijk's Seed--Field Theory of Consciousness and the Senses. Supplied 28-page research manuscript, prior author edition. Archived as `sources/seed_field_revision_1.pdf`.

Double-arc M with UU double-set SDF notation (signed-distance-field). Supplied twelve-page exported conversation. Archived as `sources/double_arc_addendum.pdf`. Page-specific dispositions appear in Appendix A.

Intermediate theorem-and-kernel revision supplied in the conversation, 25-page PDF and companion ZIP. Consulted for eighteen component theorems, symbolic pairings and executable infrastructure. Original inputs are hash-referenced in `provenance/source_manifest.json`; the present code is adapted and revalidated.

Tom Klootwijk NL200678942 10-07-1990. Supplied eighteen-page conversation corpus. Archived as `sources/unification_corpus.pdf`. Its assistant-generated assertions are distinguished from the user's questions and from evidence.

Przemyslaw Prusinkiewicz and Aristid Lindenmayer. The Algorithmic Beauty of Plants. Springer, 1990, Chapter 1. [Author-hosted chapter](https://algorithmicbotany.org/papers/abop/abop-ch1.png). Outside context for parallel rewriting and turtle interpretation only; not evidence for this grammar's biological or consciousness interpretation.

John C. Hart. "Sphere tracing: A geometric method for the antialiased ray tracing of implicit surfaces." The Visual Computer 12 (1996), 527--545. DOI: 10.1007/s003710050084. [Author manuscript hosted by Stanford](https://graphics.stanford.edu/courses/cs348b-20-spring-content/uploads/hart.png). Outside context for distance bounds and implicit geometry; no empirical support for this engine's ontology is inferred.

Martin Jinek, Krzysztof Chylinski, Ines Fonfara, Michael Hauer, Jennifer A. Doudna and Emmanuelle Charpentier. "A programmable dual-RNA-guided DNA endonuclease in adaptive bacterial immunity." Science 337 (2012), 816--821. DOI: 10.1126/science.1225829. [Primary article abstract, PMID 22745249](https://pubmed.ncbi.nlm.nih.gov/22745249/). Used narrowly to check the corpus's assertion denying DNA cleavage; not cited as evidence for the consciousness theory or as a biological protocol.

Nikolaj Bjørner, Leonardo de Moura, Lev Nachmanson and Christoph Wintersteiger. Programming Z3. [Authors' tutorial](https://z3prover.github.io/papers/programmingz3.html). Outside documentation of the solver method; not an independent verification of this package.

External references were checked on 11 September 2026. The author-hosted chapter and geometric manuscript were consulted for the stated mathematical context, not for their figures or experimental data. The new written derivations, added numerical laws and implementation decisions are explicitly the formalization in this edition. Bibliographic data are also supplied in `manuscript/references.bib`.

**Closing formulation.** The engine's unified theorem is a reproducible mathematical statement about a seed-driven, boundary-coupled, conservative and memory-bearing computation. The broader theory proposes that this architecture can inform an account of conscious organization. Keeping the theorem, its implementation and that empirical bridge distinct is what makes the next tests meaningful.
