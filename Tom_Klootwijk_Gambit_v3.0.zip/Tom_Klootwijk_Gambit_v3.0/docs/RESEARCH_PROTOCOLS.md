**Tom Klootwijk Gambit · Edition 3.0 / Kernel 3.0.0**  
**Author: Tom Klootwijk · NL200678942 · 10-07-1990**

# Research tests and extension gates

## Tests of the computational theory

**[H]**  A first research phase can remain entirely numerical. Compare the complete loop against a frozen-geometry version, a frozen-memory version, a geometry-free graph matched on node count, and a transport-free version. Predeclare a downstream task and scoring rule; match parameter counts and computational budgets. The present demonstrations do not carry out this predictive comparison and should not be described as evidence that the full architecture is necessary.

For geometry sensitivity, perturb the interpreter angle or stroke radius and record field error, mask changes, connectivity, transport spectrum and output differences. L12 predicts mask invariance under a positive sampled margin; it also specifies when that prediction is unavailable. The failure criterion is a certified-margin case whose exact target changes sign, or a numerical violation beyond a declared rounding allowance.

For the material layer, test closed graphs and explicit open-boundary sources separately. Closed-run mass must satisfy the conservation tolerance; an open-run ledger must explain every change by prescribed transfer or reaction. Test shrinking as well as growing domains. Positivity should be checked before any postprocessing. Higher-order remapping or continuum claims require a grid-refinement study and appropriate reference solutions, neither of which is supplied by the current invariant theorem.

## Testing the Gambit reduction claim

For a declared finite model, enumerate the state partition, every admissible input and the observation labels. The checker must either construct a representative-independent quotient or return a witness pair with incompatible outputs or successors. A sign-based partition failing this test is not repaired by adding unreported memory to the reduced model. Instead, refine the partition or specify that memory explicitly and then test the new model.

For a continuous or experimentally observed system, a finite test cannot establish the universal congruence condition by itself. Predeclare the observation resolution and intervention set; compare full-state and reduced-state predictors on held-out histories; report uncertainty and any pair of initially equivalent states with distinguishable later outcomes. A hysteresis robustness claim additionally requires field-error bounds and positive threshold margins. This links the new theorem to falsifiable modeling choices without presenting a successful toy quotient as universal physical evidence.

## Tests of an empirical consciousness bridge

**[H]**  A later empirical study would need a defined behavioral or first-person outcome, measured inputs, data provenance, fitted parameters, appropriate consent and oversight, and matched alternatives. A useful hypothesis is not simply that a model can fit reports, but that a specified boundary/memory interaction predicts held-out observations or intervention effects better than the controls.

Bodily, digital and spiritual measures must not be conflated. A latency, task response, confidence rating and report of felt unity are different observables. Their scales, coding rules and uncertainty would have to be stated before interpreting a common latent feature. No personal identifier or $XX/XY$ token is a proxy for consciousness level. No clinical, neurological or genetic diagnosis should be inferred from these demonstrations.

The empirical bridge would fail for its declared task if a matched non-boundary model predicts equally well or better, if the predicted intervention signature does not occur, or if success depends on retrospective relabeling of outcomes. Failure would challenge that bridge hypothesis; it would not invalidate the standard algebra in U3. Conversely, correct algebra does not rescue a failed empirical explanation.

## Conditions for future kernel extensions

A new growth grammar must define and validate its interpreter rather than being silently ignored by configuration loading. A new reaction law must provide positivity and balance conditions. A new coordinate quotient must provide its metric and seam rules. A moving-domain continuum solver must account for relative boundary flux and demonstrate numerical convergence. A photonic or biological implementation must provide a realization map, measurements and error/latency characterization. A consciousness readout must specify observations and discriminating tests.

The existing proofs are reusable where their assumptions remain true. They are not a license to transfer every conclusion to a larger system with different state types or dynamics.


See the full manuscript for definitions, source audit and verification limits.
