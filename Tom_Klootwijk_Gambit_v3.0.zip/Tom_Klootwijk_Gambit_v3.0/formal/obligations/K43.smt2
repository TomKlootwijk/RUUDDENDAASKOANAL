; K43: Mirror-closed deletion preserves a symmetric membership predicate
; Manuscript: L17. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const o Bool)
(declare-const a Bool)
(declare-const ja Bool)
(assert (not (= (and o (not (or a ja))) (and o (not (or ja a))))))
(check-sat)
(get-proof)
