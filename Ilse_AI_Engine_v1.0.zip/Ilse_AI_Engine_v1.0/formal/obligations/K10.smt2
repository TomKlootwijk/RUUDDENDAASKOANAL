; K10: Near-side reflection distance comparison
; Manuscript: T7. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const x Real)
(declare-const u Real)
(assert (not (=> (and (>= x 0) (>= u 0)) (<= (* (- x u) (- x u)) (* (+ x u) (+ x u))))))
(check-sat)
(get-proof)
