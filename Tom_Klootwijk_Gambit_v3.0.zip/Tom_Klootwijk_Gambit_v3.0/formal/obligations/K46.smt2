; K46: Endpoint difference bounds a minimum inter-switch time
; Manuscript: L18. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const d Real)
(declare-const L Real)
(declare-const dt Real)
(assert (not (=> (and (> d 0) (> L 0) (>= dt 0) (<= (* 2 d) (* L dt))) (>= dt (/ (* 2 d) L)))))
(check-sat)
(get-proof)
