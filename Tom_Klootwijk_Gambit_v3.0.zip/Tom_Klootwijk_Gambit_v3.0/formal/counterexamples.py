"""Run constructive SAT witnesses separately from the UNSAT proof obligations."""
from pathlib import Path
import json
import re
import sys
sys.path.insert(0,str(Path(__file__).parent))
from check import library_runner
ROOT=Path(__file__).resolve().parents[1]
CASES=[('X01','Occupancy does not give an autonomous next-state law', '''
(declare-const x Real) (declare-const y Real)
(assert (= x (- 2))) (assert (= y (- (/ 1 2))))
(assert (and (<= x 0) (<= y 0)))
(assert (distinct (<= (+ x (/ 3 4)) 0) (<= (+ y (/ 3 4)) 0)))
'''),('X02','A field minimum does not automatically bridge separated components', '''
(declare-const dot_distance Real) (declare-const stem_distance Real)
(assert (= dot_distance (/ 2 5))) (assert (= stem_distance (/ 1 4)))
(assert (> (ite (< dot_distance stem_distance) dot_distance stem_distance) 0))
'''),('X03','Equal sign bits do not identify a scalar distance', '''
(declare-const f Real) (declare-const g Real)
(assert (= f 1)) (assert (= g 2))
(assert (= (<= f 0) (<= g 0))) (assert (distinct f g))
''')]
def main():
    # Same official C-library adapter as the proof runner. Optional Z3 required.
    import shutil,subprocess
    exe=shutil.which('z3')
    if exe:
        version=subprocess.check_output([exe,'-version'],text=True).strip()
        def run(text):return subprocess.check_output([exe,'-in'],input=text,text=True,timeout=20)
    else:run,version=library_runner()
    target=ROOT/'formal/counterexamples';target.mkdir(exist_ok=True)
    logs=ROOT/'results/counterexamples';logs.mkdir(exist_ok=True)
    reports=[]
    for id,title,decl in CASES:
        text=f'; {title}\n(set-logic ALL)\n'+decl+'\n(check-sat)\n(get-model)\n'
        (target/(id+'.smt2')).write_text(text)
        output=run(text);(logs/(id+'.model.txt')).write_text(output)
        ok=bool(re.search(r'^sat\s*$',output,re.M)) and '(error' not in output
        reports.append({'id':id,'title':title,'expected':'sat','passed':ok})
    doc={'solver_version':version,'cases':reports,'passed':all(r['passed'] for r in reports)}
    (ROOT/'results/counterexample_results.json').write_text(json.dumps(doc,indent=2)+'\n')
    print(json.dumps(doc,indent=2))
    return 0 if doc['passed'] else 1
if __name__=='__main__':sys.exit(main())
