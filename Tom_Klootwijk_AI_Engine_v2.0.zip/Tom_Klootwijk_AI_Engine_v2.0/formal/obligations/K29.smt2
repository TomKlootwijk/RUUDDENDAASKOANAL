; K29: Fixed-point one-step error telescopes
; Manuscript: L9. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const D Int)
(declare-const r Int)
(declare-const k Int)
(declare-const q Int)
(declare-const rn Int)
(assert (not (=> (= rn (- (+ r k) (* D q))) (= (- (* D q) k) (- r rn)))))
(check-sat)
(get-proof)
