"""Build editable reading and theorem/proof editions from the authoritative TeX.

Requires Pandoc. Run build.sh first to resolve equation references. PDF typography
and numbering remain authoritative. This script does not alter mathematical laws.
"""
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
STEM = 'Tom_Klootwijk_Gambit_Edition_3.0'


def main() -> None:
    src = (HERE / f'{STEM}.tex').read_text(encoding='utf-8')
    start = src.index(r'\begin{titlepage}')
    stop = src.index(r'\end{titlepage}') + len(r'\end{titlepage}')
    src = src[:start] + src[stop:]
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)
        tex = folder / 'reading.tex'
        tex.write_text(src, encoding='utf-8')
        lua = folder / 'plain.lua'
        lua.write_text('function Emph(el) return el.content end\n', encoding='utf-8')
        result = subprocess.run(
            ['pandoc', str(tex), '-f', 'latex', '-t', 'markdown', '--wrap=none',
             '--lua-filter', str(lua)], check=True, capture_output=True, text=True)
        text = result.stdout
    text = re.sub(r'\*\*Unified Theorem (?:U)?\d+\*\*', '**Unified Theorem U3**', text)
    text = re.sub(r'\*\*Lemma (?:L)?(\d+)\*\*', r'**Lemma L\1**', text)
    text = re.sub(r'^:::[^\n]*\n', '', text, flags=re.M)
    text = re.sub(r'\{width="[^"\n]*"\}', '', text)
    text = re.sub(r'(\]\(figures/[^)\s]+)\.pdf\)', r'\1.png)', text)
    text = text.replace('{.sans-serif}', '')
    text = re.sub(r'\[\*\*\\\[([SDTHIUE])\\\]\*\*\]', r'**[\1]**', text)
    text = re.sub(r'\{reference-type="[^"]*" reference="[^"]*"\}', '', text)
    aux = HERE / '_build' / f'{STEM}.aux'
    if aux.exists():
        for key, val in re.findall(r'\\newlabel\{(eq:[^}]+)\}\{\{([^}]+)\}', aux.read_text()):
            pattern = r'\[\\\[' + re.escape(key) + r'\\\]\]\(#' + re.escape(key) + r'\)\{[^}]*\}'
            text = re.sub(pattern, '(' + val + ')', text)
    header = '''# Tom Klootwijk Gambit
## Unified Seed–Field Theorem and Theory of Consciousness — Edition 3.0

**Author: Tom Klootwijk**  
**NL200678942 · 10-07-1990**  
Kernel 3.0.0 · 11 September 2026

> Editable reading edition. The LaTeX/PDF version controls typography and equation numbering. This private author-attributed research manuscript includes the personal details supplied by the requester. Mathematical statements, model choices, source accounts and interpretations retain their separate status labels.

'''
    text = header + text
    (HERE / f'{STEM}.md').write_text(text, encoding='utf-8')
    sections = [
        ('The Gambit unified seed--field theorem', 'Eighteen supporting lemmas and proofs', 'UNIFIED_THEOREM_U3.md'),
        ('Eighteen supporting lemmas and proofs', 'Consciousness across bodily, digital and spiritual domains', 'SUPPORTING_PROOFS.md'),
        ('Consciousness across bodily, digital and spiritual domains', 'Executable kernel and recorded verification', 'CONSCIOUSNESS_AND_INTERPRETATION.md'),
        ('Research tests and extension gates', 'Source-to-formalization audit', 'RESEARCH_PROTOCOLS.md'),
    ]
    for begin, end, name in sections:
        a = text.index('# ' + begin)
        b = text.index('# ' + end, a + len(begin))
        prefix = '**Tom Klootwijk Gambit · Edition 3.0 / Kernel 3.0.0**  \n**Author: Tom Klootwijk · NL200678942 · 10-07-1990**\n\n'
        part = text[a:b]
        (HERE.parent / 'docs' / name).write_text(prefix + part + '\nSee the full manuscript for definitions, source audit and verification limits.\n', encoding='utf-8')
    print('Created Markdown reading edition and four thematic extracts.')


if __name__ == '__main__':
    main()
