; K42: Middle-band classification survives a strict error margin
; Manuscript: L18. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(declare-const d Real)
(declare-const e Real)
(define-fun ab ((x Real)) Real (ite (>= x 0) x (- x)))
(assert (not (=> (and (> d 0) (>= e 0) (> a (+ (- d) e)) (< a (- d e)) (<= (ab (- a b)) e)) (and (> b (- d)) (< b d)))))
(check-sat)
(get-proof)
