; K11: Reflection preserves squared Euclidean norm
; Manuscript: T8. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const x Real)
(declare-const y Real)
(assert (not (= (+ (* (- x) (- x)) (* y y)) (+ (* x x) (* y y)))))
(check-sat)
(get-proof)
