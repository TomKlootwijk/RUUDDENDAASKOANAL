# Tom Klootwijk Gambit
## Unified Seed–Field Theorem and Theory of Consciousness — Edition 3.0

**Author: Tom Klootwijk**  
**NL200678942 · 10-07-1990**  
Kernel 3.0.0 · 11 September 2026

> Editable reading edition. The LaTeX/PDF version controls typography and equation numbering. This private author-attributed research manuscript includes the personal details supplied by the requester. Mathematical statements, model choices, source accounts and interpretations retain their separate status labels.

# Abstract and author statement {#abstract-and-author-statement .unnumbered}

This final Gambit edition consolidates the earlier seed--field revisions and executable composition kernel with the supplied forty-eight-page Gambit corpus. The engine and theory are attributed to **Tom Klootwijk**, with the supplied identifier **NL200678942** and date string **10-07-1990**. These are documentary author details, not identity verification, a priority ruling or a physical parameter. The standard component mathematics is not claimed as a new invention.

The formal result is **Unified Theorem U3**, supported by **eighteen lemmas and written proofs**. A complete seed specifies parallel L-system growth, geometric boundary fields, finite conservative transport, reactions, observations, binary hinges, recurrent activity, memory and an integer one-bit codec. The theorem establishes deterministic accepted finite histories, sign-correct geometric set semantics, nonnegative conserved model mass, bounded recurrent and memory states, and an exact dyadic prefix certificate. Hysteretic latches now causally control a permeability-like gate, while all required continuous-valued state remains explicit.

The decisive Gambit extension is an exact reduction criterion: a candidate binary or multi-bit representation is sufficient precisely when states with the same encoding have the same declared outputs and the same next encoded state for every common input. This is proved as a necessary-and-sufficient condition and implemented by a finite-state checker. A successful two-state quotient and a constructive failure example make the distinction between a reusable one-bit operation and a complete one-bit model explicit.

The corpus's Word, Christian interpretation, V/hourglass, quintessence and infinite-field language is preserved in a separate interpretation record. The final question about $\Sigma$ as a set receives an explicit notation migration: $\Sigma$ is the alphabet set, $\mathfrak S$ the admissible seed family, and $\sigma\in\mathfrak S$ a complete structured seed. A tagged set can faithfully encode such a record; an untagged set that erases order and multiplicity cannot.

The supplied conversations include inconsistent roots and unsupported biological, typographic and physical assertions. A page-specific audit identifies source wording, formal choices, retained hypotheses and mathematical counterexamples. Limited external checks are marked separately. No biological, neural, clinical or hardware observations are invented.

The delivered execution record contains **145 passing regression tests**, **46 UNSAT algebraic counterexample queries** with Z3 proof logs, and **three SAT witnesses** to overstrong claims. The finite quotient example checks **508 histories**. These results concern the specified code and mathematical targets; the full theorem is not a proof-assistant refinement proof of every floating-point execution, and the traces are not empirical proof of consciousness.

**Research hypothesis:** history-dependent coupling among generated boundaries, material processes, modality-specific observations, recurrent internal activity and memory may explain aspects of conscious organization. The theorem establishes properties of the proposed model. It does not establish that the model is conscious, that its variables are sufficient for consciousness, or that a scalar distance field is identical to bodily, digital or spiritual reality.

**Reading key.** **[S]**  source account; **[D]**  definition or explicit modeling choice; **[T]**  proved mathematical consequence under assumptions; **[H]**  empirical hypothesis; **[I]**  interpretation; **[U]**  unsupported by the supplied evidence; **[E]**  separately identified external context.

**Suggested route.** Sections 2--5 define the inherited seed, geometry and material laws. Section 6 adds the Gambit hinge and reduction question. Section 7 states U3; Section 8 gives its supporting proofs. Sections 9--11 distinguish consciousness and interpretation, recorded execution, and research tests. Appendix A records the source dispositions.

# Corpus, continuity and the revised claim

## The revision and source record

\@lY@ Record & Role in this edition\
C0 & Original supplied Markdown conversation: the SDF/operator chain, log-polar lookup, parity, IPD/ITD, photonic proposals, cell and memory analogies.\
C1 & Original 28-page seed--field research manuscript: complete seeds, L-systems, metric distinctions, event-time normalization and empirical limits.\
C2 & Twelve-page double-arc addendum: paired arcs, shared baseline, clipping, hinge, coordinate lookup and perceptual narratives.\
C3 & Intermediate 25-page theorem-and-kernel revision: symbolic $XX/XY$ seeds, eighteen component theorems, geometry utilities, recurrence and verification infrastructure.\
C4 & Earlier eighteen-page author-named corpus: word operators, paired curves, reaction--diffusion, membranes, remeshing, closed-system claims and ambient infinite axes.\
C5 & Edition 2.0 manuscript and kernel: the unified composition theorem, twelve supporting lemmas and executed transport/memory examples.\
C6 & New forty-eight-page Gambit corpus: the earlier conversation plus latching universality, typography, Christian interpretation, quintessence and the final set/seed question.\

C0, C1, C2, C4, C5 and C6 are archived as source records. C3's supplied PDF and ZIP are hash-referenced in the provenance manifest; the alternate branding is not the title or authorship of this edition. C5's 99-test suite was re-executed before adaptation and passes again in the 3.0 package. The final results reported here are from new executions, not inherited test-count claims. Opaque file aliases in the source conversations are not treated as independently available evidence.

## Preserving the corpus's conceptual progression

**[S]**  C4 starts with "parings", then paired S-curves, $S$, $T$, a double mirrored arch and competing DNA, cryptographic and scanning-tunneling interpretations (pp. 1--7). It links this to KSFF, L-system words and capsule fields (pp. 7--9), then to chiral symbols and narrative interpretation (pp. 9--12). It introduces fertilization and $XX/XY$ language (p. 12), develops reaction--diffusion and masked Laplacians (pp. 13--15), and finally discusses genetic editing, membranes, conservation, ambient vectors and log-radius infinity (pp. 15--18).

C6 repeats and extends that progression. Its later sections add the typographic `i`/`I` interpretation (pp. 30--31), journey and Christian IT language (pp. 32--38), the universal-latch discussion and its competing qualifications (pp. 38--43), and quintessence, polarity and $\Sigma$ (pp. 44--48). The table on C6, p. 40, separately names geometric, chemical, electrical and quantum categories, yet places a Walsh--Hadamard memory matrix in its quantum row without supplying a Hamiltonian, state preparation or measurement law. That visual table is source framing, not physical validation. The plotted curve on p. 5 is similarly not an STM dataset or a cryptographic-pairing computation.

This progression is the basis of the present formalization. Its individual statements have different evidential status. The assistant responses reproduced in the corpus are not experiments, and repeated agreement is not a proof. In particular, a source reference to the earlier engine does not establish that the referenced engine already implemented the later reaction--diffusion claims.

**[D]**  This edition preserves the pipeline while introducing the missing contracts: the alphabet and interpreter; a geometric metric; the field's sign convention; control-volume closure; transport and reaction laws; a positive numerical step; conservative mass transfer under changed geometry; a bounded memory update; and a distinction between analog input, dyadic input, pulse output and parity metadata. Each added choice is visible in the configuration or versioned code.

## What is unified, and what is not identified

The unification is compositional: different mathematical objects have compatible input and output types. A word is not a concentration. A concentration is not a distance. An orientation determinant is not a parity checksum. A genome is not the two-character label $XY$, and a personal identifier is not a numerical seed.

The proposed consciousness account uses the whole history-dependent loop as an explanatory unit. It is not the proposition that one arc, one bit, one membrane crossing or one matrix transform independently explains subjective experience. A theory can be mathematically precise while its physical interpretation remains a hypothesis.

# The complete seed and its word operators

## Alphabet sets, the seed family and an individual seed

**[D]**  To settle the notation question in C6, pp. 47--48, define $$\Sigma=\{X,Y,+,-,[,]\},\qquad \sigma\in\mathfrak S_N,$$ where $\Sigma$ is a set of symbols, $\Sigma^*$ the set of finite words, and $\mathfrak S_N$ the set of complete specifications admissible for $N$ accepted steps. A particular complete seed is the structured record $$\sigma=(\mathcal S,\mathcal G,\mathcal Q,\mathcal R,\mathcal X_0,
 \mathcal E,\mathcal H,\mathcal C,\mathcal V,\mathcal B),$$ with $\mathcal S=(\Sigma,p,w_0,P,\mathcal I,\Theta)$ and $\mathcal X_0=(\mu_0,z_0,m_0,b_0,r^{(c)}_0)$. Here $p$ is the ordered pair, $w_0$ the axiom, $P$ the parallel grammar, $\mathcal I$ the interpreter and $\Theta$ the geometric parameters. $\mathcal G$ specifies the grid and remap; $\mathcal Q$ transport and gates; $\mathcal R$ reactions. Initial values include chemical mass $\mu_0$, fast state $z_0$, memory $m_0$, latch bits $b_0$ and codec residual $r^{(c)}_0=0$. $\mathcal E$ fixes input/probe laws and pseudorandom conventions; $\mathcal H$ fixes hinge thresholds, tie rules and feedback. $\mathcal C$ records coding; $\mathcal V$ implementation and arithmetic; $\mathcal B$ finite budgets.

This notation explicitly supersedes the use of capital $\Sigma$ for the complete seed tuple in earlier revisions. Nothing about the letter itself forces either a tuple or a set. A record can equivalently be encoded as a set of uniquely tagged field/value pairs; L13 shows why this preserves the record while an untagged set can lose information. The operator family $\{\tau_w:w\in\Sigma^*,\ w\text{ is interpretable}\}$ is another set, but it is not identical to the alphabet or the set of all possible distance fields.

The archive's schema lists alphabet, grammar, model parameters and hinge parameters explicitly. Changing document labels does not alter these laws. A random integer alone does not specify the complete seed; a one-bit selector chooses between two fully predefined seeds only when all shared structure is already supplied. Source-code hashes and realized-matrix fingerprints record the computational specification. They do not establish scientific truth or a person's identity.

## Symbolic pairings and growth

**[D]**  Use $\Sigma=\{X,Y,+,-,[,]\}$ with $$P(X)=X[+X]Y,\qquad P(Y)=Y[-Y]X,$$ and identity productions on brackets and turns. For $p=(a,b)\in\{X,Y\}^2$ set $$w_0(p)=[a][b],\qquad w_g=P^g(w_0).$$ Every production at a generation is applied to the old word in parallel. It is not repeated substitution into newly generated symbols during the same generation. This is a stipulated grammar inherited from C3, not a DNA sequence or a law of human development. Parallel rewriting and turtle interpretation are standard L-system constructions; that outside mathematical context does not validate this grammar biologically. [\[C3, Sec. 2; E1\]]

Both $X$ and $Y$ emit a forward segment. The $+$ and $-$ tokens turn by $\pm\delta$. A bracket saves or restores pose; the step at stack depth $d$ is $\ell\beta^d$. The complete default interpreter uses $\ell=0.12$, $\delta=\pi/7$, $\beta=0.72$, upward initial heading and the embedding $(x,y)\mapsto(x,y+0.10)$. The retained embedding scale is explicitly $1.0$, rather than silently inheriting the smaller intermediate demonstrator scale.

Define $e(X)=0$, $e(Y)=1$, $q(a,b)=e(a)\oplus e(b)$, and $\kappa(a,b)$ as the sorted pair. The ordered records $XY$ and $YX$ remain different seeds even though their canonical pair and parity coincide. The optional mixing function draws one token from each pair under four equally weighted draws. It is a symbolic sampling law; it does not model fertilization or infer a person's characteristics.

## The meaning of "all words as SDF operators"

**[S]**  C4, pp. 8--9, asks whether the L-system operator is the set of operators of all words as SDF notation. The mathematically supported connection is a composition of maps, not an identity of those objects: $$\Sigma^* \xrightarrow{P} \Sigma^*
\xrightarrow{\mathcal I_{\Theta}} \mathsf{Geometry}
\xrightarrow{\mathcal D} \mathsf{BoundaryFields}.$$ $\Sigma^*$ is the set of finite words. The rewrite operator $P$ acts on words. Each interpreted token acts on a turtle state with pose, stack and emitted primitives. If $\tau_w$ denotes that state transformation, then $$\tau_{uv}=\tau_v\circ\tau_u$$ where both sides are defined. The interpreter has a domain condition: unmatched brackets or unknown tokens are invalid. Concatenation preserves state-transform composition; it is not generally addition, minimum or multiplication of scalar distance functions.

The generated field family is $$\mathcal F_{\sigma}=\{\mathcal D(\mathcal I_{\Theta}(P^g(w_0))):g\leq g_{\max}\}.$$ It is a specified family, not the class of all possible SDFs, words, organisms or conscious states. Distinct words may emit overlapping geometry. Distinct seeds can consequently have the same sampled mask or output, as the included initial $XX/XY$ example demonstrates.

![The declared $XX$ grammar at generation four. The zero contour bounds the union of the two arc strokes, baseline and interpreted capsules after ground clipping. This is simulated geometry, not a chromosome, neural structure or recorded biological growth.](figures/geometry_xx.png)

# Ambient space, local fields and coordinate hinges

## Infinite axes without eliminating coordinates

**[D]**  A coordinate-independent starting point is a Riemannian manifold $(M,g)$ with vector field $v_t\in\Gamma(TM)$. The reference implementation uses the unbounded Euclidean ambient space $M=\mathbb{R}^2$ and its ordinary metric. Local geometry may select a material region $\Omega_t\subset M$ without creating $M$ or creating its vector field. This preserves the final emphasis of C4, pp. 17--18: local hinges and boundaries are not the whole ambient space.

A vector field assigns a tangent vector to each relevant point. It is not itself an axis. An axis is a chosen direction or a coordinate line; an eigenvector additionally requires a specified operator $A$ and a relation $Av=\lambda v$. A direction does not become an eigenvector solely by being used for sound localization. No physical attenuation law follows from the eigenvalue of an unspecified frame matrix.

The numerical model uses a finite window $B\subset M$ and a grid in that window. The field and ambient velocity law have mathematical definitions outside it, but the software does not represent infinitely many coordinates or infinite resolution. The requested "infinity as axis" is retained as ambient domain and limiting behavior, not as an assertion that finite memory computes an infinite object exactly.

## Capsule and double-arc boundary fields

For a segment from $a_j$ to $b_j$ with radius $r_j>0$, define $$\begin{aligned}
\lambda_j(x)&=\operatorname{clamp}_{[0,1]}
\frac{(x-a_j)\cdot(b_j-a_j)}{\left\lVert b_j-a_j\right\rVert^2},\\
d_j(x)&=\left\lVert x-a_j-\lambda_j(x)(b_j-a_j)\right\rVert-r_j.
\end{aligned}$$ When $a_j=b_j$, use $d_j(x)=\left\lVert x-a_j\right\rVert-r_j$. The nondegenerate expression is the signed distance of a capsule. The composite $$F_G(x)=\min_j d_j(x),\qquad \Omega_G=\{x:F_G(x)\leq0\}$$ represents the exact union membership. Its negative values need not be exact distances to the boundary of an overlapping union. This distinction, already present in the revised manuscripts, must not be erased by C4's repeated use of "exact SDF" for the entire composite. [\[C1; C3; C4, pp. 9, 13--14\]]

For the addendum's arches, use centerline $$A=\{R(\sin\theta,\cos\theta):|\theta|\leq\alpha\},\quad
A_{\pm}=A\pm(h,0),\quad 0<\alpha\leq\pi/2.$$ Let $B_0$ be the horizontal segment from $(-h-R,0)$ to $(h+R,0)$. Using unsigned centerline distances $d_A,d_{B_0}$, the clipped stroke field is $$F_M(x)=\max\{\min[d_{A_-}(x)-r,\ d_{A_+}(x)-r,
 d_{B_0}(x)-r],-y\}.$$ The default combined engine field is $$F_{g,m}(x)=\max\{\min[F_M(x;m),F_{G_g}(x)],-y\},\qquad
r(m)=r_*+\gamma\tanh(m_1),\quad r_*>|\gamma|.$$ The finite word and fixed memory state determine this field. The half-space uses the convention "inside at zero". It clips to $y\geq0$; it does not by itself create a Klein bottle or a physical membrane.

The addendum's coordinate fold $x\mapsto |x|-h$ is not used as an unconditional replacement for an explicit union. It is valid under a suitable lateral-containment condition, such as $h\geq R\sin\alpha$. Outside that regime the nearest branch can be the apparently farther arc. The code retains the fold only as a comparison routine and tests a counterexample. [\[C2, pp. 1--3; C3, T7\]]

## Reflection, chirality and sign are different operations

Let $J=\operatorname{diag}(-1,1)$ and let $R_\theta$ be the usual planar rotation. Then $J^2=I$, $\det J=-1$, $\det R_\theta=1$, and $$JR_\theta J=R_{-\theta}.$$ These identities formalize the paired rotor language as geometry. For a reflected set $J\Omega$, its distance field obeys $d_{J\Omega}(Jx)=d_\Omega(x)$: reflection does not change inside into outside. A symmetric double-arc field satisfies $F_M(Jx)=F_M(x)$, so its occupancy bit is preserved rather than flipped.

The field sign, orientation sign, geometric set difference and payload parity therefore require separate variables. A $45$-degree rotation is still an isometry. C4's claims that historical symbolism or such a rotation mathematically forces constructive or destructive dynamics are not consequences of these equations. This is a limitation of the geometric inference, not a historical theory. [\[C4, pp. 9--11\]]

The circle centers $(\pm h,0)$ satisfy intersecting-circle equations $x=0$, $y^2=R^2-h^2$. When $h=R$, their tangency point is $(0,0)$, not $(0,R)$. A tangent contact or a nondifferentiable minimum need not be a sign-changing crossing, a quantum event or a topological singularity. The addendum's hinge diagram and its stated coordinate are audited separately. [\[C2, pp. 8--9\]]

## The logarithmic radial axis and its metric

For reference length $r_0>0$, the log-polar representation of the punctured plane is $$\rho=\log(r/r_0),\quad \theta\in S^1,\qquad
x=r_0e^\rho(\cos\theta,\sin\theta).$$ Thus $\rho\in\mathbb{R}$ corresponds to $r\in(0,\infty)$; $r\downarrow0$ means $\rho\to-\infty$, and $r\to\infty$ means $\rho\to\infty$. The origin is not a finite coordinate of this chart. The angular seam is a representation choice; $S^1$ is not an interval with unrelated endpoints.

The Euclidean metric pulls back to $$ds^2=r_0^2e^{2\rho}(d\rho^2+d\theta^2).$$ Consequently, a Euclidean distance field evaluated through the inverse chart is a scalar field with the same membership semantics; it is not generally an exact distance in the flat $(\rho,\theta)$ metric. Coordinate compression does not prove perceptual calibration, physical time dilation or infinite near-origin numerical detail.

The optional lookup table stores sampled Cartesian field values on a finite annulus. For a 1-Lipschitz field and convex bilinear weights $w_j$, its query error is bounded by $$\left|\sum_jw_jF(p_j)-F(p)\right|
\leq\sum_jw_j\left\lVert p_j-p\right\rVert\leq\max_j\left\lVert p_j-p\right\rVert.$$ The numerical kernel rejects queries outside the chart domain. It does not replace an origin singularity with an unannounced epsilon and call the result an exact chart. A Klein-bottle quotient would need explicit identifications and metric compatibility; it is not implemented in the present engine.

# Paired time roots: preserving both corpus variants

## The polynomial actually determines the roots

**[S]**  C0 and the original normalized event example use $\sin^2\theta$ in the second factor. C4, p. 8, prints $\sin^2(\theta/2)$ in that factor but gives a root with denominator $\sin\theta$. C4, p. 6, also reproduces earlier differently scaled exponential envelopes. These are not one consistent equation.

**[D]**  Preserve the two explicit polynomial variants as $$\label{eq:toy}
F_\kappa(\rho,\theta)=
\left[\rho^2-\cos^2(\theta/2)\right]
\left[\rho^2\sin^2(\kappa\theta)-\phi_-^2\right],
\quad \kappa\in\{1,\tfrac12\},$$ where $\phi_-=(\sqrt5-1)/2$ is dimensionless. $F_\kappa$ is an auxiliary implicit polynomial, not the capsule-union SDF $F_G$, not an established Klein-bottle equation, and not an experimentally determined biological surface.

For a fixed angle and $\sin(\kappa\theta_0)\ne0$, the algebraic radial roots are $$\rho_{1,\pm}=\pm\cos(\theta_0/2),\qquad
\rho_{2,\pm}=\pm\frac{\phi_-}{\sin(\kappa\theta_0)}.$$ These are sets of candidate roots with multiplicities; coincidences need not yield four distinct events. At exact $\sin(\kappa\theta_0)=0$, the second factor is the nonzero constant $-\phi_-^2$, and its finite roots are absent.

## Dimensionally consistent event time

Declare a radial path $r(t)=c_s(t-t_0)>0$, with $c_s$ in length/time and $r_0$ in length. Substitution gives $$\label{eq:times}
T_{j,\pm}=t_0+\frac{r_0}{c_s}\exp(\rho_{j,\pm}).$$ The exponent is dimensionless. A factor with dimensions of inverse speed cannot be inserted into the exponent unless an additional normalization has been explicitly defined. The reciprocal symmetry is in normalized delay: $$\tau_{j,\pm}=\frac{c_s(T_{j,\pm}-t_0)}{r_0},\qquad
\tau_{j,+}\tau_{j,-}=1.$$ Thus the branches mirror in log time; they are not automatically reflected across an ordinary linear time baseline. The "double mirrored arch" phrase can describe this representation, but does not make a DNA helix, membrane crossing or all physical time an immutable geometric arch.

The root API retains log-delay when exponentiation overflows or underflows. It distinguishes an exact zero denominator from a near-singular unresolved denominator. For general moving fields, solve $f(t)=F(x(t),t)=0$ with a justified bracket or another specified method. Bisection bounds the error after $n$ halvings by the retained half-width; sign sampling alone does not find all tangencies. Where derivatives exist, $$\frac{d}{dt}F(x(t),t)=\nabla_xF\cdot\dot x+\partial_tF.$$ No zero-latency hardware event follows from a mathematical root. The reference growth trigger is a sampled concentration predicate; the auxiliary polynomial roots are diagnostic queries and are not silently used as fertilization times or growth laws.

# Reaction, diffusion and the membrane-like graph

## The continuous template and its closure assumptions

**[S]**  C4, pp. 13--14, proposes an L-system-generated spatial region carrying reaction--diffusion with advection: $$\label{eq:pde}
\partial_t c_k+\nabla\cdot(c_kv)=D_k\Delta c_k+\mathcal R_k(c).$$ **[D]**  This equation needs a domain, initial state, reaction law, flux convention, units and boundary motion. A specified geometry alone does not determine those quantities. Write material flux $J_k=c_kv-D_k\nabla c_k$. For a fixed closed domain, require $J_k\cdot n=0$. With advection present, $\nabla c_k\cdot n=0$ alone is not enough unless the normal advective flux also vanishes.

For a moving boundary with velocity $w$, the no-transfer condition relative to that boundary is $(J_k-c_kw)\cdot n=0$. Reynolds transport then gives, for conserved weights $\ell_k$, $$\frac{d}{dt}\int_{\Omega(t)}\sum_k\ell_k c_k\,dx
=\int_{\Omega(t)}\sum_k\ell_k\mathcal R_k(c)\,dx
-\int_{\partial\Omega(t)}\sum_k\ell_k(J_k-c_kw)\cdot n\,dS.$$ Conservation follows only after the right-hand side is controlled. An open membrane, external feeding or a nonconservative reaction gives an explicit source term instead. This is a declared model boundary condition, not a proof that the universe or a living organism is a closed system. [\[C4, pp. 16--17\]]

## Finite masked diffusion without invented smooth normals

Let $V_h$ be grid nodes within the simulation window, $h$ the spacing, and $$I_n=\{i\in V_h:F_{g_n,m_n}(x_i)\leq0\}$$ the active mask used at that update. For undirected active-neighbor conductances $w_{ij}=w_{ji}\geq0$, define $$(L_hc)_i=\sum_{j\sim i}w_{ij}(c_j-c_i).$$ With $w_{ij}=1/h^2$, a node with four interior neighbors has the standard five-point stencil. Removing exterior edges changes the diagonal from $-4/h^2$ to minus the sum of the retained weights. This is the precise finite counterpart of the corpus's "return the removed coefficient to the diagonal" instruction.

It yields zero graph flux across absent edges, exact row and column sums of zero in real arithmetic, and no need to evaluate $\nabla F/\left\lVert \nabla F\right\rVert$. The latter expression can fail at ties, corners or zero gradients of a composite field. A staircase graph boundary is not the exact curved-boundary Neumann problem, and no continuum convergence rate is asserted without a separate analysis.

## Ambient swirl, gates and directed transport

The implemented ambient field is the illustrative law $$v(x,y)=\omega(-y,x),\qquad (x,y)\in\mathbb{R}^2.$$ It exists independently of $I_n$. At an edge $i\to j$, use the upwind rate $$a_{i\to j}=g_{ij}\left[\frac{D}{h^2}+
\max\left(\frac{v((x_i+x_j)/2)\cdot(x_j-x_i)}{h^2},0\right)\right].$$ The interface gate $g_{ij}\in[0,1]$ multiplies rates on edges crossing $x=0$; elsewhere it is one. In the inherited memory-dependent base-gate law, $$g_{ij}=g_*+\gamma_g\tanh(m_2),\quad
0\leq g_*-|\gamma_g|\leq g_*+|\gamma_g|\leq1.$$ Edition 3.0 additionally multiplies crossing-edge gates by the causal latch factor in Eq. [\[eq:gambitgate\]](#eq:gambitgate). This is a formal permeability-like control, not a physical identification of a molecular valve with a vortex. The corpus does not supply the molecular variables or measurements needed for that identity.

Use a column generator $Q$ on node masses: $Q_{ji}=a_{i\to j}$, $Q_{ii}=-\sum_{j\ne i}a_{i\to j}$. Thus off-diagonal entries are nonnegative and $\mathbf{1}^TQ=0$. Suppressing exterior edges is a declared closed graph boundary. In a general directed graph, a uniform concentration need not remain uniform even though total mass is conserved; this must not be confused with the symmetric diffusion-only case.

## Positive transport, reactions and domain changes

Let $\mu_i=V_i c_i$ be represented mass; the reference grid uses equal areas $V_i=h^2$. For a substep $\delta t$ satisfying $$\delta t\max_i(-Q_{ii})\leq1,$$ $P_Q=I+\delta t Q$ is nonnegative and column-stochastic. The implementation substeps to a stricter target of $0.9$. It applies the nonnegative sparse transition matrix directly and does not conceal a negative concentration by clipping it to zero.

The reference reaction is reversible conversion $U\rightleftarrows V$ with rates $a,b\geq0$ and equal conserved simulation-mass units: $$\begin{pmatrix}u'\\v'\end{pmatrix}
=\begin{pmatrix}1-\delta t a&\delta t b\\
\delta t a&1-\delta t b\end{pmatrix}
\begin{pmatrix}u\\v\end{pmatrix},\qquad
\delta t\max(a,b)\leq1.$$ This local matrix is also column-stochastic. Other reactions require new positivity, stoichiometry and balance conditions; periodic-table language alone does not specify them.

If memory or growth changes the domain, old mass must not simply be discarded. Define a remap $\Pi_n$ from old active nodes to new active nodes with $$(\Pi_n)_{ij}\geq0,\qquad \mathbf{1}^T\Pi_n=\mathbf{1}^T.$$ For unequal cell volumes the concentration rule is $c'=V_{n+1}^{-1}\Pi_nV_nc$. The reference rule keeps mass on retained nodes and transfers removed-node mass to the nearest new active node; exact numerical ties use the smallest node index. Newly activated nodes start with zero mass unless receiving this transfer. This can concentrate material and is not a high-order moving-boundary solver. It is a simple, explicit mass-conserving policy. Empty domains are rejected rather than assigned an invented destination.

## The growth trigger and step ordering

At a stored graph-boundary node, define $\chi_i=u_i/(u_i+v_i)$ when the denominator is positive and zero otherwise. The growth score is the maximum $\chi_i$ on those nodes. A rewrite is permitted when that score meets or exceeds the seed threshold, the minimum dwell count has elapsed and the generation budget has not been exhausted. It executes once, not infinitely often at a threshold.

One step proceeds as follows: evaluate the growth predicate on the stored state; choose the current generation; compile its memory-dependent field; remap the old mass into the new mask; apply positive transport and local reaction; compute bounded observations; update fast state and memory; sample and store the new hinge bits; encode a pulse and frame parity; store the new mask and state. In Edition 3.0 the incoming hinge bit also scales the current transport gate. The newly updated memory is used in the next compilation. This explicit one-step ordering resolves the otherwise ambiguous simultaneous feedback in the conversational account. It is a model choice, not an observed biochemical clock.

# Gambit: the latching hinge and exact binary reduction {#sec:gambit}

## The operational and the stronger readings

**[S]**  The Gambit corpus intensifies the earlier proposal. It asks whether the same one-bit latching hinge underlies otherwise different forms, with molecules and structures forming around that operation (C6, pp. 38--42). It also asks whether an initial "Word" is one bit, how a field can be understood as quintessence, and whether $\Sigma$ denotes a set (pp. 34--35, 44--48).

**[D]**  Edition 3.0 gives the hinge an actual executable role. A common binary operation may be reused at many sites and times while the complete system retains geometric, material and memory states. This is different from the stronger assertion that the entire evolving system has only two possible states. A network of $k$ bits already has $2^k$ configurations; a bitstream additionally uses order, timing and a decoder. Neither a single operation type nor a one-bit channel is automatically a complete physical theory.

The operational reading is implemented below. The stronger reading becomes an exact mathematical question: which state distinctions can be discarded without changing any declared future observation? This question is the reduction clause of the unified theorem, rather than an assumption hidden inside the word "unified".

## A causal, hysteretic binary hinge

For each of three prescribed probes, store a bit $b_{n,\ell}\in\{0,1\}$. Use a strictly positive threshold $\delta_h$ and the current field sample $$s_{n,\ell}=F_{g_{n+1},m_n}(p_{n,\ell}).$$ The generation index denotes the generation selected at the start of this update; the memory is still the incoming memory. Define $$\label{eq:latch}
 b_{n+1,\ell}=\mathcal H_{\delta_h}(s_{n,\ell},b_{n,\ell})=
 \begin{cases}
 1,&s_{n,\ell}\leq-\delta_h,\\
 0,&s_{n,\ell}\geq\delta_h,\\
 b_{n,\ell},&-\delta_h<s_{n,\ell}<\delta_h.
 \end{cases}$$ The transition event is $e_{n,\ell}=b_{n+1,\ell}\oplus b_{n,\ell}$. The raw occupancy predicate $o_{n,\ell}=\mathbf{1}[s_{n,\ell}\leq0]$ is exported separately. At $s=0$, occupancy is one by convention, but the hysteretic latch retains its prior bit and has no transition. Zero is a boundary value, not a third bit and not a proof of a physical state collapse.

Incoming latch $b_{n,1}$ controls the crossing-edge multiplier $$\label{eq:gambitgate}
 \lambda_n=\lambda_{\min}+(1-\lambda_{\min})b_{n,1},\qquad
 g_{ij,n}=\bigl[g_*+\gamma_g\tanh(m_{n,2})\bigr]\lambda_n,
 \quad 0\leq\lambda_{\min}\leq1.$$ Noncrossing edges still have gate one. The newly sampled latch is used on the next step, avoiding an implicit same-step algebraic feedback loop. A seed switch can disable this feedback, in which case $\lambda_n=1$. The default leakage is $0.2$: a closed latch attenuates rather than completely blocks the interface.

This is a dimensionless control choice, not a molecular measurement. The kernel retains three distinct state layers: current analog field samples, persistent binary latches, and the integer pulse-density accumulator. The last has its own residual state. Latch transitions, instantaneous occupancy, pulse output and frame parity are not treated as interchangeable bits.

## The precise meaning of an exact reduced kernel

Let $\mathsf X$ be a specified state space, $\mathsf U$ an input set, $\mathcal K:\mathsf X\times\mathsf U\to\mathsf X$ a total deterministic update, and $\mathcal O:\mathsf X\to\mathsf Y$ the declared observable. Counters and time must either be included in the state or supplied as inputs. Let $\pi:\mathsf X\twoheadrightarrow\mathsf B$ be a surjective candidate encoding. A binary encoding has $\mathsf B=\{0,1\}$; a network encoding can use a subset of $\{0,1\}^k$.

The exact reduced kernel must make both diagrams commute: $$\label{eq:quotient}
 \pi(\mathcal K(x,u))=\overline{\mathcal K}(\pi(x),u),\qquad
 \mathcal O(x)=\overline{\mathcal O}(\pi(x)).$$ It exists exactly when, for every common input $u$, $$\label{eq:congruence}
 \pi(x)=\pi(x')\ \Longrightarrow\
 \begin{cases}
 \pi(\mathcal K(x,u))=\pi(\mathcal K(x',u)),\\
 \mathcal O(x)=\mathcal O(x').
 \end{cases}$$ These conditions say that two states declared equivalent must stay observationally equivalent after every possible allowed next input. They are more demanding than similar-looking curves or equal current sign bits. A partial physical model needs a declared domain of admissibility; a finite checker needs a complete finite transition table. Neither can replace unspecified transitions with a favorable answer.

## A successful reduction and a decisive counterexample

For four states $0,1,2,3$, use blocks $\{0,1\}$ and $\{2,3\}$, with their output labels $0$ and $1$. The transition rows for inputs $u=0,1$ are $$\begin{array}{c|cc|c}
x&\mathcal K(x,0)&\mathcal K(x,1)&\mathcal O(x)\\\hline
0&1&2&0\\1&0&3&0\\2&3&0&1\\3&2&1&1
\end{array}$$ Input zero preserves the block; input one exchanges it. The exact quotient is $\bar b=b\oplus u$. All four initial states and all binary input words of lengths zero through six give $508$ checked traces; the reduced outputs and state blocks match exactly. This is a separate finite example, not a claim that the full continuous-valued Gambit simulation has been reduced to two states.

For a counterexample, take $\mathcal K(x)=x+3/4$ and $\pi(x)=\mathbf{1}[x\leq0]$. States $x=-2$ and $x'=-1/2$ both encode as one, but their successors $-5/4$ and $1/4$ encode differently. Thus no deterministic next-bit map depending only on that current bit can represent this law. Distance-to-threshold is predictive information, even when current occupancy agrees. This demonstrates why the delivered engine retains material amounts, memory, counters and codec residuals instead of silently deleting them.

The reusable hinge is a well-defined binary interface. A complete binary reduction is an additional theorem obligation. Edition 3.0 supplies both the interface and a checker for finite reduction claims; it does not confuse implementing an interface with proving universal sufficiency.

# The Gambit unified seed--field theorem

## Admissibility conditions

Call a seed admissible for $N$ steps when the following contracts hold. The grammar and interpreter are deterministic, all words needed through $g_{\max}$ fit the finite budget, geometric scales remain positive, and every compiled active mask is nonempty. Coordinates, rates, input probes and states are finite. The source record, realized pseudorandom law, arithmetic conventions and all tie rules are specified.

At every accepted step, remapping is nonnegative and column-stochastic; transport is generated by nonnegative edge rates with zero column sums and is substepped to $\delta t\max(-Q_{ii})\leq1$; and reaction is nonnegative and conserves the declared total mass. The default reversible conversion satisfies those conditions. The initial mass is nonnegative with total $M_0$, and $z_0,m_0\in[-1,1]^d$.

Observations $y_n\in[-1,1]^d$ drive $$\begin{aligned}
\label{eq:recurrence}
z_{n+1}&=(1-\alpha)z_n+\alpha\tanh(Az_n+Bm_n+Cy_n),\\
m_{n+1}&=(1-\eta)m_n+\eta\tanh(Dz_n+Ey_n),
\quad 0<\alpha,\eta\leq1,
\end{aligned}$$ with componentwise $\tanh$. The codec uses $D_c=2^b$, $k_n\in\{0,\ldots,D_c\}$, $r_0=0$ and $$\label{eq:codec}
q_n=\mathbf{1}[r_n+k_n\geq D_c],\qquad r_{n+1}=r_n+k_n-D_cq_n.$$ $D_c$ is the codec denominator, not a diffusion coefficient or the recurrent matrix $D$. The codec residual $r_n$ is not the reference length used in the log-polar chart. Initial latch bits, positive hysteresis thresholds and gate leakage in $[0,1]$ are part of admissibility. Parity is computed on the declared payload and stored separately from the material dynamics.

**Unified Theorem U3** (Gambit composition and exact reduction). For an admissible complete seed and any $N$ accepted finite updates, the declared operator composition defines one unique history. It has the following guarantees.

**(a) Replay and type separation.** Identical complete seed, input history and arithmetic conventions yield identical states, generated words and outputs. Documentary labels that do not enter the laws cannot alter that history.

**(b) Geometric semantics.** At each fixed generation and memory state, the compiled field is 1-Lipschitz in the chosen Euclidean spatial metric and its nonpositive set is exactly the declared union/intersection of strokes and ground half-space. This does not assert a globally exact interior signed distance for an overlapping composite.

**(c) Material invariants.** The chemical state remains nonnegative and its total declared mass is $M_0$ through transport, reaction and domain changes. For a fixed realized sequence of the same stochastic matrices, the chemical transition is nonexpansive in mass $\ell^1$ norm.

**(d) Bounded recurrence.** The fast state and memory remain in $[-1,1]^d$, including when the field, masks, transport coefficients and growth decisions change within the admissibility conditions.

**(e) One-bit certificate.** Every output is a bit, $0\leq r_n<D_c$, and for every prefix of length $n$, $$\sum_{j=0}^{n-1}q_j-\sum_{j=0}^{n-1}\frac{k_j}{D_c}
=-\frac{r_n}{D_c}\in(-1,0].$$ Appending XOR parity produces an even-parity frame. This is a coding invariant, not proof of geometric topology or immunity to all transmission errors.

**(f) Conditional covariance.** Rigidly transforming the entire geometry, metric representation, probes, velocity and gate specification preserves the corresponding continuous scalar observations. At the discrete level, an exact node relabeling preserves the history when all graph matrices, remaps, data and tie policies transform consistently. A fixed raster need not be invariant under an arbitrary rotation.

**(g) Binary hinges and causal feedback.** The declared latch update preserves its binary state, with cumulative event XOR $b_{N,\ell}\oplus b_{0,\ell}$. Its causal gate multiplier preserves the transport assumptions and hence clauses (c)--(e). L18 gives a sufficient strict-margin certificate for sampled latch-trace stability.

**(h) Exact reduction, if and only if.** For a total deterministic realization, a specified observation law and a surjective encoding $\pi$ as in Section [6](#sec:gambit), a unique reduced transition and observation model exists exactly when Eq. [\[eq:congruence\]](#eq:congruence) holds. Under those conditions all histories commute with the encoding. This is a criterion, not an assertion that the full Gambit state has an exact two-state quotient.

**(i) Scope of the unification.** A common binary interface and a one-bit output do not identify the full seed or state. With a fixed decoder, $b$ bits distinguish at most $2^b$ cases. Narrative or theological labels absent from the laws cannot be inferred from numerical traces alone.

Proof. The grammar, interpreter and all finite state updates are deterministic on their specified domains. Composition and induction establish (a). Each primitive distance is 1-Lipschitz, and finite minima and maxima preserve a common Lipschitz bound and the required closed-set membership identities, giving (b).

For (c), express one material update on stacked species masses as $$\mu_{n+1}=R_n\,\operatorname{diag}(P^U_n,P^V_n)
\,\operatorname{diag}(\Pi_n,\Pi_n)\mu_n.$$ Each factor, including any repeated positive substeps, is a nonnegative column-stochastic matrix. A product of such matrices is again nonnegative and column-stochastic. Hence positivity and $\mathbf{1}^T\mu_n=M_0$ follow by induction. For any fixed such product $K$, $\left\lVert Kx\right\rVert_1\leq\left\lVert x\right\rVert_1$; apply this to the difference of two mass states using the same realized factors.

For (d), every component of each next state is a convex combination of a number in $[-1,1]$ and a $\tanh$ value in that interval. The result is independent of the size of the driving matrices so long as their evaluations are defined. For (e), $0\leq r_n+k_n<2D_c$ gives a binary $q_n$ and a residual in $[0,D_c)$. Summation of Eq. [\[eq:codec\]](#eq:codec) gives the prefix identity. XOR of the payload XOR with itself gives even parity.

For (f), Euclidean isometries preserve distances and consistently transformed vector projections. Discrete permutation covariance follows by conjugating state-transition matrices and applying the corresponding input and output permutations. Consistent remap and tie-policy transformation is essential. For (g), L14 proves that the hinge is total and binary and that its multiplier leaves gate rates admissible. Thus the same invariant argument applies at each new realized gate. The strict-margin induction of L18 covers the stated perturbation certificate. Clause (h) is precisely the representative-independence equivalence proved in L15. Clause (i) follows from the cardinality bound in L16 and the semantic non-identification of L10. L13 fixes the set/seed representation and L17 makes the edit boundary explicit. These are mathematical consequences under assumptions; none introduces an empirical statement about consciousness. ◻

## What this theorem deliberately does not imply

U3 is an invariant-and-composition theorem. It does not claim global contraction of the full hybrid system, unique patterns for different seeds, continuum convergence, biological validity or universal physical closure. State-dependent gates, masks and threshold decisions mean that two nearby initial states may select different matrices; the fixed-matrix nonexpansiveness clause cannot then be applied across them without further estimates. A conserved total also prevents unrestricted contraction across initial states with different total mass.

Admissibility is a mathematical premise, not a claim that all arbitrary parameter files succeed. The implementation rejects unsupported grammar changes, invalid domains and scales, nonfinite values, negative masses, invalid generators and exceeded budgets. Floating-point execution can differ from exact real arithmetic. The numerical tests and exact integer codec checks address specified examples; they do not prove every floating-point program path.

# Eighteen supporting lemmas and proofs

**Lemma L1** (Word algebra, pairing and finite replay). Pair exchange preserves pair parity and canonicalization. Symbol exchange $X\leftrightarrow Y$, together with $+\leftrightarrow-$, is an involution commuting with the grammar. At generation $g$, $$N_X+N_Y=2\,3^g,\quad N_X-N_Y=N_X(0)-N_Y(0),\quad |w_g|=5\,3^g+1.$$ With reflected initial pose, the exchanged word emits the reflected segment sequence. Complete deterministic initialization and transitions imply unique finite replay.

Proof. XOR is addition in $\mathbb{F}_2$, and sorting a pair is exchange-invariant and idempotent. Inspection of the two productions gives $P(Jw)=J(Pw)$, where this $J$ denotes token exchange. The count vector is multiplied by $\left(\begin{smallmatrix}2&1\\1&2\end{smallmatrix}\right)$; its sum triples and its difference is unchanged. Initially $|w_0|=6$. Each draw token is replaced by six tokens, so $|w_{g+1}|-|w_g|=5(2\,3^g)$, yielding the stated formula. Turn reversal under spatial reflection, with stack save/restore, proves interpreter covariance by induction on tokens. Induction on deterministic time steps proves replay. These statements do not make the seed-to-output map injective. ◻

**Lemma L2** (Set semantics, Lipschitz closure and the conditional fold). Finite minima encode closed-set unions, maxima encode intersections, and finite min/max compositions of 1-Lipschitz fields are 1-Lipschitz. For the paired arcs, a near-side fold is valid when the translated right arc lies wholly in $x\geq0$; $h\geq R\sin\alpha$ suffices. Composite membership does not imply exact interior signed distance.

Proof. $\min(f,g)\leq0$ iff $f\leq0$ or $g\leq0$; the analogous maximum gives "and". If both $f$ and $g$ change by at most $e$ between two points, their minimum and maximum also change by at most $e$. Induction proves the finite statement. For a query $x\geq0$ and any right-arc point with horizontal coordinate $u\geq0$, $(x-u)^2\leq(x+u)^2$, so the corresponding reflected point is never closer. Taking minima proves the fold in that regime.

For a counterexample outside it, take $R=1$, $h=0.5$, $\alpha=\pi/2$, thickness $0.1$ and query $(0.5,0)$. The explicit union field is $-0.1$ but the fold gives $0.9$. For a separate metric counterexample, two unit disks centered at $(\pm0.5,0)$ give minimum signed distance $-0.5$ at the origin, while the actual signed distance to the union boundary is $-\sqrt{3}/2$. Correct membership and a Lipschitz bound therefore do not imply exact negative distance magnitude. Conservative distance reasoning is standard context, not a consciousness result. [\[E2\]] ◻

**Lemma L3** (Rigid hinges preserve geometry, not a forced bit flip). For Euclidean isometry $T(x)=Qx+b$, $Q^TQ=I$, $d_{T\Omega}(Tx)=d_\Omega(x)$. A reflection can reverse orientation while preserving occupancy. A global change of frame preserves consistently transformed observations; arbitrary resampling on a fixed Cartesian raster is a separate operation.

Proof. $\left\lVert Tx-Ty\right\rVert=\left\lVert Q(x-y)\right\rVert=\left\lVert x-y\right\rVert$. Taking the infimum over the set or its boundary preserves distances, and the bijection preserves interior membership. Orientation is determined by $\det Q$, while occupancy depends on membership; neither determines the other. Covariance of vector projections follows by transforming both vectors by $Q$. A grid after an arbitrary rotation is usually not the original node set, so no exact raster permutation is supplied by the continuous identity alone. ◻

**Lemma L4** (Chart metric, event roots and bracket error). The log-polar metric and roots in Sections 3--4 follow from the declared coordinate and trajectory maps. A sign-changing continuous function on a finite bracket has a zero in it; $n$ bisections reduce bracket width by $2^{-n}$. A tangent zero need not be detected by opposite-sign tests.

Proof. Differentiate $x=r_0e^\rho(\cos\theta,\sin\theta)$: the two coordinate derivatives are orthogonal with equal length $r_0e^\rho$, giving the metric. In Eq. [\[eq:toy\]](#eq:toy), a product vanishes exactly when a factor does. Solving those factors yields the stated $\rho$ roots, with no second-factor root when its sine coefficient is zero. Substitution into $\rho=\log(c_s(t-t_0)/r_0)$ gives Eq. [\[eq:times\]](#eq:times). Exponent pairs multiply to one in normalized delay. The intermediate value theorem preserves a root-containing sign bracket, and each chosen half has half its width. The example $f(t)=(t-a)^2$ proves why a zero need not change sign. ◻

**Lemma L5** (Closed graph transport and dissipative diffusion). A finite column generator $Q$ with nonnegative off-diagonal entries and zero column sums gives a nonnegative column-stochastic $P=I+\delta t Q$ whenever $\delta t\max(-Q_{ii})\leq1$. It preserves mass, nonnegativity and is nonexpansive in $\ell^1$. For symmetric diffusion, $$x^TL_hx=-\sum_{\{i,j\}\in E}w_{ij}(x_i-x_j)^2\leq0.$$

Proof. The step bound makes every diagonal of $P$ nonnegative; off-diagonals already are. Its columns sum to one. Therefore $P\mu\geq0$ for $\mu\geq0$ and $\mathbf{1}^TP\mu=\mathbf{1}^T\mu$. For any signed vector $x$, the triangle inequality gives $\sum_i|\sum_jP_{ij}x_j|\leq\sum_j|x_j|\sum_iP_{ij}=\left\lVert x\right\rVert_1$. For symmetric edge weights, collect the contributions of the two endpoints of each edge in $x^TL_hx$ to obtain $-w_{ij}(x_i-x_j)^2$. Constants lie in the kernel; disconnected components supply additional constant modes. ◻

**Lemma L6** (Positive, locally conservative reaction). The reversible conversion step of Section 5 preserves $u_i+v_i$ at each node and maps nonnegative pairs to nonnegative pairs under the stated step bound. Products of such substeps have the same properties.

Proof. All four reaction-matrix entries are nonnegative and each column sums to one. Matrix multiplication therefore preserves the nonnegative cone and the left invariant $(1,1)$. A product of column-stochastic nonnegative matrices remains in that class. If arbitrary nonlinear reactions are substituted, these premises must be re-established; the theorem is not inherited merely by naming a reaction function. ◻

**Lemma L7** (Conservative geometry changes). A nonnegative column-stochastic remap $\Pi$ preserves nonnegative total mass across domains of different sizes. With cell-volume matrices $V,V'$, $c'=(V')^{-1}\Pi Vc$ preserves integrated concentration. Deleting outside samples without transferring their mass is not this operation.

Proof. Let $\mu=Vc$. Then $\mu'=\Pi\mu\geq0$ and $\mathbf{1}^T\mu'=\mathbf{1}^T\mu$. The concentration formula is just the positive diagonal change of representation. In the nearest-node implementation, each old node's mass has one destination, including itself when retained; each remap column contains one unit entry. A finite index tie rule makes the result deterministic. An arbitrary relabeling must transform that priority rule as well, or tie covariance can fail. ◻

**Lemma L8** (Bounded state and mutable memory). The recurrent laws in Eq. [\[eq:recurrence\]](#eq:recurrence) leave the cube $[-1,1]^{2d}$ invariant. More generally, if $m_{n+1}=(1-\eta)m_n+\eta\psi_n$ with $\left\lVert \psi_n\right\rVert_\infty\leq B$, then $$\left\lVert m_n\right\rVert_\infty\leq(1-\eta)^n\left\lVert m_0\right\rVert_\infty+
[1-(1-\eta)^n]B.$$

Proof. Each scalar $\tanh$ lies between $-1$ and $1$. A convex combination of values in that interval stays in it. For the more general bound, repeatedly substitute the affine recurrence and bound its geometric series. Memory in this model is a mutable state variable whose influence can decay or change. Boundedness neither implies permanent storage nor identifies the physical substrate of human memory. ◻

**Lemma L9** (One-bit error, parity and Hadamard structure). The integer accumulator satisfies U3(e). If input coverage $a_n\in[0,1]$ is rounded to $k_n/D_c$ by nearest-half-up, then in ideal real arithmetic $$\left|\sum_{j<n}q_j-\sum_{j<n}a_j\right|
<1+\frac{n}{2D_c}.$$ Parity is addition modulo two. The normalized Walsh--Hadamard transform is a real orthogonal involution, not a one-bit XOR reduction.

Proof. The residual induction and telescoping identity are given in U3. The rounding error of each input is at most $1/(2D_c)$; add these errors to the strict dyadic prefix bound. The implementation's integer certificate is exact for its emitted $k_n$ values; the separate conversion from arbitrary floating-point coverage remains part of numerical arithmetic.

For set indicators, $\mathbf{1}_{A\triangle B}=\mathbf{1}_A\oplus\mathbf{1}_B$ pointwise. Appending the XOR of a finite payload makes total parity zero. Odd numbers of flipped bits are detected; even numbers can evade this check. This does not recover lost distances or encrypt a payload.

For binary indices $a,b\in\mathbb{F}_2^r$, set $H_{ab}=(-1)^{a\cdot b}$. Distinct rows sum to zero in their inner product by pairing indices on a differing bit; identical rows have squared norm $2^r$. Thus $HH^T=2^rI$ and $U=2^{-r/2}H$ is orthogonal with $U^2=I$. The parity appears inside an exponent that defines real matrix entries. The complete transform retains dimensions and accepts asymmetric vectors; it does not imply a quantum electron-memory mechanism. ◻

**Lemma L10** (Observational and semantic non-identification). An interpretation label absent from the transition and observation laws cannot change observable histories under identical numerical inputs. A finite occupancy record does not identify the full field, and model traces alone do not select an unmeasured consciousness ontology.

Proof. If the label does not enter any map, equal states and inputs produce equal next states and outputs regardless of label. Induction proves equality of histories. Likewise, two different positive values have the same outside bit; finitely many such signs leave infinitely many compatible field assignments. The numerical invariants therefore cannot identify an interpretation that has not been linked to distinct observations. This proves a measurement limitation, not the falsity or truth of any spiritual interpretation. ◻

**Lemma L11** (Conditional recurrent contraction). For a fixed generation, common prescribed probes and no state-dependent chemistry difference, suppose the observation law has memory Lipschitz constant $L_y$. In the joint infinity norm, a sufficient contraction factor for Eq. [\[eq:recurrence\]](#eq:recurrence) is $$\begin{aligned}
q=\max\{&1-\alpha+\alpha(\left\lVert A\right\rVert_\infty+\left\lVert B\right\rVert_\infty+\left\lVert C\right\rVert_\infty L_y),\\
&1-\eta+\eta(\left\lVert D\right\rVert_\infty+\left\lVert E\right\rVert_\infty L_y)\}.
\end{aligned}$$ If $q<1$, two such trajectories contract by at most $q$ per step. This is not an unconditional contraction claim for the hybrid growth/transport system.

Proof. $\tanh$ is 1-Lipschitz. Subtract the state equations, apply the induced matrix infinity norm, and bound both state differences by their joint maximum. The resulting two nonnegative row bounds give $q$. Iteration gives $q^n$ times initial separation. A fixed-point conclusion additionally needs a time-independent self-map. If masks, gates, chemistry or trigger decisions change differently between the trajectories, the observation bound used in this argument is not supplied. The retained auxiliary geometry-only model has $L_y=0.04$ and $q=0.94464$; that numeric factor must not be transferred to the v2 coupled chemical loop. ◻

**Lemma L12** (Perturbation margins and limits of pattern claims). For finite sample sites $p_i$, if $\epsilon<\min_i|F(p_i)|$ and $|\widetilde F(p_i)-F(p_i)|\leq\epsilon$, then the two sampled masks coincide. In the fixed, symmetric diffusion-only graph with positive reversible reaction rates and nonnegative diffusivities, the two-species reaction has no diffusion-driven growing eigenmode.

Proof. A perturbation smaller than the distance of a scalar sample from zero cannot change its sign, proving the mask claim. If a sample lies exactly on the boundary, its margin is zero and the claim gives no protection. Consequently, a seed-bit change does not necessarily change topology or a pattern.

For a Laplacian eigenmode with $L_hx=-\lambda x$, $\lambda\geq0$, the reaction--diffusion mode matrix is $$M_\lambda=\begin{pmatrix}-a-D_U\lambda&b\\a&-b-D_V\lambda\end{pmatrix}.$$ Its trace is negative and its determinant is $(aD_V+bD_U)\lambda+D_UD_V\lambda^2\geq0$. The eigenvalues therefore have nonpositive real parts. The zero spatial mode has a conserved direction. This minimal model can redistribute an initial pattern and react to geometry changes, but it is not evidence that a seed necessarily generates self-organized Turing patterns. That stronger corpus statement would require a different reaction law and an instability analysis. [\[C4, pp. 14--15\]] ◻

**Lemma L13** (Alphabet sets, complete seeds and word semantics). A finite alphabet $\Sigma$ determines a free monoid $\Sigma^*$ under concatenation. A deterministic production function $P:\Sigma\to\Sigma^*$ extends uniquely by concatenation to words. A complete labeled seed record can be represented losslessly as a set of tagged fields, provided each tag occurs exactly once and the component values retain their own structure.

Proof. Define $P(a_1\cdots a_n)=P(a_1)\cdots P(a_n)$ and $P(\varepsilon)=\varepsilon$. These equations force the extension and preserve concatenation. The interpreter composes token-state transformations in reading order, so $\tau_{uv}=\tau_v\circ\tau_u$ wherever its stack preconditions hold. For a record $(s_1,\ldots,s_j)$ with fixed distinct tags $t_i$, encode it as $\{(t_i,s_i):1\leq i\leq j\}$. Unique tags recover every component. The ordinary untagged set of values is not an equivalent encoding: it can erase order and repeated values. In particular, the pair-word $XX$ must not become the singleton alphabet subset $\{X\}$. These are definitions of syntax and representation, not an assertion that letters independently contain all growth laws. ◻

**Lemma L14** (A total binary hinge and causal admissibility). For finite $s$, $\delta_h>0$ and an incoming bit, Eq. [\[eq:latch\]](#eq:latch) returns one unique bit. The events satisfy $$\bigoplus_{n=0}^{N-1}e_{n,\ell}=b_{N,\ell}\oplus b_{0,\ell}.$$ Multiplying an admissible gate in $[0,1]$ by Eq. [\[eq:gambitgate\]](#eq:gambitgate)'s $\lambda_n$ preserves its admissible range and hence the nonnegative-rate transport premise.

Proof. The strictly separated thresholds and middle interval partition the real line, including their stated equality cases. Each branch returns zero, one or the incoming bit, proving totality and the binary invariant. Expanding the XOR of adjacent-state differences cancels every intermediate bit twice. Since $\lambda_n$ is either $\lambda_{\min}$ or one, both factors of the effective gate lie in $[0,1]$. Its edge rates remain nonnegative; generator diagonals are rebuilt from outgoing rates, preserving zero column sums. This remains true with feedback because the incoming bit fixes the gate before that step is executed. ◻

**Lemma L15** (Exact deterministic quotient criterion). For the total maps and surjective encoding in Section [6](#sec:gambit), a unique pair $(\overline{\mathcal K},\overline{\mathcal O})$ satisfying Eq. [\[eq:quotient\]](#eq:quotient) exists if and only if Eq. [\[eq:congruence\]](#eq:congruence) holds. Under this condition, all reduced histories commute with $\pi$ for every common input sequence.

Proof. Necessity follows by substituting equal encoded states into the two reduced maps. For sufficiency, choose any representative $x$ with $\pi(x)=b$, and set $\overline{\mathcal K}(b,u)=\pi(\mathcal K(x,u))$ and $\overline{\mathcal O}(b)=\mathcal O(x)$. The congruence conditions make both choices independent of the representative. Surjectivity covers every encoded state and forces uniqueness. Inductively apply the transition identity at each input to obtain $\pi(x_n)=\bar x_n$ and then the observation identity for outputs. On a finite machine it suffices to compare every state in each block to one representative for every input, exactly the supplied checker. That checker does not prove the criterion for an unenumerated continuum state space. ◻

**Lemma L16** (Information capacity of an initial word). For a fixed decoder and fixed side information, a $b$-bit code distinguishes at most $2^b$ cases. If $r$ cases must be distinguished, then $b\geq\lceil\log_2r\rceil$. In particular, a one-bit selector can choose between two predeclared complete seeds but cannot independently specify arbitrary alphabets, rules, constants and input histories.

Proof. There are $2^b$ binary strings of length $b$. A deterministic decoder maps each to at most one decoded case. Distinguishing $r$ cases therefore requires an injection of those cases into the code space, which forces $r\leq2^b$. A length or timing channel, a changing decoder or additional memory constitutes extra information and must be counted separately. With a fixed kernel $K$, the notation $E_K(0)=\sigma_{XX}$ and $E_K(1)=\sigma_{XY}$ is valid, but $K$ supplies all shared structure. No small selector turns that shared structure into information carried by the selector itself. ◻

**Lemma L17** (Local editing without global collapse). A legal finite edit with at least one retained positive-radius primitive has a defined composite field. If matched compact centerlines change by Hausdorff distance at most $\epsilon$ and radii by at most $\delta$, the corresponding distance-minus-radius min-fields differ uniformly by at most $\epsilon+\delta$. Further fixed min/max composition preserves this bound. If $J^2=I$, $J\Omega=\Omega$, and the removed set is $E\cup JE$, then $J(\Omega\setminus(E\cup JE))=\Omega\setminus(E\cup JE)$.

Proof. A nonempty finite minimum of finite continuous primitive fields is finite and continuous. For compact sets $A,B$ with Hausdorff distance at most $\epsilon$, choose a nearest point of $A$ to a query and a point of $B$ within $\epsilon$ of it. The triangle inequality gives $d(x,B)\leq d(x,A)+\epsilon$; exchange the sets for the reverse inequality. Subtracting radii adds at most $\delta$. Finite min/max operations are nonexpansive in the common sup-norm perturbation, as in L2. The last identity follows because a bijection distributes over union and difference and $J(E\cup JE)=JE\cup E$. A nonsymmetric edit can break symmetry without invalidating the edited shape. The set-difference identity has literal set semantics; implementing it by a closed-field maximum would additionally require an explicit boundary convention. This lemma is not a biochemical gene-editing law. ◻

**Lemma L18** (Robust hinge traces and a conditional dwell bound). Suppose $|s_n-\widetilde s_n|\leq\epsilon$ for a finite sampled trace and $$\epsilon<\min_n\min\{|s_n-\delta_h|,|s_n+\delta_h|\}.$$ Starting from the same bit, both traces give identical latch states and events. For an ideal continuous relay with an $L$-Lipschitz input in time, $L>0$, consecutive opposite switches are separated by at least $2\delta_h/L$.

Proof. The strict margin prevents a perturbed sample from crossing either threshold. The two traces therefore choose the same branch of Eq. [\[eq:latch\]](#eq:latch); induction preserves equal bits and hence equal events. A zero margin supplies no certificate, even when particular traces happen to agree. For the continuous statement, opposite switches require input values separated by at least $2\delta_h$. The temporal Lipschitz bound implies $2\delta_h\leq L|t_2-t_1|$. Discrete growth or mask jumps in the full hybrid engine need not satisfy such a temporal bound. The delivered simulation claims only its sampled-event record; its separate growth dwell count is not this continuous relay theorem. ◻

# Consciousness across bodily, digital and spiritual domains

## The candidate explanatory bridge

**[H]**  The proposed bridge is that some organization of conscious experience may depend on a recurrent, memory-modified model of embodied boundaries, where physical transport and sensing constrain the available information and action. The mathematical state is an explicit surrogate for such organization. Its suitability must be judged by predictions about observations, not by the visual resemblance of a simulated arch or branch to anatomy.

Let $h_n$ be the model history and let $\widehat r_n=\mathcal O_\vartheta(h_n)$ be a prospective readout of a predeclared report or task measure. A fitted relationship between $h_n$ and measured reports would be an empirical bridge hypothesis; it is not part of U3. The supplied corpus contains no paired reports, sensor measurements or fitted $\vartheta$, so the delivered kernel exports synthetic state features, not a calibrated consciousness score.

A useful unified account must explain which operations matter, under which interventions, and beyond which comparison models. One cannot infer that consciousness exists whenever U3's invariants hold: a nonnegative conservative transport calculation with bounded memory is already enough to satisfy many clauses, regardless of any proposed subjective interpretation.

## Bodily sensing: separate interfaces, shared geometry

**[D]**  Retained toy sensing interfaces make dimensional distinctions explicit. For eye-origin baseline $d_{\mathrm{IPD}}>0$, $$e_{L,R}=o\mp\tfrac12 d_{\mathrm{IPD}}\hat x.$$ For point receivers at $r_L,r_R$, a source $s$ and specified constant speed $c_s$, $$\mathrm{ITD}=\frac{\left\lVert s-r_R\right\rVert-\left\lVert s-r_L\right\rVert}{c_s},\qquad
|\mathrm{ITD}|\leq\frac{\left\lVert r_R-r_L\right\rVert}{c_s}.$$ The last inequality is the reverse triangle inequality. Eye separation is a length, while this idealized arrival difference is a time. IPD does not uniquely determine ear separation, a person's acoustic transfer function, gaze direction or vestibular response. The code provides geometric interfaces, not physiological calibration. "IDT" remains insufficiently specified in the corpus and is not silently assigned a new operator.

The chemical layer could motivate a future body-boundary model, but it is not already one. The supplied materials do not give membrane transport coefficients, receptor kinetics, neural transduction, cell mechanics or a measurement procedure for molecular valves. The new "sieve" is therefore represented by a gate and a domain boundary as a modeling analogy. A biological realization would require independent calibration and tests of those assignments.

## Genetic pairings and unsupported biological reductions

[**\[S; U\]**]  C4, p. 12, treats fertilization as a deterministic time root and a one-bit $XX/XY$ collapse; pp. 15--16 assert that local genetic editing is invalidated by mirrored geometry. Neither conclusion is established by the equations or the supplied evidence. The symbolic alphabet is not the genome, a model's boundary event does not specify a biochemical mechanism, and neither parenthood nor human development is reduced to a scalar computational bottleneck by this theorem.

**[E]**  A limited external check is directly relevant to the source's denial of DNA cutting: Jinek and colleagues experimentally reported RNA-guided Cas9 cleavage of double-stranded target DNA. That primary result contradicts the assertion that mirrored DNA geometry makes such cutting fictitious. It does not imply that all editing is simple, unconstrained or explained by this engine. [\[E3\]]

There is also a purely mathematical error in the corpus's argument. Removing or changing one primitive leaves a finite min-field defined when at least one primitive remains; cutting a symmetric shape may break symmetry without making all geometry undefined. The Hadamard transform is invertible on all input vectors of its declared size, not only symmetric ones. The accompanying tests exhibit both facts. Molecular transport, chemistry and environmental context can matter without implying that a supported DNA-cleavage mechanism is impossible.

## Digital scope

**[D]**  The engine is an inspectable research kernel: it performs finite rewriting, geometry evaluation, graph assembly, mass transfer, transport, reaction, recurrent updates and coding. The title "AI Engine" is the author's system name; no trained language model, general agent, brain emulation or consciousness detector is included. The code uses real-valued numerical arrays internally. A one-bit output does not make every internal variable a bit.

The binary spatial hierarchy and log-polar lookup are retained utilities, not a universal replacement for computation. Geometry evaluation is still an operation with resource costs. No acoustic driver, surveillance function, biological protocol, optical hardware or harmful-stimulus generator is provided. Optical implementation and processing latency remain engineering proposals; no propagation path, device characterization or measured latency is supplied.

## Spiritual scope and the "story around the operators"

**[I]**  Spiritual language may describe felt unity, significance, connectedness, purpose or transcendence in first-person terms. These are interpretive categories carried forward from the earlier manuscript, not measured fields introduced into the transport equations. A report about such experience can become an observable variable with an appropriate study design. Its metaphysical interpretation is a separate question.

C4, pp. 11--12, explicitly distinguishes operators from the stories used to interpret them. L10 formalizes the narrow numerical consequence: changing a narrative label that does not enter the laws cannot change their outputs. This does not prove that human meaning is unreal or that a spiritual interpretation is false. It prevents the same trace from being presented as independent confirmation of incompatible unmeasured ontologies.

No geometric proof assigns moral value to $XX/XY$ pairings, rotation direction, a person's ancestry or a historical symbol. No asserted equivalence between an SDF hinge and a soul, wormhole, charge--parity boundary or quantum collapse enters U3.

## The Gambit interpretation record: Word, field and quintessence

[**\[S; I\]**]  C6, pp. 32--38 and 44--47, explicitly develops a Christian interpretation: the initial Word or seed, an interpreting realization, a pervasive field, the "V"/hourglass motif, and quintessence. This edition records that as the author's requested interpretive perspective, rather than replacing it with a different theology or presenting it as universally accepted Christian doctrine. The manuscript's use of "Gambit" is the edition designation, not a chess algorithm or an added acronym.

The interpretive mappings are made visible and kept separate from execution:

\@P.24YY@ Corpus term & Formal anchor used here & Status and limit\
Word / seed & A complete $\sigma\in\mathfrak S$; optionally a bit selecting two fixed seeds & Generative analogy. The complete decoder, laws and environment are not compressed into that selector.\
Interpreter / realization & $\mathcal I$ maps words to geometric primitives & A defined computational stage; no literal biological incarnation is derived.\
Quintessence / infinite field & The chosen ambient $(M,g)$ and any declared fields on it & Interpretive name, not a newly measured substance, cosmological field equation or extra energy source.\
V / hourglass & Branching, paired geometry and a reversible coordinate motif & Symbolic geometry; not a theorem about reproductive anatomy, sex or human worth.\
God / field & An interpretation map assigning religious significance to the architecture & Faith interpretation; no scalar measurement or software test identifies a divine being.\
Journey / godspeed & A path and a selected goal or event time & Meaning attached to a trajectory, not a proof that all life follows one predetermined event-root formula.\

Formally, let $\iota:\mathsf{Histories}\to\mathsf{Narratives}$ be an interpretation map. In this reference build it is not an argument of $\mathcal K$ or $\mathcal O$. L10 therefore applies: changing documentary religious language does not change the numerical trace. This states what the program executes, not that faith or lived significance is meaningless. A human report of significance could become a separate observable in a properly specified empirical study.

## Glyphs, casing and the distinction between union and fusion

**[S]**  C6, pp. 30--31, reads lowercase `i`, capital `I`, a dot and a pipe as geometric operators. As a chosen graphical interpretation, a dot may be modeled by a disk and a stem by a capsule. Their union is $D\cup S$, with field $\min(d_D,d_S)$. If they are disjoint, that union is still disjoint: a point in the gap remains outside both sets. A connector primitive, dilation or an explicit blending operator is required to bridge it. These are additional operations, not consequences of the union symbol.

**[E]**  Unicode distinguishes abstract characters from their rendered glyphs. Thus a font-dependent resemblance is not by itself a semantic equation or a physical law. The pipe can be assigned a bitwise OR meaning in a specified programming language, but it is not a universal replacement for every set operation. The reference grammar remains exactly $\{X,Y,+,-,[,]\}$; `i`, `I`, `|`, `V` and religious words are not secretly executed as extra production commands. [\[E5; C6, pp. 30--35\]]

## Binary pairings without human classification

**[S]**  C6, pp. 42--47, connects the two-state language to female/male symbolism and to the seed/hourglass interpretation. The corpus also explicitly acknowledges chromosomal and other biological variation (pp. 42--43). These distinct source positions are recorded, not harmonized into an unsupported universal biological theorem.

**[D]**  $XX$ and $XY$ in this engine are explicit symbolic seed labels. They initialize different words under the same grammar, and their interpretation in code is exhausted by those rules. There is no input variable for a person's gender, ancestry, value or spiritual status; no classifier for living beings; and no model of the mechanisms that determine biological development. An arbitrary renaming of these two token labels would preserve the mathematical architecture when its interpretation map is renamed consistently. Giving tokens biological names does not establish that two tokens exhaust the biological phenomena.

Likewise, reflections and rotations do not acquire physical or moral properties from historical labels. The earlier corpus's Hindu/Nazi rotor story is retained as a source interpretation with an explicitly unsupported geometric causal claim; a $45$-degree rotation remains an isometry under L3. No ideological conclusion, hierarchy of people or diagnosis is produced by this kernel.

## A formal research formulation of conscious organization

**[H]**  The theory's constructive proposal is boundary-mediated, history-dependent self/world organization. A body-oriented model supplies interfaces that restrict information and action. Digital operations provide explicit encodings and reproducible transitions. Recurrent state and memory enable present activity to depend on prior interactions. Spiritual interpretation concerns the meaning attributed to those experiences. The three descriptions are connected through declared maps rather than identified as one interchangeable quantity.

A future empirical formulation can use a history feature map $$\Psi_n=\Psi(g_{0:n},F_{0:n},\mu_{0:n},b_{0:n},z_{0:n},m_{0:n}),\qquad
\widehat r_n=\mathcal O_\vartheta(\Psi_n),$$ where $r_n$ is a predeclared behavioral or first-person measure. A specific hypothesis would predict which boundary-feedback and memory interventions change $r_n$ and whether a reduced model loses those predictions. The quotient criterion supplies a rigorous target for model information loss. It does not establish that report prediction is sufficient for phenomenal consciousness.

The operational thesis is that coupled boundary, material, sensing and memory dynamics may provide a useful explanatory model. The stronger substrate thesis---that the same hinge mechanism is sufficient for every biological, digital and spiritual manifestation---remains an explicit interpretive or empirical postulate. Neither is converted into a proven fact merely because the conservative transport and integer-code theorems hold. No neural recordings, participant reports or fitted consciousness readout are present in the delivered corpus or generated results.

# Executable kernel and recorded verification

## Defaults and concrete observations

The default configurations use a $61\times31$ Cartesian grid, $h=0.08$, total window $[-2.4,2.4]\times[-0.16,2.24]$, and 120 steps of $\Delta t=0.04$. Geometry starts at generation one and may reach generation four. The dwell count is 30 and the growth-score threshold is $0.55$. Diffusivities are $D_U=0.05$, $D_V=0.025$, swirl coefficient $\omega=0.06$, and conversion rates $a=0.24$, $b=0.12$. All are uncalibrated simulation units.

The initial concentration law is explicit in code: a small positive background and a Gaussian enrichment for each species, restricted to the active mask and multiplied by $h^2$ to obtain mass. Both sample configurations initially represent the same total mass. Their early sampled fields coincide; later generated geometry and boundary scores can diverge.

Three prescribed moving probes produce the field feature $-\tanh F$. The actual bounded observation is $$y_{n,\ell}=0.6[-\tanh F(x_{n,\ell})]+0.4(2f_U-1),\quad
f_U=\frac{\sum_i u_i}{\sum_i(u_i+v_i)},$$ with $f_U=1/2$ when total mass is zero. This is a dimensionless mixture chosen for the demonstrator, not a claim that concentration and distance are the same quantity. The fast and memory matrices are seeded PCG64 realizations with declared row-sum norms $0.35,0.15,0.40,0.30,0.20$. The final pulse coverage is $a_n=(1+\operatorname{mean}z_{n+1})/2$. A current frame contains three new latch bits, a growth-event bit and the pulse, followed by a separately computed even-parity bit. Raw occupancy and three latch-event bits are separately exported in the history record. Hinge thresholds are $0.012$, initial latch bits are $(0,0,0)$, leakage is $0.2$, and the first probe controls the gate with one-step causality. The versioned probe law adds vertical sinusoidal motion of amplitude $0.18$ and angular frequency $1.8$ in simulation units; its exact three coordinates are in the kernel specification.

\@Yrr@ Executed default quantity & $XX$ & $XY$\
Number of steps & 120 & 120\
Initial mass & 0.4004597981 & 0.4004597981\
Largest absolute total-mass drift & $1.832\times10^{-15}$ & $1.832\times10^{-15}$\
Smallest represented mass & 0 & 0\
Growth-event steps & 31, 61, 91 & 31, 61\
Final generation & 4 & 3\
Final active nodes & 317 & 293\
Maximum substep exit-rate product & 0.697 & 0.697\
Largest absolute fast-state component & 0.0455494 & 0.0455494\
Largest absolute memory component & 0.0132783 & 0.0123557\
Lowest dyadic prefix error & $-0.757553$ & $-0.761414$\
Hinge transition counts (probes 1, 2, 3) & 6, 5, 3 & 6, 5, 1\
Gate multiplier range & $[0.2,1]$ & $[0.2,1]$\
All exact integer codec certificates & Pass & Pass\
All recorded frames have even parity & Pass & Pass\

The default $XY$ trace does not reach generation four because its later boundary-score predicate is not satisfied. This is a disclosed simulation outcome, not a claim of superiority or biological difference between token pairs. The cover and same-generation geometry figures deliberately show generation-four compiled geometry; the final transport fields show the actual reached generation. Their captions are not interchangeable.

![Final $XY$ concentration in the active finite graph. The mass is transported and locally converted without an external source. This transient result is not evidence of a biological morphogen, tissue development or self-organized Turing instability.](figures/transport_xy.png)

![Observed floating-point drift relative to the common initial mass. The mathematical invariant is exact in real arithmetic; the run is finite-precision. The archive contains the scalar mass at every step.](figures/mass_conservation.png)

![The three explicitly stored latch bits in the synthetic $XY$ run. Vertical offsets separate the traces visually. The first incoming bit controls the gate multiplier; these bits do not replace the full chemical or memory state.](figures/hinge_history.png)

## Written proof, solver checks and executable tests

**Written layer.** U3 and L1--L18 supply assumptions, statements and proofs. Infinite induction, metric arguments, differential formulas and semantic non-identification are not completely encoded in a proof assistant. The mathematical contribution of this edition is the explicit composition, closure assumptions, counterexamples and correspondence to the kernel, not a priority claim for its standard component identities.

**Solver layer.** The package contains 46 standalone SMT-LIB negated identities or implications. Z3 version 4.13.3.0 returned `unsat` for all 46 and produced proof logs. K01--K34 retain the earlier algebraic obligations. K35--K46 add latch totality fragments, causal gate bounds, margin stability, mirrored deletion, finite bit capacity and representative independence. Three separate satisfiable queries produce explicit witnesses for insufficient current-bit dynamics, a remaining geometric gap and loss of distance magnitude. These SAT witnesses are expected successful counterexamples, not failed theorem proofs. The official solver and its encoding are within the trust boundary; no independent small-kernel replay of the proof logs is claimed. The solver-method reference is external documentation, not an audit of this package. [\[E4\]]

**Execution layer.** 145 regression tests pass in the recorded environment: the 99-test inherited suite plus 46 new Gambit tests. These cover geometry, the invalid fold, reflection, coordinates, LUT certificates, event roots and near-singular cases, graph sums, diffusion energy, positive substeps, mass-preserving remap, reaction, exact integer coding, state bounds, input nonmutation, configuration validation and same-environment replay. A fixed-point codec test checks all $5^4=625$ length-four input words at denominator four. Separate random-prefix tests check 5,000 dyadic inputs. The new tests cover schema closure, latch threshold ties, event telescoping, error margins, causal gating, local edits, information capacity, quotient success and failure, metadata independence and full-run invariants. The separate finite quotient demonstrator checks 508 input histories. Tests are finite examples and do not turn floating-point code into a universally verified implementation.

The auxiliary full-angle and half-angle event roots at the disclosed test angle have maximum polynomial residual $3.73\times10^{-17}$. A 1,000-query LUT test has maximum observed error $0.0640730$ with zero violations of its conservative corner-distance certificate. The retained geometry-only recurrent test has bound $q=0.94464$ and step-180 separation $1.308\times10^{-7}$ against a $3.531\times10^{-5}$ envelope. These auxiliary numbers are not biological findings or global hybrid-system guarantees.

![Every recorded prefix satisfies the dyadic accumulator certificate. The certificate concerns the quantized $k_n/2^{16}$ input, not recovery of the full original field or perfect transmission of every frame.](figures/codec_prefix.png)

## Implementation map and reproduction

\@lY@ File & Main responsibility\
`kernel/core.py` & Pair algebra, grammar, turtle, primitive and composite fields, lookup, bisection, sensing, parity, Hadamard and auxiliary recurrence.\
`kernel/spatial.py` & Capsule bounding-volume hierarchy with exhaustive-query comparison tests.\
`kernel/transport.py` & Finite grid, masked graph, directed rates, positive transport, reversible reaction and conservative remapping.\
`kernel/events.py` & Both actual corpus polynomial variants, dimensionally normalized times and singularity/overflow status.\
`kernel/coding.py` & Exact integer dyadic accumulator and prefix certificate.\
`kernel/unified.py` & Inherited composition core with a validated external gate multiplier; the geometry/chemistry/memory update.\
`kernel/gambit.py` & Current strict seed schema, explicit alphabet set, three latches, causal gate feedback, current framing and complete kernel fingerprint.\
`kernel/quotient.py` & Exact finite partition checker, representative witnesses, a valid two-state quotient and bit-capacity utility.\
`kernel/editing.py` & Legal word edits, segment perturbations and reflection-closed editing examples.\
`kernel/demo.py` & Disclosed runs, numerical files, fingerprints and figures.\

Run from the extracted package root:

    python verify_package.py
    python -m pip install -r requirements.txt
    python -m unittest discover -s tests -v
    python -m kernel
    python formal/check.py
    python formal/counterexamples.py
    bash manuscript/build.sh

For a single configuration, use `python -m kernel –config config/seed_xy.json –out rerun_xy`. The full reproduction record uses Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8 on Linux. A LaTeX installation is required for PDF rebuilding; Z3 is needed for the optional solver rerun. The checker supports an installed executable or the official C library. No font or solver binary is redistributed. External scientific papers are cited, not bundled as dependencies.

Run the checksum verifier before regenerating outputs. Rebuilt figures or PDFs may have different timestamps and bytes, even when numerical results agree. Same-environment replay refers to the defined numerical experiment, not to cross-platform bitwise identity of all artifacts. The configuration fingerprint records realized matrices; the archive checksum manifest records code and source bytes.

# Research tests and extension gates

## Tests of the computational theory

**[H]**  A first research phase can remain entirely numerical. Compare the complete loop against a frozen-geometry version, a frozen-memory version, a geometry-free graph matched on node count, and a transport-free version. Predeclare a downstream task and scoring rule; match parameter counts and computational budgets. The present demonstrations do not carry out this predictive comparison and should not be described as evidence that the full architecture is necessary.

For geometry sensitivity, perturb the interpreter angle or stroke radius and record field error, mask changes, connectivity, transport spectrum and output differences. L12 predicts mask invariance under a positive sampled margin; it also specifies when that prediction is unavailable. The failure criterion is a certified-margin case whose exact target changes sign, or a numerical violation beyond a declared rounding allowance.

For the material layer, test closed graphs and explicit open-boundary sources separately. Closed-run mass must satisfy the conservation tolerance; an open-run ledger must explain every change by prescribed transfer or reaction. Test shrinking as well as growing domains. Positivity should be checked before any postprocessing. Higher-order remapping or continuum claims require a grid-refinement study and appropriate reference solutions, neither of which is supplied by the current invariant theorem.

## Testing the Gambit reduction claim

For a declared finite model, enumerate the state partition, every admissible input and the observation labels. The checker must either construct a representative-independent quotient or return a witness pair with incompatible outputs or successors. A sign-based partition failing this test is not repaired by adding unreported memory to the reduced model. Instead, refine the partition or specify that memory explicitly and then test the new model.

For a continuous or experimentally observed system, a finite test cannot establish the universal congruence condition by itself. Predeclare the observation resolution and intervention set; compare full-state and reduced-state predictors on held-out histories; report uncertainty and any pair of initially equivalent states with distinguishable later outcomes. A hysteresis robustness claim additionally requires field-error bounds and positive threshold margins. This links the new theorem to falsifiable modeling choices without presenting a successful toy quotient as universal physical evidence.

## Tests of an empirical consciousness bridge

**[H]**  A later empirical study would need a defined behavioral or first-person outcome, measured inputs, data provenance, fitted parameters, appropriate consent and oversight, and matched alternatives. A useful hypothesis is not simply that a model can fit reports, but that a specified boundary/memory interaction predicts held-out observations or intervention effects better than the controls.

Bodily, digital and spiritual measures must not be conflated. A latency, task response, confidence rating and report of felt unity are different observables. Their scales, coding rules and uncertainty would have to be stated before interpreting a common latent feature. No personal identifier or $XX/XY$ token is a proxy for consciousness level. No clinical, neurological or genetic diagnosis should be inferred from these demonstrations.

The empirical bridge would fail for its declared task if a matched non-boundary model predicts equally well or better, if the predicted intervention signature does not occur, or if success depends on retrospective relabeling of outcomes. Failure would challenge that bridge hypothesis; it would not invalidate the standard algebra in U3. Conversely, correct algebra does not rescue a failed empirical explanation.

## Conditions for future kernel extensions

A new growth grammar must define and validate its interpreter rather than being silently ignored by configuration loading. A new reaction law must provide positivity and balance conditions. A new coordinate quotient must provide its metric and seam rules. A moving-domain continuum solver must account for relative boundary flux and demonstrate numerical convergence. A photonic or biological implementation must provide a realization map, measurements and error/latency characterization. A consciousness readout must specify observations and discriminating tests.

The existing proofs are reusable where their assumptions remain true. They are not a license to transfer every conclusion to a larger system with different state types or dynamics.

# Source-to-formalization audit

The complete machine-readable audit is `docs/claim_audit.csv`. The following register records the principal decisions, including conflicts and unsupported inferences. It preserves the distinction between a source assertion, an added model and a supported conclusion. "Not established" refers to the supplied evidence or a stated mathematical implication, not to a blanket rejection of the author's research program.

P.10P.24P.57 ID & Source location & Disposition in the author edition\
A01 & C0; C1; C3 & The seed--field/operator-chain scope is retained. Standard component mathematics is not claimed as a new physical law.\
A02 & C3, Sec. 2 & The explicit $X/Y$ grammar, pair algebra and brackets are retained; v2 parameters and code paths are made explicit.\
A03 & C4, pp. 1--3 & S-curve shape does not establish a cryptographic pairing. No finite-field pairing or cryptographic security claim is implemented.\
A04 & C4, pp. 3--4 & STM, Ohm's law and the Miller algorithm are not connected by a supplied derivation or apparatus. This chain is not a theorem premise.\
A05 & C4, pp. 5--8 & A program run is not a "physical proof" of the engine's proposed ontology. Verification targets are stated independently.\
A06 & C4, p. 6 & Earlier exponential envelopes have incompatible scaling. This edition declares a path and units before deriving time.\
A07 & C4, p. 8 & The half-angle second polynomial factor and full-angle root conflict. Both $\kappa=1/2$ and $\kappa=1$ are preserved as distinct models.\
A08 & C0; C1; C4, p. 8 & Positive exponential branches are reciprocal in normalized delay, not necessarily linearly mirrored time curves.\
A09 & C4, pp. 8--9 & "All words as SDF operators" is typed as rewrite, interpreter and field compilation. Reachable words need not represent every field.\
A10 & C2, pp. 1--3 & Explicit two-arc union and baseline are retained. Conditional folding is tested rather than universally assumed.\
A11 & C2, p. 2 & A query-coordinate fold denotes a preimage when used to define a set; the forward-image notation is not silently adopted.\
A12 & C2, pp. 2--3; C4, p. 14 & A min of exact primitive SDFs is sign-correct but not generally an exact interior union distance. The distinction is retained.\
A13 & C2, pp. 7--9 & A baseline clip, orientation marker and event-time root are separate operations. The hinge diagram supplies no physical parity law.\
A14 & C2, p. 8 & For the stated centers, the tangent-circle hinge is $(0,0)$ when spacing equals radius. The claimed $(0,R)$ coordinate is not used.\
A15 & C4, pp. 9--10 & Rotor direction does not determine the field's inside/outside sign. Reflected occupancy is preserved for reflected geometry.\
A16 & C4, pp. 10--11 & Historical symbolism and a $45$-degree rotation do not mathematically cause generative balance or collapse. Rotation remains an isometry.\
A17 & C4, pp. 11--12 & The distinction between operators and interpretive stories is retained as a semantic non-identification result, not a verdict on meaning.\
A18 & C4, p. 12 & Fertilization is not established as the toy exponential event or quantum collapse. $XX/XY$ remain declared symbolic seeds.\
A19 & C4, pp. 12, 15 & Parenthood is not mathematically reduced to a time sink or a scalar bottleneck. The kernel makes no such human classification.\
A20 & C4, p. 13 & The generic reaction--diffusion--advection template is retained. Reaction laws, boundary conditions and material units are added explicitly.\
A21 & C4, pp. 13--14 & A no-flux condition with advection concerns total relative flux. A Neumann gradient condition alone is insufficient in general.\
A22 & C4, p. 14 & Removing outside stencil edges and updating the diagonal is implemented as a closed finite graph. Curved-boundary exactness is not claimed.\
A23 & C4, p. 14 & The normalized gradient can fail at nonsmooth composite locations. The finite graph does not require a universal smooth SDF normal.\
A24 & C4, pp. 14--15 & A seed change need not invert topology or uniquely reshape every pattern. A sampled-margin lemma and noninjective examples are provided.\
A25 & C4, p. 15 & Curvature alone does not create a mass sink in a closed diffusion graph. Connectivity can restrict transport without destroying mass.\
A26 & C4, pp. 14--15 & Turing patterns are not guaranteed by a seed or a Laplacian. The minimal reversible reaction has no diffusion-driven growing mode under L12.\
A27 & C4, p. 13 & Concentration-triggered growth is implemented as a sampled threshold with dwell and generation caps, not as instantaneous exact biological timing.\
A28 & C4, pp. 15--16 & The claim that CRISPR cutting is fictitious is unsupported by the formalism and contradicted by the limited primary-source check E3.\
A29 & C4, p. 16 & A local geometric edit can break symmetry without invalidating the whole field. A nonempty edited capsule union is explicitly tested.\
A30 & C4, p. 16 & Hadamard transforms do not reject asymmetric inputs. Their real orthogonal/invertible character is proved and tested.\
A31 & C4, pp. 16--17 & A "sieve" becomes a declared permeability-like interface. No molecular equivalence, ion-channel model or membrane measurement is supplied.\
A32 & C4, p. 17 & "Valves are vortices" is not established as a physical identity. Ambient swirl and edge permeability are separate model inputs.\
A33 & C4, p. 17 & Periodic-table or bond language does not specify $\mathcal R$. The implemented $U\rightleftarrows V$ law is an added, minimal conservative choice.\
A34 & C4, p. 17 & Physical reality's closure is not proved. The theorem uses an explicit closed control-volume assumption; open systems need source and flux terms.\
A35 & C4, pp. 17--18 & The ambient field exists independently of local geometry. A vector field is a section of the tangent bundle, not literally an infinite axis.\
A36 & C4, p. 18 & Log-radius covers all finite real values on the punctured plane. The origin is excluded and the software window remains finite.\
A37 & C0; C2; C4 & A frame is not automatically an eigenbasis; an operator must be specified. No attenuation law is inferred from an arbitrary frame eigenvalue.\
A38 & C0; C2, pp. 4--6 & Log-polar lookup and spatial indexing are finite approximations and acceleration proposals. No universal zero-cost query is asserted.\
A39 & C0; C3 & IPD length and ITD time have separate interfaces. "IDT" remains undefined for implementation purposes.\
A40 & C0; C2, pp. 5--6 & Occupancy, pulse-density coding, Bernoulli thresholding, bit serialization and parity are distinct. Internal float arrays are not erased by one-bit output.\
A41 & C0; C2 & XOR with arbitrary noise is not a universal fidelity improvement. No blue-noise spectrum or guaranteed perceptual benefit is claimed.\
A42 & C0; C2, pp. 8--9 & No wormhole, charge--parity boundary, electron tunneling law or quantum collapse is derived from an SDF hinge or jitter.\
A43 & C0; C2, pp. 10--12 & The asserted deterministic migraine/nausea pathways are not implemented or validated. No diagnosis, exposure recommendation or clinical safety claim follows.\
A44 & C2, p. 11 & The vestibular sketch's inconsistent label placement is not used as anatomical evidence. Model figures are not physiological diagrams.\
A45 & C0; C1; C3 & Memory is modeled as a bounded, mutable state with feedback, not necessarily permanent etching or mitosis. Biological substrate claims remain hypotheses.\
A46 & C0; C1; C3 & Spiritual interpretation remains distinct from measured physical variables. L10 states the limit of an unobserved label.\
A47 & C3; present update & The old tests and algebra fragments are adapted and rerun. New transport, reaction, remap and coding checks are separately recorded.\
A48 & Present update & The full formalization is attributed to Tom Klootwijk as requested. Personal attribution is documentary, not a numerical or physical parameter.\

## Gambit extension: forty-eight-page corpus {#gambit-extension-forty-eight-page-corpus .unnumbered}

P.08P.19P.64 ID & Source & Explicit disposition\
A49 & C6, pp. 1--48 & The Gambit record is a conversation containing user questions and generated responses. Neither repetition nor agreement constitutes independent evidence. Its contributions are tracked as source, definition, theorem, hypothesis or interpretation.\
A50 & C6, pp. 11, 14 & The printed half-angle second factor and full-angle root do not agree. Both polynomial variants remain explicit diagnostics; neither is silently selected as a biological time law.\
A51 & C6, p. 15 & The alphabet, word set, production function, state-transform family and generated boundary-field family are different objects. Composition relates them; it does not make every word every possible SDF.\
A52 & C6, pp. 16--19 & Chirality, field sign and historical symbolism are separated. A reflection need not flip occupancy, and a 45-degree rotation does not mathematically force destructive dynamics.\
A53 & C6, pp. 20--21 & A sperm/egg narrative and a toy temporal root do not specify fertilization dynamics. Symbolic XX/XY seeds remain computational labels, not a biochemical or human-classification mechanism.\
A54 & C6, pp. 22--25 & Capsule minima give declared union membership but not globally exact interior distance. Masked graph transport is a finite closed approximation, not a fully specified curved-boundary PDE solution.\
A55 & C6, pp. 25--27 & The claim that double-mirrored geometry makes cutting fictitious is not adopted. Legal local edits remain mathematically defined (L17); the separate primary result E3 documents Cas9 DNA cleavage.\
A56 & C6, pp. 27--29 & Closure is an explicit model assumption, not a conclusion about the universe. Material conservation is proved for declared control-volume laws only.\
A57 & C6, p. 28 & Vortex velocity and membrane-like permeability are separate inputs. No evidence in the source identifies every biological valve with a vortex.\
A58 & C6, pp. 29--30 & The ambient space is independent of local hinges; the log-radius axis is unbounded as a mathematical domain. The reference computer still uses a finite window and finite resources.\
A59 & C6, pp. 30--31 & Lowercase i and uppercase I can be given a graphical analogy, but character identity and font-dependent glyph shape are not physical transition laws. E5 supplies the limited Unicode distinction.\
A60 & C6, p. 31 & The pipe is not used as a universal set-union command. Operators require declared syntax; the current executable alphabet contains only X, Y, turns and brackets.\
A61 & C6, p. 31 & Union of a separated disk and stem does not fill their gap. A bridge, dilation or other explicitly added operation would be required. A constructive witness and regression test preserve this distinction.\
A62 & C6, p. 32 & Journey/godspeed language is preserved as interpretation of paths and goals. No etymological claim or new physical speed law is established by the kernel.\
A63 & C6, pp. 32--34 & Christian IT is recorded as the requested author perspective, not as a theorem, universal Christian doctrine, or a prediction made by the numerical model.\
A64 & C6, p. 33 & The Father/seed, Son/interpreter and Spirit/field comparison is an interpretive stage mapping. The underlying mathematical objects and numerical laws remain separately defined.\
A65 & C6, pp. 34--35 & A one-bit initial Word can select at most two predefined cases for a fixed decoder. The decoder, rules, parameters, clock and input environment are additional structure (L16).\
A66 & C6, p. 35 & The current kernel uses floating-point arrays internally and an exact integer codec at the output. One-bit serialization does not eliminate internal calculations or create zero physical latency.\
A67 & C6, pp. 35--36 & Evolution-as-L-system is a modeling analogy. No ancestral genetic record, evolutionary experiment or calibration is supplied; the demonstrator is not a reconstructed history of life.\
A68 & C6, p. 36 & The claim that an asymmetric or tilted mutation must fail is not a consequence of the geometry. No universal biological survival rule is inferred from rotor symmetry.\
A69 & C6, p. 37 & The God/dog reversal and hourglass motif are preserved as language and visual analogy. Reversing a string does not establish a spatial reflection or a physical identity.\
A70 & C6, pp. 37--38 & The V/womb motif is interpretive. The simulated closed graph is not a model of gestation, maternal exchange or developmental physiology.\
A71 & C6, pp. 38--39 & The source itself rejects a literal one-bit, no-alternative account of genetic expression at this point. Edition 3.0 records that qualification alongside the later stronger postulate.\
A72 & C6, pp. 39--41 & Different organism and material names motivate a common interface question, not a classifier. The engine does not model the cited organisms or claim their mechanisms are physically identical.\
A73 & C6, p. 40 table & The quantum-state row supplies a Walsh-Hadamard label but no quantum state preparation, Hamiltonian or measurement rule. Orthogonal real matrix operations alone do not implement that physical claim.\
A74 & C6, pp. 41--42 & A reusable one-bit latch is implemented. Reducing the complete system to a binary state requires the exact congruence condition of L15; a finite example succeeds and an occupancy counterexample fails.\
A75 & C6, p. 41 & Molecules-as-passive-digital-ink is retained as a strong substrate interpretation, not as the implemented reaction law or an experimentally supported reduction of chemistry.\
A76 & C6, p. 42 & Shared representability does not prove identity between a cell and a silicon machine. Their physical realization and the consciousness bridge remain outside the mathematical invariant proof.\
A77 & C6, pp. 42--43 & The source connects two-state language to F/M, while also acknowledging biological variation. This formalization uses symbolic XX/XY seeds and draws no conclusion about a person's gender or value.\
A78 & C6, p. 43 & No single-cause account of human variation, diagnosis or intervention is generated. The supplied qualitative biological narrative is not a calibrated model in the kernel.\
A79 & C6, p. 44 & Black/white and female/male labels do not define the semantics of a bit. Zero-set membership uses a declared tie convention; no cultural, biological or moral ranking follows.\
A80 & C6, pp. 44--45 & Quintessence names the ambient framework in the interpretation record. It does not add an independently measured substance, physical field law, energy source or cosmological result.\
A81 & C6, pp. 46--47 & $\Sigma$-as-male and V-as-female are source archetypes, not properties of the formal alphabet, seed or metric. The numerical program does not use sex or theology as a control variable.\
A82 & C6, pp. 47--48 & The notation is explicitly migrated: capital $\Sigma$ is the alphabet set, the admissible seed family is a separate set, and lowercase $\sigma$ is one structured seed. Tagged records can be represented as sets without erasing multiplicity.\
A83 & C6, p. 48 & An ordered tuple or tagged record specifies components, not the temporal order of every operation by itself. Edition 3.0 states the causal update order, thresholds, tie rules and finite budgets explicitly.\
A84 & Edition 3.0 & The publication is a finalized research edition with runnable artifacts. Tests, SMT fragments and file hashes establish their declared targets, not consciousness, spiritual ontology, identity verification or intellectual priority.\

# Notation and proof-to-code index

\@lY@ Symbol & Meaning and restriction\
$\Sigma,\Sigma^*$ & Alphabet set and finite-word set; not complete initialization data.\
$\mathfrak S_N,\sigma$ & Admissible seed family and a complete versioned seed, including input and numerical conventions.\
$p,w_g,P$ & Ordered token pair, generation word and parallel rewriting operator.\
$M,g,v$ & Ambient manifold, metric and vector field; the implementation uses Euclidean $\mathbb{R}^2$.\
$F_G,F_M,F_{g,m}$ & Capsule, double-arc and combined boundary fields; sign-correct composites.\
$F_\kappa$ & Separate auxiliary polynomial with full- or half-angle second factor.\
$\rho,\theta,r_0$ & Log-radius, circular angle and positive reference length.\
$\phi_-$ & $(\sqrt5-1)/2$, a dimensionless toy-geometry parameter.\
$T,t_0,c_s$ & Event time, reference time and declared propagation speed.\
$\mu,c,V$ & Represented mass, concentration and cell-volume conversion.\
$Q,L_h,\Pi,R_n$ & Directed column generator, symmetric graph Laplacian, remap and reaction matrix.\
$z,m,y$ & Fast state, slower memory and bounded model observations.\
$b,e,\delta_h$ & Persistent latch bits, transition-event bits and positive hysteresis threshold.\
$\pi,\overline{\mathcal K}$ & Candidate state encoding and exact reduced transition, when the congruence condition holds.\
$D_c,k,q,r$ & Dyadic codec denominator, integer input, output pulse and integer residual.\
$J,R_\theta$ & Reflection and rotation; not a physical charge--parity operation.\

P.12P.39P.40 Result & Mathematical focus & Supporting executable material\
U3 & Composition, invariants and exact reduction criterion & Written proof; component tests; $XX/XY$ traces; finite quotient examples.\
L1 & Pair, grammar, counts and replay & K01--K05; grammar and replay tests.\
L2 & Set semantics and field bounds & K06--K10; distance, fold and membership counterchecks.\
L3 & Rigid covariance, sign distinction & K11, K33; reflection and graph-permutation tests.\
L4 & Charts, roots and bisection & K17 fragment; both root variants and chart tests.\
L5 & Transport positivity and conservation & K21--K24; graph, substep, energy and $\ell^1$ tests.\
L6 & Reversible reaction & K25 and K24 algebra; local reaction tests.\
L7 & Conservative remapping & K26--K27; shrinking, expanding, support and tie tests.\
L8 & Bounded recurrence and memory & K19 fragment; both recurrent test suites.\
L9 & Integer codec, parity, Hadamard & K12--K15, K18, K28--K29; exhaustive short codec words and other coding tests.\
L10 & Interpretive and sign non-identification & K16, K34 fragments; author-field independence and asymmetric-input tests.\
L11 & Conditional contraction & K20 fragment; separate fixed-input geometry-only recurrence.\
L12 & Margins and pattern limitations & K30--K32; mode-spectrum and noninjective-seed tests.\
L13 & Alphabet, records and word semantics & Alphabet closure and multiplicity tests; written monoid argument.\
L14 & Binary hinges and causal gates & K35--K39; latch and integration tests.\
L15 & Exact deterministic quotient & K45 fragment; exhaustive finite checker and 508 traces.\
L16 & Fixed-decoder information capacity & K44 fragment; integer capacity tests.\
L17 & Admissible local editing & K43 fragment; legal edit, translation-bound and union-gap tests.\
L18 & Robust latch traces and dwell bound & K40--K42, K46; strict-margin and relay-example tests.\

The registry does not imply that every analytic clause is encoded by its listed algebra fragment. In particular, arbitrary-dimensional inductions, manifold statements, PDE templates and empirical bridge hypotheses are not solver-certified by the small finite identities.

# References and reference scope

Original conversation notes, supplied as Pasted markdown.md. Conceptual source, not experimental evidence.\
Archived as `sources/original_notes.md`.

Tom Klootwijk's Seed--Field Theory of Consciousness and the Senses. Supplied 28-page research manuscript, prior author edition. Archived as `sources/seed_field_revision_1.pdf`.

Double-arc M with UU double-set SDF notation (signed-distance-field). Supplied twelve-page exported conversation. Archived as `sources/double_arc_addendum.pdf`. Page-specific dispositions appear in Appendix A.

Intermediate theorem-and-kernel revision supplied in the conversation, 25-page PDF and companion ZIP. Consulted for eighteen component theorems, symbolic pairings and executable infrastructure. Original inputs are hash-referenced in `provenance/source_manifest.json`; the present code is adapted and revalidated.

Tom Klootwijk NL200678942 10-07-1990. Supplied eighteen-page conversation corpus. Archived as `sources/unification_corpus.pdf`. Its assistant-generated assertions are distinguished from the user's questions and from evidence.

Tom Klootwijk AI Engine: Unified Seed--Field Theorem and Theory of Consciousness, Edition 2.0. Supplied 26-page manuscript and companion code archive. PDF archived as `sources/author_edition_2.pdf`; archive fingerprint is recorded in the source manifest. U3 extends rather than silently relabels its U1 composition result.

Tom Klootwijk NL200678942 10-07-1990 Gambit. Supplied 48-page conversation PDF, archived unchanged as `sources/gambit_corpus.pdf`. Primary conceptual source for this revision; assistant-generated assertions within it are not independent scientific evidence.

Przemyslaw Prusinkiewicz and Aristid Lindenmayer. The Algorithmic Beauty of Plants. Springer, 1990, Chapter 1. [Author-hosted chapter](https://algorithmicbotany.org/papers/abop/abop-ch1.pdf). Outside context for parallel rewriting and turtle interpretation only; not evidence for this grammar's biological or consciousness interpretation.

John C. Hart. "Sphere tracing: A geometric method for the antialiased ray tracing of implicit surfaces." The Visual Computer 12 (1996), 527--545. DOI: 10.1007/s003710050084. [Author manuscript hosted by Stanford](https://graphics.stanford.edu/courses/cs348b-20-spring-content/uploads/hart.pdf). Outside context for distance bounds and implicit geometry; no empirical support for this engine's ontology is inferred.

Martin Jinek, Krzysztof Chylinski, Ines Fonfara, Michael Hauer, Jennifer A. Doudna and Emmanuelle Charpentier. "A programmable dual-RNA-guided DNA endonuclease in adaptive bacterial immunity." Science 337 (2012), 816--821. DOI: 10.1126/science.1225829. [Primary article abstract, PMID 22745249](https://pubmed.ncbi.nlm.nih.gov/22745249/). Used narrowly to check the corpus's assertion denying DNA cleavage; not cited as evidence for the consciousness theory or as a biological protocol.

Nikolaj Bjørner, Leonardo de Moura, Lev Nachmanson and Christoph Wintersteiger. Programming Z3. [Authors' tutorial](https://z3prover.github.io/papers/programmingz3.html). Outside documentation of the solver method; not an independent verification of this package.

Unicode Consortium. Glossary of Unicode Terms, entries "Abstract Character" and "Glyph". [Official glossary](https://www.unicode.org/glossary/). Used only to distinguish a character's identity from its rendered appearance, not as support for the corpus's theological or physical glyph interpretation.

External references were checked on 11 September 2026. The author-hosted chapter and geometric manuscript were consulted for the stated mathematical context, not for their figures or experimental data. The new written derivations, added hinge and quotient laws, and implementation decisions are explicitly the formalization in this edition. None of the external references is an endorsement of the consciousness theory. Bibliographic data are also supplied in `manuscript/references.bib`.

**Closing formulation.** Gambit's unified theorem establishes invariants of a seed-driven, boundary-coupled computation and a criterion for an exact reduced description. Its broader consciousness theory remains a candidate empirical bridge. The mathematical result, executable implementation and interpretive claims are separate objects of evaluation.
