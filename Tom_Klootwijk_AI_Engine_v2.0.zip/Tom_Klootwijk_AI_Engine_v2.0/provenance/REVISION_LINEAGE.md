# Revision lineage

## Current author edition
Tom Klootwijk AI Engine 2.0.0. Author designation: Tom Klootwijk; supplied identifier NL200678942; supplied date 10-07-1990.

The current engine name, PDF author metadata, manuscript and kernel package use the restored author designation. Documentary attribution is not a numerical seed and is not independently identity-verified.

## Consulted record
C0 supplies the original conceptual operator chain. C1 adds the earlier author-attributed seed-field formalization. C2 supplies the double-arc addendum. C3 supplies the intermediate component theorem family and numerical infrastructure. C4 supplies the new reaction-diffusion, sieve, paired-curve and ambient-field corpus.

The current `kernel/core.py`, `kernel/spatial.py`, the 55 component tests, the Z3 adapter and the first twenty algebra fragments were adapted from C3. The former class name is replaced by `KlootwijkKernel`; versioning is updated. The new `UnifiedKernel` adds a strict configuration schema, finite masked transport, reaction, conservative geometry changes, sampled growth, and integer pulse-density coding. All checks were rerun rather than inherited from old logs.

The sixteen-bit integer codec complements, rather than erases, the earlier real-valued/threshold coding account. The full-angle and half-angle time polynomials are explicit separate variants. The default embedding scale is now 1.0; geometry starts at generation one and can reach generation four under the growth predicate. The source audit records these choices and the unsupported conclusions in the conversational corpus.

The original intermediate PDF/ZIP are hash-referenced, not reissued under the new authorship. Original uploaded inputs C0/C1/C2/C4 are preserved as source records. External papers and font/solver binaries are not bundled.
