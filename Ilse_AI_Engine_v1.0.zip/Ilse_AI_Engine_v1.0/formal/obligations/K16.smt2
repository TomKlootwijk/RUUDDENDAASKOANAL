; K16: Positive field rescaling preserves the occupancy predicate
; Manuscript: T13. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const k Real)
(declare-const x Real)
(assert (not (=> (> k 0) (= (<= (* k x) 0) (<= x 0)))))
(check-sat)
(get-proof)
