# Author attribution and scope

**Author: Tom Klootwijk**  
**Identifier as supplied: NL200678942**  
**Date as supplied: 10-07-1990**

Engine: Tom Klootwijk AI Engine. Continuing framework terminology: Klootwijk Seed-Field Framework (KSFF); current implementation name: Klootwijk Seed-Field Engine (KSFE). Version: 2.0.0. Edition date: 11 September 2026.

This is an AI-assisted formalization and implementation prepared from the supplied corpus under the requested author designation. Attribution is not independent verification of identity, patent ownership, scientific priority, or the novelty of the standard mathematics. The prior alternate perspective designation is not the current manuscript's authorship.

The package includes personal identifying details because they were expressly requested. Source PDFs also retain user-supplied personal details and original conversational assertions. Review these files before public distribution. Author metadata and input identity strings do not enter the numerical state laws.

This is a research model, not a consciousness detector, biological mechanism, medical device, genetic protocol, acoustic driver or verified physical theory. Written proofs establish the declared mathematical results; solver checks cover algebraic fragments; tests cover finite program examples. The connection to conscious experience is a hypothesis requiring measurements and discriminating tests. Spiritual interpretation is not converted into an unmeasured physical quantity.
