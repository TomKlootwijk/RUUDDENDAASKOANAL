; K01: Pair parity is exchange-invariant
; Manuscript: T1. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Bool)
(declare-const b Bool)
(assert (not (= (xor a b) (xor b a))))
(check-sat)
(get-proof)
