# Verification summary

**Ilse AI Engine 1.0.0 — 11 September 2026**

## Executed records

| Item | Result | Record |
| --- | --- | --- |
| Python regression suite | 55 tests passed | `results/tests.txt` |
| SMT counterexample checks | All 20 returned UNSAT and emitted a proof log | `results/formal_results.json`, `results/formal/` |
| Solver | Z3 4.13.3.0 | `results/formal_check.txt` |
| XX and XY generation-four counts | 162 draw operations, 406 word tokens each | `results/growth_counts.csv` |
| Closed-loop contraction q | 0.94464 | `results/metrics.json` |
| Step-180 computed separation | 1.7951040525527803e-07 | `results/state_trajectory.csv` |
| Step-180 contraction envelope | 3.178206958648021e-05 | `results/state_trajectory.csv` |
| 1,000 LUT queries | Maximum error 0.0266515313; 0 certificate violations | `results/lut_queries.csv` |
| 100 capsule BVH queries | Maximum difference from exhaustive evaluation 0; median 10/162 primitive evaluations | `results/bvh_queries.csv` |
| 11 threshold coding inputs, 25,000 samples each | Maximum empirical mean error 0.00444 | `results/quantization.csv` |

The complete configuration digest is
`ffe3395583024cc8ae931beab5a682b8fc44b1e2cbd82559219882ed77ae1f5f`.
All coordinates not explicitly assigned physical units are simulation units.

## Trust boundaries

The eighteen theorem statements have written proofs under their assumptions.
Twenty algebraic fragments are separately expressed as SMT-LIB counterexample
queries. Their UNSAT results depend on the Z3 implementation, supported theories
and correct translation. Solver proof logs are included but were not independently
replayed in a different small proof kernel. This is not a machine-checked proof of
the entire Python implementation or of all analytic arguments.

The regression tests and numerical samples are finite checks. They do not prove
all floating-point paths, every geometric query, random-number quality or absence
of implementation defects. BVH query counts are not a hardware latency benchmark.
The quantization experiment is not a sensory-safety study.

There are no human, animal or cell data. No claim about consciousness, clinical
causation, genetic identity or spiritual ontology has been empirically verified.
The source audit and theorem registry provide the intended scope for each result.

## Publication checks

The final manuscript has 25 pages. Rendered pages were visually reviewed, and the
last adjusted theorem page was rechecked. Text extraction found all 18 theorem
headings and no Unicode replacement characters. The typesetting build reported no
overfull boxes. This is a production check, not independent mathematical review.
