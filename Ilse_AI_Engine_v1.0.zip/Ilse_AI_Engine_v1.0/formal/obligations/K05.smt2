; K05: Growth count update preserves the difference
; Manuscript: T3. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const x Int)
(declare-const y Int)
(assert (not (= (- (+ (* 2 x) y) (+ x (* 2 y))) (- x y))))
(check-sat)
(get-proof)
