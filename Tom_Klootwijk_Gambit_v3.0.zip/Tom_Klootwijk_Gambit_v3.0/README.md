# Tom Klootwijk Gambit — Edition 3.0
## Unified Seed–Field Theorem and Theory of Consciousness

**Author: Tom Klootwijk · NL200678942 · 10-07-1990**  
**Kernel version: 3.0.0 · Research edition dated 11 September 2026**

This package contains the finalized Edition 3.0 manuscript, written mathematical proofs, an executable Python kernel, complete symbolic XX/XY seeds, tests, numerical histories, finite-state quotient examples and source provenance. The manuscript distinguishes mathematical results, new implementation choices, consciousness hypotheses and the author's Christian interpretation.

The central result, **Unified Theorem U3**, combines the seed–field composition invariants with explicit binary hinges and a necessary-and-sufficient condition for an exact reduced state model. The full engine is **not** asserted to be a two-state machine: it stores geometry, chemical mass, recurrent activity, memory, latch bits, time counters and a codec residual.

## Read first

`Tom_Klootwijk_Gambit_Edition_3.0.pdf` is the typeset manuscript. The authoritative editable source is `manuscript/Tom_Klootwijk_Gambit_Edition_3.0.tex`; the matching Markdown is a reading/editing edition. `docs/UNIFIED_THEOREM_U3.md` and `docs/SUPPORTING_PROOFS.md` expose U3 and all eighteen lemmas. `docs/KERNEL_SPEC.md` fixes the update order and model contracts.

**Privacy:** the manuscript, this file, seed metadata and preserved source documents contain the personal attribution details supplied by the requester. Source conversations also contain superseded or unsupported claims. They are preserved as provenance, not endorsed as scientific evidence. Review the entire archive before public redistribution.

## Reproduce

Python 3.13.5 was used for the recorded delivery; the pinned dependencies target that environment. Other Python versions require their own compatibility check. Run from the extracted package root:

```bash
python verify_package.py
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m kernel --out rerun
```

The last command runs both complete seeds, writes numerical data under `rerun/XX` and `rerun/XY`, and creates figures under `rerun/figures`. It does not transmit data, drive hardware, play sound or present flashing stimuli. To run just one seed:

```bash
python -m kernel --config config/seed_xy.json --out rerun_xy
```

A plain `python -m kernel` regenerates the delivered `results/` and manuscript figures. Prefer a new output directory to retain the original evidence. Run the checksum verification **before** changing or regenerating files; byte differences after rebuilding are expected.

## Inspect or use the kernel

```python
from kernel.gambit import GambitSpec, GambitKernel
from kernel.quotient import FiniteMachine, analyse_quotient

spec = GambitSpec.load("config/seed_xy.json")
engine = GambitKernel(spec)
state, history = engine.run()
assert all(row["codec_certificate"] for row in history)
assert all(row["frame_even"] for row in history)
print(state.latches, engine.fingerprint())

machine = FiniteMachine(
    ((1, 2), (0, 3), (3, 0), (2, 1)),
    (0, 0, 1, 1),
)
print(analyse_quotient(machine, (0, 0, 1, 1)))
```

The quotient checker verifies a **provided finite table**. It does not automatically discretize the full Gambit state, infer unseen transitions or identify consciousness. Invalid reduction candidates return representative witnesses. The companion example checks 508 finite histories and supplies a continuous sign-only counterexample.

## Mathematical checks and manuscript rebuild

An external Z3 installation is required for solver re-execution. Either an installed `z3` executable or the official shared library is supported. With the library, `Z3_LIBRARY` can specify its local path. No solver binary is bundled.

```bash
python formal/make_obligations.py
python formal/check.py
python formal/counterexamples.py
bash manuscript/build.sh
python manuscript/export_markdown.py
```

The PDF build requires a LaTeX installation with the packages in the source preamble, including `newtx`, `inconsolata`, `tcolorbox` and `hyperref`. Markdown export additionally requires Pandoc. Fonts are not bundled. `run_checks.sh` runs checksum verification, the unit suite, the two solver checks and simulations into a separate rerun directory; it stops on errors.

## What is included

| Directory | Contents |
|---|---|
| `kernel/` | Geometry, grammar, transport, reactions, recurrence, hinges, exact integer coding, finite quotient checking and local-edit utilities. |
| `config/` | Complete current XX/XY Gambit seeds and explicit baseline composition-core configurations. |
| `manuscript/` | LaTeX, Markdown, bibliography, rebuild script and reproducible scientific figures. |
| `docs/` | Theorem, eighteen proofs, kernel specification, interpretation record, migration notes, research plan, 84-entry claim audit and result registry. |
| `tests/` | 145 regression tests, including the 99 inherited tests and 46 new Gambit tests. |
| `formal/` | 46 SMT-LIB proof obligations, three constructive SAT cases and the runners. |
| `results/` | Fresh test/solver logs, XX/XY data, fingerprints, certificates and quantitative summaries. |
| `sources/` | Unmodified user-supplied source documents and prior author manuscripts. |
| `provenance/` | Source hashes, revision lineage, explicit computational changes and reference scopes. |

## Evidence boundaries

All 145 tests passed in the delivery environment. Z3 4.13.3.0 returned UNSAT with proof logs for 46 stated algebraic targets and SAT for three intentionally constructed counterexamples. These are not a full proof-assistant verification of the Python implementation. Floating-point tolerances and exact integer codec certificates are reported separately. Same-environment replay does not promise cross-platform bitwise identity of floating-point results or regenerated PDFs.

No empirical consciousness score, human classification, biomedical protocol, genotype model, theological measurement, zero-latency hardware result or intellectual-property priority claim is supplied. The numerical laws are uncalibrated simulation choices. Their correspondence to bodily experience and conscious organization remains an explicit research hypothesis.
