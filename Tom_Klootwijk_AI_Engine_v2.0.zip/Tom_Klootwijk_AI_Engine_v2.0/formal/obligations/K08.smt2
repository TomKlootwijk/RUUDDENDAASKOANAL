; K08: Ground clipping equals membership and y nonnegative
; Manuscript: L2. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const f Real)
(declare-const y Real)
(define-fun mx ((x Real) (y Real)) Real (ite (>= x y) x y))
(assert (not (= (<= (mx f (- y)) 0) (and (<= f 0) (>= y 0)))))
(check-sat)
(get-proof)
