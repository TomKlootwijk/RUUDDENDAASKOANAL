; K04: Growth count update triples the sum
; Manuscript: T3. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const x Int)
(declare-const y Int)
(assert (not (= (+ (+ (* 2 x) y) (+ x (* 2 y))) (* 3 (+ x y)))))
(check-sat)
(get-proof)
