# Synthetic demonstration results

These are generated numerical examples, not measurements of people, consciousness, spirituality, or hardware speed.

```json
{
  "data_status": "Synthetic mathematical demonstrations; not biological or consciousness evidence",
  "configuration": {
    "seed": 42,
    "generations": 3,
    "axiom": "F",
    "rule": "F[+F]F[-F]F",
    "step": 0.12,
    "radius": 0.035,
    "angle_deg": 25.0,
    "jitter_deg": 1.5,
    "branch_scale": 0.78
  },
  "environment": {
    "python": "3.13.5",
    "numpy": "2.3.5",
    "matplotlib": "3.10.8"
  },
  "segment_count": 125,
  "symbol_count": 311,
  "max_abs_byte_reconstruction_error": 0.0019607843137254832,
  "byte_error_bound": 0.00196078431372549,
  "max_abs_pdm_prefix_error": 1.0000000000000073,
  "pdm_mean_error": 1.4094628242311558e-18,
  "pdm_even_parity": 0,
  "memory_bits": 64,
  "stored_patterns": 4,
  "cue_errors": 8,
  "retrieved_errors": 0,
  "memory_energy_nonincreasing": true,
  "itd_point_receiver_seconds": 0.00023453737024003185,
  "illustrative_visual_disparity_pixels": 32.0,
  "bracketed_sphere_crossing_seconds": 0.9999999999854481,
  "optical_1mm_ng4_delay_seconds": 1.3342563807926083e-11,
  "same_seed_reproducible": true
}
```
