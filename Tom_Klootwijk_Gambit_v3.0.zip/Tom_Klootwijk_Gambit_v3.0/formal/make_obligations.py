"""Generate reviewable SMT-LIB counterexample queries for the discrete core.

A query being unsatisfiable establishes its stated identity/implication in the
encoded mathematical theory. It is not a proof of the numerical Python program.
"""
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
OBLIGATIONS=[]
def add(id,title,theorem,decl,formula):
    OBLIGATIONS.append(dict(id=id,title=title,theorem=theorem,declarations=decl,formula=formula))
B='(declare-const a Bool)\n(declare-const b Bool)\n'
R='(declare-const a Real)\n(declare-const b Real)\n'
minimum='(define-fun mn ((x Real) (y Real)) Real (ite (<= x y) x y))\n'
maximum='(define-fun mx ((x Real) (y Real)) Real (ite (>= x y) x y))\n'
absolute='(define-fun ab ((x Real)) Real (ite (>= x 0) x (- x)))\n'
add('K01','Pair parity is exchange-invariant','T1',B,'(= (xor a b) (xor b a))')
add('K02','Symbol exchange is an involution','T1',B,'(and (= (not (not a)) a) (= (not (not b)) b))')
add('K03','Boolean sorted-pair canonicalization is idempotent','T1',B,'(and (= (and (and a b) (or a b)) (and a b)) (= (or (and a b) (or a b)) (or a b)))')
add('K04','Growth count update triples the sum','T3','(declare-const x Int)\n(declare-const y Int)\n','(= (+ (+ (* 2 x) y) (+ x (* 2 y))) (* 3 (+ x y)))')
add('K05','Growth count update preserves the difference','T3','(declare-const x Int)\n(declare-const y Int)\n','(= (- (+ (* 2 x) y) (+ x (* 2 y))) (- x y))')
add('K06','Minimum is closed-set union at zero','T5',R+minimum,'(= (<= (mn a b) 0) (or (<= a 0) (<= b 0)))')
add('K07','Maximum is closed-set intersection at zero','T5',R+maximum,'(= (<= (mx a b) 0) (and (<= a 0) (<= b 0)))')
add('K08','Ground clipping equals membership and y nonnegative','T5','(declare-const f Real)\n(declare-const y Real)\n'+maximum,'(= (<= (mx f (- y)) 0) (and (<= f 0) (>= y 0)))')
add('K09','Minimum preserves a shared Lipschitz difference bound','T6',R+'(declare-const c Real)\n(declare-const d Real)\n(declare-const e Real)\n'+minimum+absolute,'(=> (and (>= e 0) (<= (ab (- a c)) e) (<= (ab (- b d)) e)) (<= (ab (- (mn a b) (mn c d))) e))')
add('K10','Near-side reflection distance comparison','T7','(declare-const x Real)\n(declare-const u Real)\n','(=> (and (>= x 0) (>= u 0)) (<= (* (- x u) (- x u)) (* (+ x u) (+ x u))))')
add('K11','Reflection preserves squared Euclidean norm','T8','(declare-const x Real)\n(declare-const y Real)\n','(= (+ (* (- x) (- x)) (* y y)) (+ (* x x) (* y y)))')
add('K12','XOR equals integer sum modulo two','T12',B,'(= (ite (xor a b) 1 0) (mod (+ (ite a 1 0) (ite b 1 0)) 2))')
# Eight data bits and one even parity bit.
decl='\n'.join(f'(declare-const b{i} Bool)' for i in range(8))+'\n'
def xor(xs):
    xs=list(xs)
    if len(xs)==1:return xs[0]
    return f'(xor {xs[0]} {xor(xs[1:])})'
p=xor(f'b{i}' for i in range(8))
add('K13','Appended even parity gives an even nine-bit block','T12',decl,f'(= (xor {p} {p}) false)')
p1=xor(['(not b0)']+[f'b{i}' for i in range(1,8)])
add('K14','One selected payload-bit fault flips block parity','T12',decl,f'(= {p1} (not {p}))')
p2=xor(['(not b0)','(not b1)']+[f'b{i}' for i in range(2,8)])
add('K15','Two selected payload-bit faults preserve block parity','T12',decl,f'(= {p2} {p})')
add('K16','Positive field rescaling preserves the occupancy predicate','T13','(declare-const k Real)\n(declare-const x Real)\n','(=> (> k 0) (= (<= (* k x) 0) (<= x 0)))')
add('K17','Either bisection half has half the old width','T11',R,'(and (= (- (/ (+ a b) 2) a) (/ (- b a) 2)) (= (- b (/ (+ a b) 2)) (/ (- b a) 2)))')
add('K18','Unnormalized two-point Hadamard squared is twice identity','T15','(declare-const x Real)\n(declare-const y Real)\n','(and (= (+ (+ x y) (- x y)) (* 2 x)) (= (- (+ x y) (- x y)) (* 2 y)))')
add('K19','Convex slow-memory update preserves a bounded interval','T16','(declare-const m Real)\n(declare-const v Real)\n(declare-const eta Real)\n(define-fun nxt () Real (+ (* (- 1 eta) m) (* eta v)))\n','(=> (and (<= -1 m) (<= m 1) (<= -1 v) (<= v 1) (<= 0 eta) (<= eta 1)) (and (<= -1 nxt) (<= nxt 1)))')
add('K20','Nonnegative row-sum contraction bound','T17','(declare-const a Real)\n(declare-const b Real)\n(declare-const q Real)\n(declare-const ez Real)\n(declare-const em Real)\n(declare-const e Real)\n','(=> (and (>= a 0) (>= b 0) (>= e 0) (>= ez 0) (>= em 0) (<= ez e) (<= em e) (<= (+ a b) q) (< q 1)) (<= (+ (* a ez) (* b em)) (* q e)))')


# New v2 obligations: finite-dimensional algebraic fragments of U1.
add('K21','Two-node diffusion generator conserves total mass','L5',
    '(declare-const w Real)\n(declare-const x Real)\n(declare-const y Real)\n',
    '(= (+ (* w (- y x)) (* w (- x y))) 0)')
add('K22','Two-node diffusion quadratic form is nonpositive','L5',
    '(declare-const w Real)\n(declare-const x Real)\n(declare-const y Real)\n',
    '(=> (>= w 0) (and (= (+ (* x w (- y x)) (* y w (- x y))) (- (* w (- x y) (- x y)))) (<= (+ (* x w (- y x)) (* y w (- x y))) 0)))')
add('K23','Euler exit-rate bound gives a nonnegative diagonal','L5',
    '(declare-const dt Real)\n(declare-const r Real)\n',
    '(=> (and (>= dt 0) (>= r 0) (<= (* dt r) 1)) (>= (- 1 (* dt r)) 0))')
add('K24','Directed two-node Euler transport conserves mass','L5',
    '(declare-const dt Real)\n(declare-const a Real)\n(declare-const b Real)\n(declare-const u Real)\n(declare-const v Real)\n',
    '(= (+ (+ (* (- 1 (* dt a)) u) (* dt b v)) (+ (* dt a u) (* (- 1 (* dt b)) v))) (+ u v))')
add('K25','Reversible reaction is nonnegative under the step bound','L6',
    '(declare-const dt Real)\n(declare-const a Real)\n(declare-const b Real)\n(declare-const u Real)\n(declare-const v Real)\n',
    '(=> (and (>= dt 0) (>= a 0) (>= b 0) (>= u 0) (>= v 0) (<= (* dt a) 1) (<= (* dt b) 1)) (and (>= (+ (* (- 1 (* dt a)) u) (* dt b v)) 0) (>= (+ (* dt a u) (* (- 1 (* dt b)) v)) 0)))')
add('K26','Two-column stochastic remap preserves mass','L7',
    '(declare-const a Real)\n(declare-const b Real)\n(declare-const u Real)\n(declare-const v Real)\n',
    '(= (+ (+ (* a u) (* b v)) (+ (* (- 1 a) u) (* (- 1 b) v))) (+ u v))')
add('K27','Stochastic remap preserves nonnegativity','L7',
    '(declare-const a Real)\n(declare-const b Real)\n(declare-const u Real)\n(declare-const v Real)\n',
    '(=> (and (<= 0 a) (<= a 1) (<= 0 b) (<= b 1) (>= u 0) (>= v 0)) (and (>= (+ (* a u) (* b v)) 0) (>= (+ (* (- 1 a) u) (* (- 1 b) v)) 0)))')
add('K28','Fixed-point accumulator preserves residual interval','L9',
    '(declare-const D Int)\n(declare-const r Int)\n(declare-const k Int)\n(define-fun q () Int (ite (>= (+ r k) D) 1 0))\n(define-fun rn () Int (- (+ r k) (* D q)))\n',
    '(=> (and (> D 0) (<= 0 r) (< r D) (<= 0 k) (<= k D)) (and (<= 0 rn) (< rn D) (or (= q 0) (= q 1))))')
add('K29','Fixed-point one-step error telescopes','L9',
    '(declare-const D Int)\n(declare-const r Int)\n(declare-const k Int)\n(declare-const q Int)\n(declare-const rn Int)\n',
    '(=> (= rn (- (+ r k) (* D q))) (= (- (* D q) k) (- r rn)))')
add('K30','Strict field margin preserves occupancy','L12',
    '(declare-const f Real)\n(declare-const g Real)\n(declare-const e Real)\n'+absolute,
    '(=> (and (>= e 0) (> (ab f) e) (<= (ab (- f g)) e)) (= (<= f 0) (<= g 0)))')
add('K31','Two-species modal determinant has no negative value','L12',
    '(declare-const a Real)\n(declare-const b Real)\n(declare-const D1 Real)\n(declare-const D2 Real)\n(declare-const l Real)\n',
    '(=> (and (>= a 0) (>= b 0) (>= D1 0) (>= D2 0) (>= l 0)) (>= (+ (* (+ (* a D2) (* b D1)) l) (* D1 D2 l l)) 0))')
add('K32','Reaction-diffusion determinant expansion','L12',
    '(declare-const a Real)\n(declare-const b Real)\n(declare-const D1 Real)\n(declare-const D2 Real)\n(declare-const l Real)\n',
    '(= (- (* (+ a (* D1 l)) (+ b (* D2 l))) (* a b)) (+ (* (+ (* a D2) (* b D1)) l) (* D1 D2 l l)))')
add('K33','Origin reflection does not alter a scalar occupancy value','L3',
    '(declare-const f Real)\n(declare-const fr Real)\n',
    '(=> (= f fr) (= (<= f 0) (<= fr 0)))')
add('K34','A finite output bit cannot identify two positive magnitudes','L10',
    '(declare-const a Real)\n(declare-const b Real)\n',
    '(=> (and (> a 0) (> b 0) (not (= a b))) (and (= (<= a 0) (<= b 0)) (not (= a b))))')

# The first twenty fragments were retained from the intermediate revision;
# the current manuscript gathers their targets into twelve supporting lemmas.

# Edition 3.0: reviewable fragments for L13--L18 and the coupled hinge gate.
latch_decl='(declare-const b Bool)\n(declare-const x Real)\n(declare-const d Real)\n(define-fun lat ((v Real) (old Bool)) Bool (ite (<= v (- d)) true (ite (>= v d) false old)))\n'
add('K35','Strict hysteresis band preserves the incoming bit','L14',latch_decl,
    '(=> (and (> d 0) (> x (- d)) (< x d)) (= (lat x b) b))')
add('K36','Separated thresholds set and reset the latch','L14',latch_decl,
    '(=> (> d 0) (and (lat (- d) b) (not (lat d b))))')
add('K37','No latch event occurs at zero within a positive band','L14',latch_decl,
    '(=> (> d 0) (= (xor (lat 0 b) b) false))')
add('K38','XOR transition bits telescope over three steps','L14',
    '(declare-const a Bool)\n(declare-const b Bool)\n(declare-const c Bool)\n(declare-const d Bool)\n',
    '(= (xor (xor (xor a b) (xor b c)) (xor c d)) (xor a d))')
add('K39','A causal latch multiplier keeps permeability within bounds','U3(g)',
    '(declare-const g Real)\n(declare-const l Real)\n(declare-const b Bool)\n(define-fun h () Real (* g (+ l (* (- 1 l) (ite b 1 0)))))\n',
    '(=> (and (<= 0 g) (<= g 1) (<= 0 l) (<= l 1)) (and (<= 0 h) (<= h 1)))')
add('K40','Inside-threshold classification survives a strict error margin','L18',
    R+'(declare-const d Real)\n(declare-const e Real)\n'+absolute,
    '(=> (and (> d 0) (>= e 0) (< a (- (- d) e)) (<= (ab (- a b)) e)) (< b (- d)))')
add('K41','Outside-threshold classification survives a strict error margin','L18',
    R+'(declare-const d Real)\n(declare-const e Real)\n'+absolute,
    '(=> (and (> d 0) (>= e 0) (> a (+ d e)) (<= (ab (- a b)) e)) (> b d))')
add('K42','Middle-band classification survives a strict error margin','L18',
    R+'(declare-const d Real)\n(declare-const e Real)\n'+absolute,
    '(=> (and (> d 0) (>= e 0) (> a (+ (- d) e)) (< a (- d e)) (<= (ab (- a b)) e)) (and (> b (- d)) (< b d)))')
add('K43','Mirror-closed deletion preserves a symmetric membership predicate','L17',
    '(declare-const o Bool)\n(declare-const a Bool)\n(declare-const ja Bool)\n',
    '(= (and o (not (or a ja))) (and o (not (or ja a))))')
add('K44','Three pairwise distinct states cannot be encoded injectively in one bit','L16',
    '(declare-const a Bool)\n(declare-const b Bool)\n(declare-const c Bool)\n',
    '(not (and (distinct a b) (distinct a c) (distinct b c)))')
add('K45','Factored transition implies representative independence','L15',
    '(declare-const x Int)\n(declare-const y Int)\n(declare-fun pi (Int) Bool)\n(declare-fun f (Int) Int)\n(declare-fun fb (Bool) Bool)\n',
    '(=> (and (= (pi x) (pi y)) (= (pi (f x)) (fb (pi x))) (= (pi (f y)) (fb (pi y)))) (= (pi (f x)) (pi (f y))))')
add('K46','Endpoint difference bounds a minimum inter-switch time','L18',
    '(declare-const d Real)\n(declare-const L Real)\n(declare-const dt Real)\n',
    '(=> (and (> d 0) (> L 0) (>= dt 0) (<= (* 2 d) (* L dt))) (>= dt (/ (* 2 d) L)))')

REMAP={'T1':'L1','T3':'L1','T5':'L2','T6':'L2','T7':'L2','T8':'L3',
       'T12':'L9','T13':'L10','T11':'L4','T15':'L9','T16':'L8','T17':'L11'}
for obligation in OBLIGATIONS:
    obligation['theorem']=REMAP.get(obligation['theorem'],obligation['theorem'])

def main():
    target=BASE/'obligations';target.mkdir(exist_ok=True)
    for o in OBLIGATIONS:
        text=f'; {o["id"]}: {o["title"]}\n; Manuscript: {o["theorem"]}. Prove by unsatisfiability of its negation.\n'
        text+='(set-option :produce-proofs true)\n(set-option :timeout 10000)\n(set-logic ALL)\n'
        text+=o['declarations']+f'(assert (not {o["formula"]}))\n(check-sat)\n(get-proof)\n'
        (target/(o['id']+'.smt2')).write_text(text)
    (BASE/'obligation_index.json').write_text(json.dumps([{k:v for k,v in o.items() if k not in ['declarations','formula']} for o in OBLIGATIONS],indent=2)+'\n')
if __name__=='__main__':main()
