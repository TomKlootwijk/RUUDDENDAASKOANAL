# Explicit migration from Edition 2.0 to Gambit 3.0

The final question on pp. 47–48 of the Gambit corpus asks whether sigma is a set. Edition 3.0 makes the convention explicit instead of treating the glyph as fixing its type.

| Object | Earlier usage | Edition 3.0 |
|---|---|---|
| Alphabet | `A` or `V` in different records | `Σ = {X,Y,+,-,[,]}`, a finite set |
| All finite words | Alphabet-star construction | `Σ*`, a free monoid under concatenation |
| Complete seed family | Often implicit | `𝔖_N`, the set of specifications admissible for N accepted steps |
| Individual complete seed | Capital `Σ`, including a seven-field tuple in earlier source language | Lowercase `σ ∈ 𝔖_N`, a complete structured record; grouping changes do not erase components |
| Operator family | “All words as SDF operators” | Defined partial state transformations `{τ_w}` and their geometric compilation; not all possible SDFs |
| Boundary value | Sometimes identified with every binary mechanism | Raw scalar sample `s`; occupancy, hysteretic latch, event, pulse and parity have distinct variables |
| Engine result | U1 composition with twelve lemmas | U3 composition plus binary hinges and exact reduction criterion, with eighteen lemmas |

A tuple can be represented in set theory; a named record can be encoded as a set of uniquely tagged field/value pairs. What fails is replacing a structured record or ordered word with the untagged set of its values. Such replacement can discard order and multiplicity. This is especially relevant to `XX` and `XY`.

The current JSON schema requires all nested numerical model and hinge fields explicitly. The versioned code remains part of the complete specification. A one-bit selector can name two fixed complete seeds, but the shared decoder and laws are not information magically stored in the selector.

The baseline configurations retain the Edition 2.0 composition laws with the current version tag and without the new hinge feedback. The public `python -m kernel` command uses the complete Gambit seed, moving-probe extension and causal hinge gate. These are declared additions, not a claim that Edition 2.0 already implemented them.
