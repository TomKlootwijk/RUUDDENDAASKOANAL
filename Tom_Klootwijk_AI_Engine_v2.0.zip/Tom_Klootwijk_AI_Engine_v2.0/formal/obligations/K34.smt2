; K34: A finite output bit cannot identify two positive magnitudes
; Manuscript: L10. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(assert (not (=> (and (> a 0) (> b 0) (not (= a b))) (and (= (<= a 0) (<= b 0)) (not (= a b))))))
(check-sat)
(get-proof)
