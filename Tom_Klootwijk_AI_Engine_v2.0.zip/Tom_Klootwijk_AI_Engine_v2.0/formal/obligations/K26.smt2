; K26: Two-column stochastic remap preserves mass
; Manuscript: L7. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(declare-const u Real)
(declare-const v Real)
(assert (not (= (+ (+ (* a u) (* b v)) (+ (* (- 1 a) u) (* (- 1 b) v))) (+ u v))))
(check-sat)
(get-proof)
