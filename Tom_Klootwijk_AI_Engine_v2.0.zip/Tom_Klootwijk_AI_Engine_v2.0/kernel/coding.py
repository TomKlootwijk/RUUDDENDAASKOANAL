"""Separate occupancy, payload coding and parity. Exact dyadic accumulator."""
from dataclasses import dataclass
import math

@dataclass
class DyadicAccumulator:
    """Integer realization for a_n=k_n/2^bits, with exact prefix discrepancy <1."""
    bits: int = 16
    residual: int = 0
    total_input: int = 0
    total_output: int = 0
    count: int = 0

    def __post_init__(self):
        if not isinstance(self.bits,int) or isinstance(self.bits,bool) or not 1<=self.bits<=32:
            raise ValueError('bits must be an integer in 1..32')
        if self.residual!=0 or self.total_input!=0 or self.total_output!=0 or self.count!=0:
            raise ValueError('Fresh accumulator must start at zero')

    @property
    def denominator(self): return 1<<self.bits

    def push_integer(self, k):
        if not isinstance(k,int) or isinstance(k,bool) or not 0<=k<=self.denominator:
            raise ValueError('Expected integer input in 0..2^bits')
        total=self.residual+k; q=int(total>=self.denominator)
        self.residual=total-q*self.denominator
        self.total_input+=k;self.total_output+=q;self.count+=1
        return q

    def push(self, value):
        value=float(value)
        if not math.isfinite(value) or not 0<=value<=1: raise ValueError('Coverage must be in [0,1]')
        # Explicit nearest-half-up, with a dyadic fixed-point target. Return k to
        # distinguish exact codec error from the prior real-to-dyadic rounding.
        k=min(self.denominator,math.floor(value*self.denominator+.5))
        return self.push_integer(k),k

    @property
    def discrepancy(self):
        return self.total_output-self.total_input/self.denominator

    def certificate(self):
        return self.total_output*self.denominator-self.total_input==-self.residual and 0<=self.residual<self.denominator
