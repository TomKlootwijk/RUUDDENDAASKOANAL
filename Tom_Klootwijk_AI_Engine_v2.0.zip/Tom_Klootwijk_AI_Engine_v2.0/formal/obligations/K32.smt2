; K32: Reaction-diffusion determinant expansion
; Manuscript: L12. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(declare-const D1 Real)
(declare-const D2 Real)
(declare-const l Real)
(assert (not (= (- (* (+ a (* D1 l)) (+ b (* D2 l))) (* a b)) (+ (* (+ (* a D2) (* b D1)) l) (* D1 D2 l l)))))
(check-sat)
(get-proof)
