"""Gambit 3.0: explicit binary hinges coupled to the inherited hybrid core.

The latch is one bit per declared probe; it is not the complete state. All
transport, recurrence, codec residuals and time counters remain represented.
Author: Tom Klootwijk. Documentary labels do not enter numerical laws.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import json
import math
import numpy as np
from .core import RULES, VERSION, finite_scalar, parity
from .unified import ModelSpec, UnifiedKernel, UnifiedState

ALPHABET = frozenset(RULES)
SCHEMA = 'ksfe-gambit-seed-3.0'
AUTHOR = {'name':'Tom Klootwijk','identifier':'NL200678942','date_as_supplied':'10-07-1990'}

def bit(value: int) -> int:
    if type(value) is not int or value not in (0, 1):
        raise ValueError('A bit must be the integer 0 or 1')
    return value


def latch_update(previous: int, field_value: float, threshold: float) -> tuple[int, int]:
    """Inside <= -threshold sets 1; outside >= threshold sets 0; else hold.

    threshold is strictly positive, so the two inclusive threshold tests cannot
    conflict. Return (new_bit, transition_event). This is a sampled relay, not
    a proof that every continuous zero crossing has been observed.
    """
    previous=bit(previous)
    f=finite_scalar(field_value,'field_value');d=finite_scalar(threshold,'threshold')
    if d<=0: raise ValueError('Hysteresis threshold must be positive')
    current=1 if f<=-d else 0 if f>=d else previous
    return current, previous ^ current


def replay_latch(values, threshold: float, initial: int=0):
    b=bit(initial);states=[];events=[]
    for f in values:
        b,e=latch_update(b,f,threshold);states.append(b);events.append(e)
    return states,events


def certified_latch_trace(values, approximate, threshold: float, error_bound: float,
                          initial: int=0) -> dict:
    """Finite-sample sufficient certificate, not a necessary stability test."""
    x=np.asarray(values,dtype=float);y=np.asarray(approximate,dtype=float)
    d=finite_scalar(threshold,'threshold');eps=finite_scalar(error_bound,'error_bound')
    if x.shape!=y.shape or x.ndim!=1 or x.size==0 or not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError('Matching nonempty finite one-dimensional traces required')
    if d<=0 or eps<0: raise ValueError('Invalid threshold or error bound')
    margin=float(np.min(np.minimum(abs(x-d),abs(x+d))))
    within=bool(np.all(abs(x-y)<=eps))
    a,e=replay_latch(x,d,initial);b,f=replay_latch(y,d,initial)
    return {'certified':within and margin>eps,'margin':margin,
            'error_bound':eps,'within_error_bound':within,
            'identical_states':a==b,'identical_events':e==f}

@dataclass(frozen=True)
class HingeSpec:
    threshold: float = .012
    initial_bits: tuple[int,int,int] = (0,0,0)
    feedback: bool = True
    gate_probe: int = 0
    leakage: float = .2
    probe_amplitude: float = .18
    probe_frequency: float = 1.8

    def __post_init__(self):
        if not isinstance(self.initial_bits,(tuple,list)) or len(self.initial_bits)!=3:
            raise ValueError('Three initial latch bits required')
        object.__setattr__(self,'initial_bits',tuple(bit(x) for x in self.initial_bits))
        for n in ['threshold','leakage','probe_amplitude','probe_frequency']:
            if isinstance(getattr(self,n),bool): raise ValueError('Numeric parameter cannot be Boolean')
            finite_scalar(getattr(self,n),n)
        if self.threshold<=0 or not 0<=self.leakage<=1 or self.probe_amplitude<0 or self.probe_frequency<0:
            raise ValueError('Invalid hinge scales')
        if type(self.feedback) is not bool: raise ValueError('feedback must be Boolean')
        if type(self.gate_probe) is not int or self.gate_probe not in (0,1,2):
            raise ValueError('gate_probe must be 0, 1 or 2')

@dataclass(frozen=True)
class GambitSpec:
    model: ModelSpec = ModelSpec()
    hinge: HingeSpec = HingeSpec()

    def __post_init__(self):
        if not isinstance(self.model,ModelSpec) or not isinstance(self.hinge,HingeSpec):
            raise TypeError('A complete ModelSpec and HingeSpec are required')

    def numeric_record(self):
        return {'schema':SCHEMA,'alphabet':sorted(ALPHABET),'grammar':RULES,
                'model':asdict(self.model),'hinge':asdict(self.hinge)}

    def save(self,path: str | Path):
        data=self.numeric_record()
        data.update(engine='Tom Klootwijk Gambit',author=AUTHOR,
                    interpretation='Christian interpretation is documentary, not a physical parameter.',
                    scope='Symbolic XX/XY seeds; simulation only, not a biological or consciousness detector.')
        Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

    @classmethod
    def load(cls,path: str | Path):
        def unique(pairs):
            obj={}
            for k,v in pairs:
                if k in obj: raise ValueError(f'Duplicate JSON field: {k}')
                obj[k]=v
            return obj
        def bad_constant(x): raise ValueError(f'Nonfinite JSON constant: {x}')
        data=json.loads(Path(path).read_text(),object_pairs_hook=unique,parse_constant=bad_constant)
        expected={'schema','alphabet','grammar','model','hinge','engine','author','interpretation','scope'}
        if not isinstance(data,dict) or set(data)!=expected: raise ValueError('Unexpected or missing seed field')
        if data['schema']!=SCHEMA or data['alphabet']!=sorted(ALPHABET) or data['grammar']!=RULES:
            raise ValueError('Unsupported schema, alphabet or grammar')
        if not isinstance(data['model'],dict) or set(data['model'])!=set(ModelSpec.__dataclass_fields__):
            raise ValueError('Every model field must be explicit')
        if not isinstance(data['hinge'],dict) or set(data['hinge'])!=set(HingeSpec.__dataclass_fields__):
            raise ValueError('Every hinge field must be explicit')
        try: return cls(ModelSpec(**data['model']),HingeSpec(**data['hinge']))
        except TypeError as e: raise ValueError('Invalid model or hinge fields') from e

@dataclass
class GambitState(UnifiedState):
    latches: tuple[int,int,int]

class GambitKernel(UnifiedKernel):
    def __init__(self, specification: GambitSpec):
        if not isinstance(specification,GambitSpec): raise TypeError('GambitSpec required')
        self.gambit_spec=specification
        super().__init__(specification.model)

    def initial_state(self):
        state=super().initial_state()
        return GambitState(**vars(state),latches=self.gambit_spec.hinge.initial_bits)

    def input_points(self,step):
        # Versioned, dimensionless simulated probe law; no anatomical data.
        t=step*self.spec.dt;a=self.gambit_spec.hinge.probe_amplitude
        f=self.gambit_spec.hinge.probe_frequency
        return np.array([[-1+.08*math.sin(.7*t),1.02+a*math.sin(f*t)],
                         [1+.08*math.cos(.6*t),1.02+a*math.cos(f*t)],
                         [.10*math.sin(.9*t),.65+.5*a*math.sin(f*t+.4)]])

    def advance(self,state: GambitState):
        if not isinstance(state,GambitState): raise TypeError('GambitState required')
        if len(state.latches)!=3: raise ValueError('Three latches required')
        previous=tuple(bit(b) for b in state.latches);h=self.gambit_spec.hinge
        # One-step causal feedback: incoming latch controls THIS material step.
        multiplier=h.leakage+(1-h.leakage)*previous[h.gate_probe] if h.feedback else 1.0
        nxt,trace=super().advance(state,gate_multiplier=multiplier)
        # Sample exactly the field/probes used for the current observation, before
        # the newly computed memory is fed into the NEXT material/geometry step.
        fields=self.field(self.input_points(state.step),nxt.generation,state.memory)
        updates=[latch_update(b,float(f),h.threshold) for b,f in zip(previous,fields)]
        latches=tuple(x[0] for x in updates);events=tuple(x[1] for x in updates)
        raw=tuple(int(f<=0) for f in fields)
        payload=latches+(int(trace['growth']),trace['pulse'])
        check=parity(payload)
        trace.update(field_values=fields.tolist(),raw_occupancy=list(raw),
                     latch_before=list(previous),latches=list(latches),latch_events=list(events),
                     gate_multiplier=multiplier,hinge_threshold=h.threshold,
                     payload=list(payload),parity=check,frame_even=parity(payload+(check,))==0)
        return GambitState(**vars(nxt),latches=latches),trace

    def fingerprint(self):
        # Labels are intentionally excluded. Code bytes and realized matrices are
        # included, so a code edit changes the fingerprint even with equal JSON.
        source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in sorted(Path(__file__).parent.glob('*.py'))}
        data={'configuration':self.gambit_spec.numeric_record(),
              'realized_core':super().fingerprint(),'kernel_sources':source_hashes}
        return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
