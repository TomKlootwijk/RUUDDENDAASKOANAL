# Executed verification record

## Scope
One unified composition theorem (U1) and twelve supporting lemmas (L1–L12) have written proofs. Their full analytic content and every Python path are not encoded in a proof assistant. Algebraic UNSAT checks, numerical tests and empirical consciousness validation are different levels of evidence.

## Executed checks

- **99 unit/regression tests passed:** 55 adapted component tests and 44 new tests. See `tests.txt`.
- **34/34 SMT obligations returned UNSAT and emitted proof logs:** Z3 4.13.3.0. See `formal_check.txt`, `formal_results.json` and `formal/*.proof.txt`. No independent small-kernel replay of these proof objects is claimed.
- **Two default 120-step simulations:** exact integer dyadic codec certificates and even-parity frames hold at every step; every recorded mass is nonnegative; recurrent state and memory stay in the declared cube.

The XX growth schedule is 31, 61, 91 (final generation 4; 317 active nodes). The XY growth schedule is 31, 61 (final generation 3; 293 active nodes). Both start with mass 0.40045979813582144. Maximum absolute mass drift is 1.8318679906315083e-15. The maximum substep exit-rate product is approximately 0.697.

Auxiliary root checks give maximum polynomial residual 3.726522704558471e-17. The finite LUT query set has maximum observed error 0.06407298417868589 and no violations of its conservative error certificate. The separate geometry-only recurrence has contraction bound 0.94464; this does not apply globally to the growth/chemistry loop.

## Trust boundary

No human, animal, cell, genetic, neural or spiritual measurement was analyzed. No hardware latency or perceptual safety was measured. No claim that this engine is conscious follows. Parameters are simulation choices. Full raw histories, seed fingerprints and the tested environment are in `metrics.json`, `XX/` and `XY/`.
