# Ilse AI Engine
## A seed-based theory of consciousness: theorem family and formalized kernel

**Den Daas perspective edition — version 1.0.0 — 11 September 2026**

Requested perspective designation: **Ruud den Daas · Koen den Daas · Job den Daas**.
This is an AI-assisted research formalization prepared for the request. The supplied
materials do not establish a joint publication, individual contributions, quotations,
or endorsement by the named people. See `ATTRIBUTION_AND_SCOPE.md`.

## Start here

Read `Ilse_AI_Engine.pdf` for the manuscript and `manuscript/Ilse_AI_Engine.tex` for
the complete editable typesetting source. A readable Markdown edition is included
as `manuscript/Ilse_AI_Engine.md`.

The proposed architecture is:

```text
Complete seed + ordered XX/XY-style pair
  -> parallel L-system growth -> stroke geometry
  -> double-arc + baseline + growth-capsule field
  -> modality-specific observation interfaces
  -> fast recurrent state + slower memory
  -> memory-dependent geometry -> subsequent observation
```

The mathematical family contains **18 theorems with written proofs**. The archive
also contains **20 solver-checked algebraic obligations**, their Z3 proof logs,
and **55 passing Python regression tests**. These statements have different
verification scopes. Neither the full program nor a human consciousness theory is
proved by the SMT checks. All numerical data in this archive are synthetic.

## What is implemented

The Python kernel implements validated symbolic pair algebra, exact rational pair
mixing, parallel rewriting, a bracketed turtle, arc and segment distances,
set-correct composite fields, a capsule bounding-volume hierarchy, a log-polar LUT
with an error certificate, bracketed bisection, separate IPD and free-field ITD toy
interfaces, parity, threshold quantization, a normalized Walsh–Hadamard transform,
and a three-fast/three-slow recurrent state with memory-to-geometry feedback.

The explicit productions are `X -> X[+X]Y` and `Y -> Y[-Y]X`, starting from `[a][b]`.
The two supplied configurations are XX and XY. The generic pair API also accepts
YX and YY. These are **symbolic tokens**, not genetic diagnoses, person categories,
or rankings of consciousness. The growth grammar is a specified mathematical
construction, not an account of human mitosis.

The default generation-four construction gives **162 draw operations and 406 total
word tokens**. In the declared stability regime the closed-loop contraction bound
is **q = 0.94464**. Composite fields preserve set membership and a Lipschitz bound;
they are not advertised as globally exact signed distances inside every union.

## Reproduce

Run commands from this archive's root directory. Verify the delivered bytes before
regenerating files:

```bash
python verify_package.py
python -m venv .venv
# Activate the environment using the command appropriate for your operating system.
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m kernel.demo
python formal/check.py
bash manuscript/build.sh
```

The recorded environment is Python 3.13.5, NumPy 2.3.5, Matplotlib 3.10.8 and
Z3 4.13.3.0 on Linux. The kernel uses NumPy; plotting also uses Matplotlib.
Z3 is a separate optional verification dependency: install its command-line
executable or shared library. `formal/check.py` first tries the executable, then the
official C API. An explicit library path can be given in `Z3_LIBRARY`.
No solver, font, interpreter or numerical-library binary is bundled.

The PDF build requires a LaTeX distribution providing the packages listed in the
source. The optional Markdown conversion requires Pandoc; the delivered Markdown
can be edited without it. Exact numerical replay is conditional on the complete
configuration, environment and input history. Rebuilt PDF/figure metadata can
change even when the numeric experiment is unchanged.

For a minimal kernel call:

```python
from pathlib import Path
import numpy as np
from kernel.core import Seed, IlseKernel

engine = IlseKernel(Seed.load(Path("config/seed_xy.json")))
state = engine.initial_state()
points = np.array([[0.095, 0.6772], [-0.10, 0.50], [1.0, 1.04]])
state, output = engine.advance(state, points)
print(state.z, state.memory, output["occupancy"], output["parity"])
```

## Archive map

| Path | Contents |
| --- | --- |
| `Ilse_AI_Engine.pdf` | Final manuscript |
| `manuscript/` | LaTeX, Markdown, bibliography, claim audit, theorem registry and figures |
| `config/` | Explicit XX and XY seed specifications |
| `kernel/` | Runnable numerical research kernel and demonstration driver |
| `tests/` | 55 regression tests |
| `formal/` | 20 SMT-LIB obligations, generator, index and Z3 adapter |
| `results/` | Test records, solver logs, synthetic CSV/NPZ data and verification summary |
| `docs/` | Kernel contract and proposed research plan |
| `sources/` | Supplied double-arc addendum and provenance manifest |
| `SHA256SUMS.txt` | SHA-256 checksums of the delivered package files |

## Scope and limits

This is a research prototype, not a trained AI system, medical device, participant
stimulation protocol, consciousness detector or production renderer. No neural,
cellular, genetic or spiritual mechanism has been validated. The supplied
addendum's cosmological and clinical assertions are preserved as source material,
not accepted as established findings. The 30-entry claim audit explains each
retained definition, added condition and unsupported assertion.

Bodily interfaces, digital computation and first-person spiritual interpretation
are kept distinct. A successful simulation or theorem about geometry is not proof
of experience or an immaterial entity. The five proposed studies in
`docs/RESEARCH_PLAN.md` have not been performed. No human or animal data are included.
