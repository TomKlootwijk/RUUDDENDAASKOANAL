"""Finite-volume graph transport and conservative domain changes.

Mass vectors, not an assertion about living cells. Equal-area grid concentrations
are converted to mass before transport. No normal is evaluated at SDF cusps.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from scipy import sparse
from .core import finite_array, finite_scalar

@dataclass(frozen=True)
class Grid:
    points: np.ndarray
    shape: tuple[int, int]
    h: float

    @classmethod
    def regular(cls, xmin=-2.4, xmax=2.4, ymin=-.16, ymax=2.24, h=.08,
                max_nodes=20000):
        vals=[finite_scalar(v,n) for v,n in zip([xmin,xmax,ymin,ymax,h],['xmin','xmax','ymin','ymax','h'])]
        xmin,xmax,ymin,ymax,h=vals
        if h<=0 or xmin>=xmax or ymin>=ymax: raise ValueError('Invalid regular grid')
        nx0=(xmax-xmin)/h; ny0=(ymax-ymin)/h
        if abs(nx0-round(nx0))>1e-8 or abs(ny0-round(ny0))>1e-8:
            raise ValueError('Grid spans must be integer multiples of h')
        nx,ny=int(round(nx0))+1,int(round(ny0))+1
        if nx*ny>max_nodes: raise ValueError('Grid exceeds max_nodes')
        x=xmin+h*np.arange(nx); y=ymin+h*np.arange(ny)
        xx,yy=np.meshgrid(x,y)
        return cls(np.stack([xx.ravel(),yy.ravel()],axis=1),(ny,nx),h)

    @property
    def volume(self): return self.h*self.h


def validated_mask(mask, size=None):
    raw=np.asarray(mask)
    if raw.ndim!=1 or (size is not None and raw.size!=size): raise ValueError('Mask shape mismatch')
    if not np.all(np.isin(raw,[0,1])): raise ValueError('Mask must be Boolean')
    out=raw.astype(bool)
    if not np.any(out): raise ValueError('Active domain must not be empty')
    return out

@dataclass
class Graph:
    """Column-generator convention: Q[i,j] is the rate from node j to node i."""
    grid: Grid
    mask: np.ndarray
    source: np.ndarray
    target: np.ndarray
    gate: np.ndarray
    omega: float

    @classmethod
    def build(cls, grid: Grid, mask, gate=1.0, omega=0.0, gate_x=0.0):
        mask=validated_mask(mask,len(grid.points))
        g=finite_scalar(gate,'gate'); omega=finite_scalar(omega,'omega')
        gate_x=finite_scalar(gate_x,'gate_x')
        if not 0<=g<=1: raise ValueError('gate must be in [0,1]')
        ids=np.arange(len(mask)).reshape(grid.shape)
        a=np.r_[ids[:,:-1].ravel(),ids[:-1,:].ravel()]
        b=np.r_[ids[:,1:].ravel(),ids[1:,:].ravel()]
        good=mask[a]&mask[b]; a,b=a[good],b[good]
        # An interface is assigned to an edge, not confused with vector-field chirality.
        xa=grid.points[a,0]; xb=grid.points[b,0]
        cross=(xa<gate_x)&(xb>=gate_x) | (xb<gate_x)&(xa>=gate_x)
        gates=np.where(cross,g,1.0)
        return cls(grid,mask,a,b,gates,omega)

    def generator(self, diffusion):
        D=finite_scalar(diffusion,'diffusion')
        if D<0: raise ValueError('diffusion must be nonnegative')
        a,b=self.source,self.target
        delta=self.grid.points[b]-self.grid.points[a]
        mid=(self.grid.points[b]+self.grid.points[a])/2
        velocity=self.omega*np.stack([-mid[:,1],mid[:,0]],axis=1)
        signed=np.sum(velocity*delta,axis=1)/(self.grid.h**2)
        # Shared gate preserves closed-system mass, even for directed transport.
        ab=self.gate*(D/(self.grid.h**2)+np.maximum(signed,0))
        ba=self.gate*(D/(self.grid.h**2)+np.maximum(-signed,0))
        n=len(self.mask)
        rows=np.r_[b,a,a,b]; cols=np.r_[a,b,a,b]
        data=np.r_[ab,ba,-ab,-ba]
        return sparse.coo_matrix((data,(rows,cols)),shape=(n,n)).tocsr()

    def boundary_nodes(self):
        degree=np.bincount(np.r_[self.source,self.target],minlength=len(self.mask))
        return self.mask&(degree<4)


def transport_step(mass, Q, dt, max_substeps=10000):
    """Explicit positive substepping. No negative-value clipping hides errors.

    The exact-arithmetic theorem uses dt_sub * maximum_exit_rate <= 1.
    The implementation targets <= .9 to leave numerical margin.
    """
    m=finite_array(mass)
    if m.ndim!=1 or Q.shape!=(len(m),len(m)): raise ValueError('Mass/generator shape mismatch')
    if np.min(m)<0: raise ValueError('Mass must be nonnegative')
    dt=finite_scalar(dt,'dt')
    if dt<=0: raise ValueError('dt must be positive')
    if not np.all(np.isfinite(Q.data)): raise ValueError('Nonfinite generator')
    diagonal=Q.diagonal(); off=Q-sparse.diags(diagonal)
    if len(off.data) and np.min(off.data)<0: raise ValueError('Negative off-diagonal generator entry')
    if np.max(diagonal)>1e-12 or np.max(np.abs(np.asarray(Q.sum(axis=0))))>1e-9:
        raise ValueError('Generator must have zero column sums and nonpositive diagonal')
    exit_rate=float(np.max(-diagonal))
    count=max(1,math.ceil(dt*exit_rate/.9))
    if count>max_substeps: raise ValueError('Transport substep budget exceeded')
    step=dt/count
    # The matrix expression exposes nonnegative entries, instead of subtractive Euler cancellation.
    P=sparse.eye(Q.shape[0],format='csr')+step*Q
    if len(P.data) and np.min(P.data)<0: raise FloatingPointError('Transition has a negative entry')
    out=m.copy()
    for _ in range(count): out=P@out
    if not np.all(np.isfinite(out)): raise FloatingPointError('Transport overflow')
    return out, {'substeps':count,'max_cfl':step*exit_rate}


def reaction_step(u,v,a,b,dt,max_substeps=10000):
    """Local reversible conversion U -> V at rate a and V -> U at rate b."""
    u=finite_array(u);v=finite_array(v)
    a=finite_scalar(a,'a');b=finite_scalar(b,'b');dt=finite_scalar(dt,'dt')
    if u.shape!=v.shape or u.ndim!=1 or np.min(u)<0 or np.min(v)<0:
        raise ValueError('Nonnegative matching mass vectors required')
    if min(a,b)<0 or dt<=0: raise ValueError('Nonnegative rates and positive dt required')
    n=max(1,math.ceil(dt*max(a,b)/.9))
    if n>max_substeps: raise ValueError('Reaction substep budget exceeded')
    h=dt/n;u=u.copy();v=v.copy()
    for _ in range(n): u,v=(1-h*a)*u+h*b*v,h*a*u+(1-h*b)*v
    return u,v


def conservative_remap(mass, old_mask, new_mask, points):
    """Push removed-node mass to the nearest retained/new node; ties use index.

    This is a column-stochastic finite model, not a continuum ALE convergence
    claim. Newly activated nodes start empty unless they receive mapped mass.
    """
    m=finite_array(mass);p=finite_array(points,last_dim=2)
    old=validated_mask(old_mask,len(m));new=validated_mask(new_mask,len(m))
    if m.ndim!=1 or p.shape!=(len(m),2) or np.min(m)<0: raise ValueError('Invalid remap arrays')
    if np.any(m[~old]!=0): raise ValueError('Inactive old nodes must have zero mass')
    out=np.zeros_like(m);kept=old&new;out[kept]=m[kept]
    targets=np.flatnonzero(new)
    for src in np.flatnonzero(old&~new):
        dst=targets[int(np.argmin(np.sum((p[targets]-p[src])**2,axis=1)))]
        out[dst]+=m[src]
    return out
