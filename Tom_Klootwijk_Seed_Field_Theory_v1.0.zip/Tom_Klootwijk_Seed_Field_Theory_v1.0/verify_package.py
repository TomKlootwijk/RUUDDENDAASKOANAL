"""Verify delivered package byte integrity; no network or external dependencies."""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
if not manifest.is_file():
    sys.exit("SHA256SUMS.txt is missing")
failed = []
count = 0
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    digest, relative = line.split("  ", 1)
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        failed.append(relative + " (missing or invalid path)")
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    count += 1
    if actual != digest:
        failed.append(relative + " (changed)")
if failed:
    print("Checksum differences:\n" + "\n".join(failed))
    sys.exit(1)
print(f"Verified {count} file checksums. This is a local integrity check only.")
