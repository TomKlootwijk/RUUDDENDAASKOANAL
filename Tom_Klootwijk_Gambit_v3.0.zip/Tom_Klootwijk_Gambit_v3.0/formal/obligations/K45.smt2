; K45: Factored transition implies representative independence
; Manuscript: L15. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const x Int)
(declare-const y Int)
(declare-fun pi (Int) Bool)
(declare-fun f (Int) Int)
(declare-fun fb (Bool) Bool)
(assert (not (=> (and (= (pi x) (pi y)) (= (pi (f x)) (fb (pi x))) (= (pi (f y)) (fb (pi y)))) (= (pi (f x)) (pi (f y))))))
(check-sat)
(get-proof)
