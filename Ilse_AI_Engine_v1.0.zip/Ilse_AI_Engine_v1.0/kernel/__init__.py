"""Ilse AI Engine: a research kernel, not a consciousness detector."""
from .core import *
