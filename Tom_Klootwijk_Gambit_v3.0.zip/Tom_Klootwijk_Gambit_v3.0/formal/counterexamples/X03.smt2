; Equal sign bits do not identify a scalar distance
(set-logic ALL)

(declare-const f Real) (declare-const g Real)
(assert (= f 1)) (assert (= g 2))
(assert (= (<= f 0) (<= g 0))) (assert (distinct f g))

(check-sat)
(get-model)
