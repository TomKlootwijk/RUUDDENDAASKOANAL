# Edition 3.0 verification record

The delivered 35-page PDF states U3 and eighteen supporting lemmas. `docs/claim_audit.csv` contains 84 source dispositions. The typesetting build reported no overfull boxes or undefined references. All manuscript pages were visually reviewed; the final cover and central theorem were also checked in Poppler. The PDF is searchable but is not a tagged accessible PDF.

The current code passed **145 regression tests**, retaining the 99 inherited component tests and adding 46 Gambit tests. The tests are executable examples and bounded checks, not a proof of every possible program path.

Z3 **4.13.3.0** returned **UNSAT with proof output for 46 algebraic counterexample queries**. The separate three **SAT** cases are intentional constructive witnesses to overstrong reductions, not failed invariants. Individual obligations, logs and witnesses are included. The analytic theorem is written in the manuscript; the complete numerical engine is not compiled into a proof assistant.

The exact finite quotient example checks **508 histories**, from all four full states and every binary input word of length zero through six. This verifies a declared finite example, not a two-state reduction of the full engine.

Each symbolic XX/XY run completes **120 updates**. Both keep nonnegative represented masses; the largest observed total-mass drift is **1.8318679906315083e-15**. Their integer dyadic pulse-density certificates and six-bit even-parity frames pass at every recorded step. The real-arithmetic mass invariant and floating-point numerical residual are deliberately reported separately.

`metrics.json`, the full JSON/CSV histories, array outputs, configuration fingerprints and environment record support these figures. `verification_summary.json` collects the release facts and PDF digest. File hashes attest to integrity only, and must be checked before regenerating outputs. Figure/PDF bytes can change upon rebuilding because of timestamps or platform behavior.

No human, biological, clinical, physical-hardware or spiritual measurements were collected or generated. These checks do not establish that the engine is conscious or that the interpretation is a law of nature.
