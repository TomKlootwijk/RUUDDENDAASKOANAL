"""Run the Gambit simulations and export their data."""
from .demo import main
if __name__ == "__main__": main()
