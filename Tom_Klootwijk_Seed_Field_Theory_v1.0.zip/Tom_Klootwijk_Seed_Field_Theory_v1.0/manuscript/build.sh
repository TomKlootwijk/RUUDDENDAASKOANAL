#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python3}"
command -v pdflatex >/dev/null || { echo "pdflatex is required." >&2; exit 1; }
cd "$HERE/../code"
"$PYTHON" -m unittest -v test_seed_field.py
"$PYTHON" demo.py --config seed.json --out ../outputs
cp ../outputs/growth.pdf ../outputs/encoding_error.pdf ../outputs/memory_energy.pdf "$HERE/figures/"
cd "$HERE"
pdflatex -interaction=nonstopmode -halt-on-error Tom_Klootwijk_Seed_Field_Theory.tex
pdflatex -interaction=nonstopmode -halt-on-error Tom_Klootwijk_Seed_Field_Theory.tex
cp Tom_Klootwijk_Seed_Field_Theory.pdf ../Tom_Klootwijk_Seed_Field_Theory.pdf
if command -v pandoc >/dev/null; then
  pandoc --from=latex --to=markdown --wrap=none Tom_Klootwijk_Seed_Field_Theory.tex -o Tom_Klootwijk_Seed_Field_Theory.md
fi
printf '\nBuilt ../Tom_Klootwijk_Seed_Field_Theory.pdf\n'
printf 'Checksums describe the delivered package; rebuilding can change them.\n'
