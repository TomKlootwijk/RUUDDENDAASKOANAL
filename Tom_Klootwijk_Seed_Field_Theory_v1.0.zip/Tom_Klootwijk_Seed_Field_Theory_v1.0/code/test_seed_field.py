import unittest
import numpy as np
from seed_field import *

class TestSeedField(unittest.TestCase):
    def test_parallel_rewrite(self):
        self.assertEqual(expand_lsystem('A', {'A':'AB','B':'A'}, 4), 'ABAABABA')
    def test_growth_segment_count(self):
        word, segments = grow(GrowthConfig())
        self.assertEqual(len(segments), 5**3)
        self.assertEqual(word.count('F'), len(segments))
    def test_same_seed_reproduces_geometry(self):
        self.assertTrue(np.array_equal(grow(GrowthConfig())[1], grow(GrowthConfig())[1]))
    def test_different_seed_changes_perturbed_geometry(self):
        self.assertFalse(np.array_equal(grow(GrowthConfig(seed=42))[1], grow(GrowthConfig(seed=43))[1]))
    def test_sphere_metric(self):
        np.testing.assert_allclose(sphere_sdf(np.array([[0,0],[1,0],[2,0]]),np.zeros(2),1),[-1,0,1])
    def test_capsule_and_degenerate_capsule(self):
        self.assertAlmostEqual(float(capsule_sdf(np.array([.5,2]),np.array([0,0]),np.array([1,0]),1)),1)
        self.assertAlmostEqual(float(capsule_sdf(np.array([2,0]),np.zeros(2),np.zeros(2),1)),1)
    def test_boundary_normalizes_to_half(self):
        np.testing.assert_allclose(normalize_distance(np.array([-2,0,2]),1), [0,.5,1])
    def test_byte_quantization_bound(self):
        u = np.linspace(0,1,10001)
        self.assertLessEqual(float(np.max(np.abs(quantize8(u)/255-u))),1/510+1e-14)
    def test_pdm_prefix_bound(self):
        u=np.random.default_rng(1).random(10000)
        q,a=pulse_density(u)
        self.assertLess(float(np.max(np.abs(np.cumsum(q-u)))),1+1e-10)
        np.testing.assert_allclose(np.cumsum(q-u),-a,atol=1e-10)
    def test_pdm_endpoints(self):
        np.testing.assert_array_equal(pulse_density(np.array([0,0,1,1]))[0],[0,0,1,1])
    def test_parity_detects_one_not_two_flips(self):
        b=np.array([1,0,1,1,0,0,0,1]); p=even_parity(b)
        one=b.copy(); one[0]^=1
        two=one.copy(); two[1]^=1
        self.assertNotEqual(p,even_parity(one)); self.assertEqual(p,even_parity(two))
    def test_hadamard_is_orthogonal(self):
        h=walsh_hadamard(32)
        np.testing.assert_allclose(h.T@h,np.eye(32),atol=1e-12)
    def test_memory_retrieval_energy(self):
        patterns=np.sign(walsh_hadamard(64)[1:5])
        cue=patterns[0].copy(); cue[[0,3,9,13,19,25,35,45]]*=-1
        final, energy=recall(learn_memory(patterns),cue)
        np.testing.assert_array_equal(final,patterns[0])
        self.assertTrue(np.all(np.diff(energy)<=1e-10))
    def test_bracketed_crossing(self):
        t=bisect_root(lambda t: abs(-2+t)-1,0,1.5)
        self.assertAlmostEqual(t,1,places=9)
    def test_itd_midline_and_side(self):
        left,right=np.array([-.09,0,0]),np.array([.09,0,0])
        self.assertEqual(interaural_time_difference(np.array([0,0,2]),left,right,343),0)
        self.assertGreater(interaural_time_difference(np.array([1,0,2]),left,right,343),0)
    def test_finite_sign_samples_lose_geometry(self):
        points=np.array([[2.,0],[3.,0]])
        a=sphere_sdf(points,np.zeros(2),.5); b=sphere_sdf(points,np.zeros(2),1.)
        np.testing.assert_array_equal(a<0,b<0)
        self.assertFalse(np.array_equal(a,b))
    def test_invalid_parameters_rejected(self):
        with self.assertRaises(ValueError): grow(GrowthConfig(step=-1))
        with self.assertRaises(ValueError): walsh_hadamard(3)
        with self.assertRaises(ValueError): pulse_density(np.array([1.2]))
        with self.assertRaises(ValueError): bisect_root(lambda t:t*t+1,-1,1)
        with self.assertRaises(ValueError): grow(GrowthConfig(rule='F['))
        with self.assertRaises(ValueError): expand_lsystem('F',{'F':'FFFF'},10,100)

if __name__ == '__main__': unittest.main(verbosity=2)
