; K30: Strict field margin preserves occupancy
; Manuscript: L12. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const f Real)
(declare-const g Real)
(declare-const e Real)
(define-fun ab ((x Real)) Real (ite (>= x 0) x (- x)))
(assert (not (=> (and (>= e 0) (> (ab f) e) (<= (ab (- f g)) e)) (= (<= f 0) (<= g 0)))))
(check-sat)
(get-proof)
