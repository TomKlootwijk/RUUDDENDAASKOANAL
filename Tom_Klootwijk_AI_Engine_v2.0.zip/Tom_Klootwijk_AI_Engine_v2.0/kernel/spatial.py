"""A median-split capsule BVH. Correctness does not depend on speed claims."""
from dataclasses import dataclass
import heapq
import itertools
import numpy as np
from .core import finite_array, distance_segment

@dataclass
class Node:
    lower: np.ndarray
    upper: np.ndarray
    indices: np.ndarray | None = None
    left: "Node | None" = None
    right: "Node | None" = None

class CapsuleBVH:
    def __init__(self,segments,thickness=.03,leaf_size=8):
        self.segments=finite_array(segments)
        if self.segments.ndim!=3 or self.segments.shape[1:]!=(2,2) or len(self.segments)==0:
            raise ValueError("Expected nonempty (N,2,2) segments")
        if not np.isfinite(thickness) or thickness<=0 or leaf_size<1: raise ValueError("Invalid BVH parameters")
        self.thickness=thickness
        def build(ids):
            s=self.segments[ids]; lo=s.min(axis=(0,1)); hi=s.max(axis=(0,1))
            if len(ids)<=leaf_size: return Node(lo,hi,ids)
            axis=int(np.argmax(hi-lo)); order=ids[np.argsort(s.mean(axis=1)[:,axis],kind="stable")]
            k=len(order)//2
            return Node(lo,hi,left=build(order[:k]),right=build(order[k:]))
        self.root=build(np.arange(len(self.segments)))

    def query(self,point):
        p=finite_array(point,last_dim=2)
        if p.shape!=(2,): raise ValueError("Single point expected")
        def bound(n): return float(np.linalg.norm(np.maximum(np.maximum(n.lower-p,p-n.upper),0)))-self.thickness
        counter=itertools.count(); heap=[(bound(self.root),next(counter),self.root)]
        best=float("inf"); evaluations=0
        while heap:
            lower,_,node=heapq.heappop(heap)
            if lower>=best: continue
            if node.indices is not None:
                for i in node.indices:
                    a,b=self.segments[i]; best=min(best,float(distance_segment(p,a,b))-self.thickness);evaluations+=1
            else:
                for child in [node.left,node.right]:
                    heapq.heappush(heap,(bound(child),next(counter),child))
        return best,evaluations
