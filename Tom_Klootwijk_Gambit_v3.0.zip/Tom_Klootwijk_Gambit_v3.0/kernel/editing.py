"""Admissible symbolic/local geometry edits; no gene-editing simulation."""
from __future__ import annotations
import numpy as np
from .core import RULES,turtle,finite_array


def edit_word(word: str,start: int,stop: int,replacement: str) -> str:
    if not isinstance(word,str) or not isinstance(replacement,str): raise ValueError('Strings required')
    if type(start) is not int or type(stop) is not int or not 0<=start<=stop<=len(word):
        raise ValueError('Invalid half-open edit interval')
    # Both the existing and edited words must be legal complete turtle programs.
    turtle(word)
    edited=word[:start]+replacement+word[stop:]
    if any(s not in RULES for s in edited): raise ValueError('Unknown edit token')
    if len(turtle(edited))==0: raise ValueError('Edited standalone field needs a drawing primitive')
    return edited


def translate_segments(segments,displacement):
    s=finite_array(segments);d=finite_array(displacement)
    if s.ndim!=3 or s.shape[1:]!=(2,2) or not len(s) or d.shape!=(2,):
        raise ValueError('Nonempty segment list and two-vector displacement required')
    return s+d


def reflection_closure(points):
    p=finite_array(points,last_dim=2)
    if p.ndim!=2: raise ValueError('A point list is required')
    reflected=p*np.array([-1.,1.])
    return np.unique(np.concatenate([p,reflected]),axis=0)
