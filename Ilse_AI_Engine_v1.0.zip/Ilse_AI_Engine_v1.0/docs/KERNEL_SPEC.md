# Kernel contract

This file summarizes the executable contract. The manuscript is the mathematical
source of record. The implementation lives in `kernel/core.py` and `kernel/spatial.py`.

## 1. Seed, growth and resource constraints

`Seed.load(path)` loads the `seed` object from the named JSON configuration.
The implementation's `RULES`, turtle defaults and matrix construction complete
the configuration. The additional JSON `grammar` and `conventions` fields document
those defaults; they are not an independent runtime rule override.

The seed records the ordered pair, generation count, PCG64 integer seed, geometry,
update rates and version. `IlseKernel.configuration_digest()` also hashes the
realized matrices and built-in rules. Exact replay additionally requires identical
input sample sequences and numerical conventions.

The ordered pair uses X/Y tokens. `mix_pairs` is a separate stipulated law selecting
one of two positions uniformly from each pair; it returns exact `Fraction` values.
It does not sample actual chromosomes or biological traits.

The grammar replaces all old tokens in parallel. X and Y each draw forward;
`+`/`-` turn; brackets save/restore the turtle state. Default length is 0.12,
turn angle is pi/7, branch-depth factor is 0.72 and heading is upward.
`grow` uses a default 200,000-symbol ceiling; `Seed` restricts generations to 0..9.
The derived number of active draws is 2*3**n and full word length is 5*3**n+1.
Overlapping draw operations are not counted as distinct set boundaries.

## 2. Geometric field

`distance_arc` returns unsigned centerline distance on 0 < aperture <= pi/2.
`paired_arcs` evaluates the two translated arcs explicitly unless comparison mode
`folded=True` is requested. That comparison shortcut is guaranteed by the stated
sufficient condition spacing >= radius*sin(aperture), not for arbitrary geometry.

`m_field` adds a baseline capsule and clips against y >= 0. `capsule_field`
returns the minimum segment distance minus a positive radius. The construction
preserves closed-set membership and is 1-Lipschitz for fixed memory. Interior
values after CSG composition need not equal exact signed distance to the union.

The growth geometry is fixed at the configured generation for a run. The kernel
embeds its stroke coordinates as `0.55*segments + [0, 0.10]`, thickens them by
0.018, and unions them with the M field. Growth therefore enters the actual
observation law, not just a decorative figure. The recurrent loop changes the M
stroke radius through memory; it does not rewrite its grammar on each time step.

## 3. Observation and fast/slow transition

The state is `State(z, memory, step)`, with two real three-vectors. Each call to
`advance` takes exactly three finite 2D query points in simulation units.

The M stroke radius is `r(m) = thickness + memory_geometry_gain*tanh(m[0])`.
The seed constructor enforces `thickness > abs(memory_geometry_gain)` so the
radius remains positive. The three observations are `u = -tanh(phi(points; m))`.

The transition is:

```text
z_next = (1-alpha)*z + alpha*tanh(A@z + B@m + C@u)
m_next = (1-eta)*m + eta*tanh(D@z + E@u)
```

Tanh acts componentwise. The seeded random matrices are normalized to infinity
row norms 0.35, 0.15, 0.40, 0.30 and 0.20 respectively. They are demonstration
parameters, not fitted neural weights. Occupancy and parity describe the current
observation supplied to this update, not a report about the next state.

The default alpha is 0.4, eta is 0.08 and memory-geometry gain is 0.04. In the
real-arithmetic model, the cube [-1,1]^6 is invariant, and the joint transition has
contraction bound 0.94464 for a shared external query sequence. Unique fixed-point
language applies only when the external input is fixed. A changing external
sequence instead has a same-input forgetting bound between initial conditions.
Floating-point tests are regression evidence, not a machine proof of every step.

This strong contraction also limits persistent memory. It is not a model of
unbounded autobiographical storage or a theorem that memory must be permanent.

## 4. Separate auxiliary interfaces

`stereo_eyes` offsets eye origins by a declared physical separation and pose.
`itd_seconds` uses the difference of two source-to-receiver path lengths divided
by a specified speed, with right-minus-left arrival-time convention. They are
separate toy geometry interfaces and are not full ocular or auditory models.
IPD cannot supply an auditory transfer function without an additional model.

`LogPolarLUT` stores Cartesian field values on a finite annulus. Bilinear lookup
returns both an estimate and a conservative Euclidean corner-distance error
certificate for a 1-Lipschitz source field. It is not a distance computation in
an unweighted logarithmic metric. `CapsuleBVH` is a median-split spatial hierarchy
with geometric lower bounds, not a claim that every binary search tree accelerates
ray tracing. Neither auxiliary accelerator is required by the three-state update.

`bisect_root` requires a valid sign bracket and returns its retained interval.
It does not guarantee the earliest crossing or detect all tangent roots.
`parity` is a modulo-two reduction, not a geometry dimension or encryption key.
`bernoulli_encode` uses uniform threshold coding of values in [0,1]; it does not
promise blue-noise spectra. `fwht` is a normalized real transform on a positive
power-of-two vector length, not a quantum simulation of a biological system.

## 5. Unsupported extensions and output restrictions

There is no implementation of the optional Klein quotient, undefined IDT,
reaction–diffusion biology, learned report readout, body action controller or
optical hardware. Source claims about wormholes, quantum collapse, unavoidable
migraine or vestibular “hacks” are not transition laws. The kernel outputs only
numerical arrays and static explanatory figures. It does not drive transducers,
medical equipment or any other physical actuator.
