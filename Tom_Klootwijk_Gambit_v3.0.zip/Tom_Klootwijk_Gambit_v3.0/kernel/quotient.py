"""Exact finite-state checker for U3(h)/L15.

A partition is a lossless deterministic abstraction for the declared output
iff same-block states have equal outputs and successor blocks for every input.
This does not discretize the continuous Gambit state or certify it as one bit.
"""
from __future__ import annotations
from dataclasses import dataclass
import itertools

@dataclass(frozen=True)
class FiniteMachine:
    transitions: tuple[tuple[int,...],...]
    outputs: tuple[str | int,...]

    def __post_init__(self):
        t=tuple(tuple(row) for row in self.transitions);o=tuple(self.outputs)
        if not t or not t[0] or len(o)!=len(t): raise ValueError('Nonempty total machine required')
        n=len(t);m=len(t[0])
        if any(len(row)!=m for row in t): raise ValueError('Every state must define every input')
        if any(type(s) is not int or not 0<=s<n for row in t for s in row):
            raise ValueError('Successors must be valid integer state indices')
        if any(type(x) not in (str,int) for x in o): raise ValueError('Outputs must be string or integer labels')
        object.__setattr__(self,'transitions',t);object.__setattr__(self,'outputs',o)

    def trace(self,initial: int,inputs):
        if type(initial) is not int or not 0<=initial<len(self.transitions): raise ValueError('Invalid initial state')
        s=initial;states=[s];outputs=[self.outputs[s]]
        for u in inputs:
            if type(u) is not int or not 0<=u<len(self.transitions[0]): raise ValueError('Invalid input')
            s=self.transitions[s][u];states.append(s);outputs.append(self.outputs[s])
        return states,outputs


def analyse_quotient(machine: FiniteMachine, partition) -> dict:
    p=tuple(partition);n=len(machine.transitions)
    if len(p)!=n or any(type(x) is not int or x<0 for x in p): raise ValueError('Invalid partition')
    blocks=sorted(set(p))
    if blocks!=list(range(len(blocks))): raise ValueError('Block indices must be contiguous from zero')
    representatives=[p.index(b) for b in blocks]
    for x in range(n):
        r=representatives[p[x]]
        if machine.outputs[x]!=machine.outputs[r]:
            return {'valid':False,'blocks':len(blocks),'witness':{'kind':'output','states':[r,x],
                      'block':p[x],'outputs':[machine.outputs[r],machine.outputs[x]]}}
        for u in range(len(machine.transitions[0])):
            a=p[machine.transitions[r][u]];b=p[machine.transitions[x][u]]
            if a!=b:
                return {'valid':False,'blocks':len(blocks),'witness':{'kind':'transition','states':[r,x],
                          'input':u,'block':p[x],'next_blocks':[a,b]}}
    transitions=[[p[machine.transitions[r][u]] for u in range(len(machine.transitions[0]))]
                 for r in representatives]
    outputs=[machine.outputs[r] for r in representatives]
    return {'valid':True,'blocks':len(blocks),'representatives':representatives,
            'partition':list(p),'transitions':transitions,'outputs':outputs}


def quotient_machine(machine: FiniteMachine, partition) -> FiniteMachine:
    report=analyse_quotient(machine,partition)
    if not report['valid']: raise ValueError(f'Not an exact quotient: {report["witness"]}')
    return FiniteMachine(tuple(map(tuple,report['transitions'])),tuple(report['outputs']))


def minimum_state_bits(distinguishable_states: int) -> int:
    if type(distinguishable_states) is not int or distinguishable_states<1:
        raise ValueError('A positive integer count is required')
    return (distinguishable_states-1).bit_length()


def examples() -> dict:
    # Blocks {0,1} and {2,3}; input 0 preserves, input 1 exchanges blocks.
    good=FiniteMachine(((1,2),(0,3),(3,0),(2,1)),(0,0,1,1))
    # State 0 and state 1 currently look identical, but input 0 separates them.
    bad=FiniteMachine(((0,2),(2,3),(3,0),(2,1)),(0,0,1,1))
    p=(0,0,1,1);result=analyse_quotient(good,p);q=quotient_machine(good,p)
    count=0
    for length in range(7):
        for inputs in itertools.product((0,1),repeat=length):
            for x in range(4):
                states,outputs=good.trace(x,inputs);qs,qo=q.trace(p[x],inputs)
                if [p[s] for s in states]!=qs or outputs!=qo: raise AssertionError('Quotient trace mismatch')
                count+=1
    return {'compatible':result,'incompatible':analyse_quotient(bad,p),
            'finite_example_traces_checked':count,
            'continuous_counterexample':{'law':'F(x)=x+0.75; b(x)=1[x<=0]',
                 'states':[-2.0,-.5],'same_current_bits':[1,1],
                 'successors':[-1.25,.25],'different_next_bits':[1,0]},
            'minimum_bits':{str(n):minimum_state_bits(n) for n in [1,2,3,4,6,8,9]}}
