"""Create an editable reading edition from the authoritative LaTeX manuscript.

Requires Pandoc. The PDF/LaTeX source controls equation numbers and typography.
No mathematical content is removed; prose emphasis wrappers are simplified.
"""
from pathlib import Path
import re
import subprocess
import tempfile

HERE=Path(__file__).resolve().parent

def main():
    src=(HERE/'Tom_Klootwijk_AI_Engine.tex').read_text()
    start=src.index('\\begin{titlepage}')
    stop=src.index('\\end{titlepage}')+len('\\end{titlepage}')
    src=src[:start]+src[stop:]
    with tempfile.TemporaryDirectory() as d:
        d=Path(d);tex=d/'reading.tex';tex.write_text(src)
        lua=d/'plain.lua';lua.write_text('function Emph(el) return el.content end\n')
        result=subprocess.run(['pandoc',str(tex),'-f','latex','-t','markdown','--wrap=none','--lua-filter',str(lua)],check=True,capture_output=True,text=True)
        text=result.stdout
    text=re.sub(r'\*\*Unified Theorem (\d+)\*\*',r'**Unified Theorem U\1**',text)
    text=re.sub(r'\*\*Lemma (\d+)\*\*',r'**Lemma L\1**',text)
    text=re.sub(r'^:::[^\n]*\n','',text,flags=re.M)
    text=re.sub(r'\{width="[^"\n]*"\}','',text)
    text=text.replace('.pdf)', '.png)')  # Local figure alternatives supplied in this directory.
    text=text.replace('{.sans-serif}','')
    # Resolve displayed equation cross-references using the latest LaTeX aux file.
    aux=HERE/'_build/Tom_Klootwijk_AI_Engine.aux'
    labels={}
    if aux.exists():
        for key,val in re.findall(r'\\newlabel\{(eq:[^}]+)\}\{\{([^}]+)\}',aux.read_text()):labels[key]=val
    for key,val in labels.items():
        pat=r'\[\\\['+re.escape(key)+r'\\\]\]\(#'+re.escape(key)+r'\)\{[^}]*\}'
        text=re.sub(pat,'('+val+')',text)
    header='''# Tom Klootwijk AI Engine
## Unified Seed–Field Theorem and Theory of Consciousness

**Author: Tom Klootwijk**  
**NL200678942 · 10-07-1990**  
Version 2.0.0 · 11 September 2026

> Editable reading edition. The LaTeX/PDF version controls typography and equation numbering. This private author-attributed research manuscript includes the personal details supplied by the requester.

'''
    text=header+text
    (HERE/'Tom_Klootwijk_AI_Engine.md').write_text(text)
    sections=[('The unified seed--field composition theorem','Twelve supporting lemmas and proofs','UNIFIED_THEOREM.md'),
              ('Twelve supporting lemmas and proofs','Consciousness across bodily, digital and spiritual domains','SUPPORTING_PROOFS.md')]
    for begin,end,fn in sections:
        a=text.index('# '+begin)
        b=text.index('# '+end,a+len(begin))
        part=text[a:b]
        (HERE.parent/'docs'/fn).write_text('**Tom Klootwijk AI Engine 2.0.0**  \n**Author: Tom Klootwijk · NL200678942 · 10-07-1990**\n\n'+part+'\nSee the full manuscript for definitions, source audit and verification limits.\n')
    print('Markdown reading edition and theorem/proof extracts created')
if __name__=='__main__':main()
