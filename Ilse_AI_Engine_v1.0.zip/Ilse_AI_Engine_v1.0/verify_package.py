"""Verify the delivered files against SHA256SUMS.txt (standard library only).

Run before rebuilding generated outputs. The checksum manifest cannot authenticate
its own origin and is not a digital signature. Unlisted local files are ignored.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent

def main() -> int:
    manifest = ROOT / "SHA256SUMS.txt"
    if not manifest.is_file():
        print("Missing SHA256SUMS.txt", file=sys.stderr)
        return 2
    errors: list[str] = []
    checked = 0
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        parts = line.split("  ", 1)
        if len(parts) != 2 or len(parts[0]) != 64:
            errors.append(f"Malformed checksum line {number}")
            continue
        expected, relative = parts
        path = (ROOT / relative).resolve()
        if not path.is_relative_to(ROOT) or path == ROOT:
            errors.append(f"Invalid relative path on line {number}")
            continue
        if not path.is_file():
            errors.append(f"Missing: {relative}")
            continue
        with path.open("rb") as handle:
            actual = hashlib.file_digest(handle, "sha256").hexdigest()
        checked += 1
        if actual != expected:
            errors.append(f"Checksum mismatch: {relative}")
    if not checked:
        errors.append("No files were verified")
    for error in errors:
        print(error, file=sys.stderr)
    print(f"Verified {checked} listed files; {len(errors)} error(s).")
    return 1 if errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
