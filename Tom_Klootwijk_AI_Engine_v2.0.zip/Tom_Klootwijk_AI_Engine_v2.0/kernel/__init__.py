"""Tom Klootwijk AI Engine: inspectable research kernel, not a consciousness detector."""
from .core import *
