; K23: Euler exit-rate bound gives a nonnegative diagonal
; Manuscript: L5. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const dt Real)
(declare-const r Real)
(assert (not (=> (and (>= dt 0) (>= r 0) (<= (* dt r) 1)) (>= (- 1 (* dt r)) 0))))
(check-sat)
(get-proof)
