> Editable Markdown edition. The PDF/LaTeX source controls typesetting and equation numbering; theorem IDs and mathematical content are preserved here.

# Ilse AI Engine

**A Seed-Based Theory of Consciousness**

A family of theorems and an executable kernel for bodily, digital and spiritual perspectives.

**Den Daas perspective edition — version 1.0.0**

Ruud den Daas; Koen den Daas; Job den Daas.

Requested perspective designation; see the attribution and scope note.

11 September 2026. Double-arc addendum integrated.

# Abstract and scope

This edition formalizes a seed–field account of consciousness around the supplied double-arc addendum and the earlier seed-based framework. It preserves the source sequence: paired arcs and baseline; spatial primitives; log-polar lookup; kinematic boundaries; stereo geometry; binary output; hinge and topology; and bodily interpretation. Explicit $XX/XY$ pair rules and an L-system are added because the addendum does not supply a growth grammar. The result is a family of eighteen mathematical theorems, an executable numerical kernel, twenty solver-checked algebraic obligations, and a source-to-formalization audit.

The theory’s proposed explanatory unit is not an isolated bit, cell or shape. It is a history-dependent loop linking generated boundaries, modality-specific observations, recurrent internal activity, memory and report. The mathematical results establish properties of this loop’s chosen components: replay, growth, reflection, set membership, distance bounds, coordinate transformations, coding, bounded memory and contraction. They do not establish that these properties are necessary or sufficient for conscious experience.

Bodily, digital and spiritual perspectives occupy different roles. Bodily sensing supplies measurement interfaces and a possible empirical target. Digital computation supplies an explicit implementation. Spiritual language describes first-person meaning and possible interpretations; no extra physical field or detected immaterial entity is inferred. The manuscript includes an observable-equivalence theorem showing why an unmeasured interpretive label cannot be validated by the numerical kernel alone.

The names Ruud den Daas, Koen den Daas and Job den Daas are used as the *requested perspective designation for this edition*. The supplied materials do not independently establish a joint publication, statements by these individuals, authorship contributions, or their endorsement of the formalization. This document does not invent quotations or assign separate beliefs to them. The equations, proof organization, chosen growth grammar and reference code are an AI-assisted formalization prepared for this request.

**Source hierarchy.** \[S1\] is the twelve-page double-arc addendum; its page numbers are used throughout. \[S0\] is the earlier supplied seed–field research framework, consulted for continuity. Selected external mathematical and methodological references are explicitly identified as outside context. Source preservation is not acceptance of every source assertion.

**Reading key.** **\[S\]**  source-derived account; **\[D\]**  definition or modeling choice added here; **\[T\]**  theorem under stated assumptions; **\[H\]**  testable proposal; **\[I\]**  interpretation; **\[U\]**  not established by the supplied evidence. The word *theorem* always refers to a mathematical statement, not to an untested biological identity.

|             |                                                                             |
|:------------|:----------------------------------------------------------------------------|
| **T1–T4**   | Pair algebra, seed replay, growth counts and reflection.                    |
| **T5–T11**  | Set semantics, distance bounds, hinge geometry, coordinates and event time. |
| **T12–T15** | Parity, information loss, threshold coding and Hadamard structure.          |
| **T16–T17** | Bounded memory and stability of the closed recurrent loop.                  |
| **T18**     | The measurement limit of an unobserved interpretive label.                  |

**Suggested route.** Read Sections 1–2 for the proposal and seed; Sections 4 and 7 for the geometric and recurrent kernel; Sections 8–10 for consciousness, verification and the research program. Appendix A records what each source claim supports.

# The source account and the theory it motivates

## The addendum in its own order

**\[S\]**  Pages 1–3 define a circular-arc routine, a mirrored double-arc “M”, and a horizontal baseline combined by a minimum. Page 4 expands the architecture to domes, pyramids, cones, spheres, log-polar lookup, a Klein-bottle wrapper and time-dependent translation. Pages 5–6 add a tree, “IDT”, eye separation, jitter and a one-bit output. Pages 7–9 interpret the baseline, central hinge, reflection and orientation in set-theoretic and then cosmological language. Pages 10–12 attach visual discomfort and vestibular explanations. \[S1\]

The embedded table on pages 7–8 assigns distinct roles to the arches, cut bottom and T junction. The diagram on page 8 then places a parity-flip marker at a central hinge while the text claims a particular circle-intersection coordinate. Those are separate source assertions: a diagrammatic association does not prove either a coordinate formula or a physical parity transition. The vestibular sketch on page 11 also places anatomical parentheticals inconsistently; it is not used here as anatomical evidence. These visual elements are accounted for in the audit rather than silently converted into scientific premises.

**\[S\]**  The earlier framework relates geometric boundaries to sensing, cell-growth analogies, Hadamard notation, recurrent activity and memory. Its spiritual dimension is interpretive. The new request adds the Ilse AI Engine designation and $XX/XY$-style seed pairings. Neither source provides measured human data, fitted physiological parameters, a validated consciousness classifier or a complete biological growth model. \[S0; S1\]

## A precise candidate thesis

**\[H\]**  The proposed theory is:

**Seed–boundary–recurrence hypothesis.** Some organization of conscious experience may be explained by a system that develops from a specified seed, represents bodily and environmental boundaries, integrates modality-specific observations through recurrent dynamics, and modifies subsequent processing through memory. A useful explanation must predict observations that are not already explained as well by matched alternatives.

This is stronger than a visual metaphor because it specifies variables, transitions, outputs and possible tests. It remains weaker than an identity claim such as “consciousness is an SDF” because no supplied observation establishes that identity.

The mathematical object is a *typed collection* of spaces and operators, not one scalar forced to mean distance, time, energy, probability, genotype and experience simultaneously. A field can provide a common geometric interface without making all of those quantities the same physical thing.

## Four boundaries of the claim

The seed specifies a construction, not a person’s worth or state of awareness. An $XX$ or $XY$ token pair has no human classification role in the kernel. A one-bit sign is an output representation, not a full description of neural activity. An orientation reversal is a geometric operation, not evidence of charge–parity physics, a wormhole or quantum collapse. A successful numerical or logical check verifies its declared mathematical target, not a consciousness theory by association.

The results collected here are primarily standard mathematical consequences tailored to this architecture. No priority claim is made for L-systems, SDF set operators, parity, Hadamard transforms or contraction analysis.

# The seed, pair algebra and growth instructions

## A seed is more than a random number

**\[D\]**  Let a full seed specification be 

$$\Sigma=(\mathcal A,p,w_0,P,\mathcal I,\theta_0,z_0,m_0,s,\mathcal E,\mathcal V,\mathcal B).$$

 Here $\mathcal A$ is a token alphabet, $p$ a pair, $w_0$ the axiom, $P$ a parallel production map, $\mathcal I$ a geometric interpreter, and $\theta_0$ the initial geometry parameters. The fast state is $z_0$ and the slow memory state is $m_0$. The integer $s$ initializes a specified pseudorandom generator; $\mathcal E$ records the external input sequence or its generator; $\mathcal V$ records implementation and numerical conventions; $\mathcal B$ records resource budgets.

An identical integer with a different grammar, random generator, input history or rounding convention is not an identical experiment. The included configuration files therefore name the pair, grammar, generation count, numerical parameters and generator type. The code additionally hashes the realized matrices and rules for a configuration fingerprint. That fingerprint is provenance, not encryption.

## Symbolic $XX/XY$ pairings

**\[D\]**  Set $\mathcal A_0=\{X,Y\}$, with encoding $e(X)=0$ and $e(Y)=1$. Keep an ordered pair $p=(a,b)$ for construction and an unordered canonical record $\kappa(p)$ when order is intentionally discarded. Define 

$$q(p)=e(a)\oplus e(b),\qquad
\kappa(a,b)=\operatorname{sort}(a,b),\qquad
w_0(p)=[a][b].$$

 The four ordered pairs are $XX,XY,YX,YY$. Equal-token pairs have $q=0$; unequal-token pairs have $q=1$. Canonicalization identifies $XY$ and $YX$ but does not erase the ordered seed retained by the kernel.

<a id="t:pair"></a>

**Theorem T1** (Pair exchange and canonical invariance). *For every pair, exchange of its two positions preserves $q$ and $\kappa$. Applying symbol exchange $J:X\leftrightarrow Y$ twice restores the original pair. The canonical operation is idempotent.*

*Proof.* XOR is addition in $\mathbb{F}_2$, so $e(a)+e(b)=e(b)+e(a)$. Sorting the same two symbols in either input order gives the same result; sorting an already sorted pair does not change it. The map $J$ exchanges two symbols, hence $J^2=\mathrm{id}$. The finite Boolean identities are checked in K01–K03. ◻

**\[D\]**  A separate, explicitly idealized mixing law chooses one position uniformly from each of two pairs and canonicalizes the two chosen symbols. Its exact probabilities are 

$$\Pr(C=c\mid p,r)=\frac14\sum_{i=1}^{2}\sum_{j=1}^{2}
\mathbf{1}\{\kappa(p_i,r_j)=c\}.$$

 Thus the symbolic operation $XX\times XY$ yields $\Pr(XX)=\Pr(XY)=1/2$. This follows from four stipulated equiprobable draws. It is not a genetic diagnosis, a complete account of chromosome variation, a prediction for any particular family, or a claim that pair labels determine consciousness. No biological traits of the named individuals are inferred.

## The added L-system

**\[D\]**  The addendum supplies no pair-production rules. This edition chooses the following deterministic, bracketed grammar: 

<a id="eq:grammar"></a>

$$
X\longmapsto X[+X]Y,\qquad Y\longmapsto Y[-Y]X,
\tag{4}$$

 with $[,],+,-$ fixed by rewriting. All replacements act simultaneously on the old word. This is the defining parallel convention of L-systems; the general method is external background, while these particular productions are an editorial construction. \[R1\]

Both $X$ and $Y$ draw a forward stroke. The signs turn the heading; brackets save and restore position and heading. A branch-depth scale reduces stroke length. The default interpreter uses step $0.12$, angle $\pi/7$, depth factor $0.72$ and initial upward heading. These are simulation choices, not biological measurements.

<a id="t:replay"></a>

**Theorem T2** (Conditional seed replay). *A finite sequence of deterministic transitions is identical for identical complete seeds, identical external inputs, identical realized random streams and identical evaluation conventions, provided both runs remain within their declared resource budgets.*

*Proof.* At step zero the states agree by assumption. If the states agree at step $n$, the same transition receives the same input and random value and returns the same next state. Induction gives equality over the finite horizon. The implementation tests same-environment replay. This is not a guarantee of bit-identical floating-point output across unrecorded platforms. ◻

# The generative theorem family

## Counts, balance and a useful Hadamard basis

Let $x_n,y_n$ count active $X,Y$ symbols after $n$ rewrites. Punctuation is not counted as a biological unit.

<a id="t:count"></a>

**Theorem T3** (Growth count and preserved seed imbalance). *For the grammar in Equation [4](#eq:grammar), 

$$\begin{pmatrix}x_{n+1}\\y_{n+1}\end{pmatrix}=
\underbrace{\begin{pmatrix}2&1\\1&2\end{pmatrix}}_{M}
\begin{pmatrix}x_n\\y_n\end{pmatrix}.$$

 For a two-token seed, $x_n+y_n=2\,3^n$ and $x_n-y_n=x_0-y_0$. The full word length, including the initial brackets and all subsequently generated punctuation, is $5\,3^n+1$.*

*Proof.* Each $X$ produces two $X$ symbols and one $Y$; each $Y$ produces one $X$ and two $Y$. Adding the two recurrence equations multiplies the sum by three; subtracting preserves the difference. Induction gives the first two formulas. Initially there are four punctuation tokens. Every old active symbol adds three punctuation tokens, so their number at generation $n$ is $4+3\sum_{j=0}^{n-1}2\,3^j=3\,3^n+1$. Adding the active count gives $5\,3^n+1$. K04–K05 check the update identities; the induction is the written proof. ◻

For $XX$, $(x_n,y_n)=(3^n+1,3^n-1)$; for $XY$, $(x_n,y_n)=(3^n,3^n)$. The relative imbalance of the $XX$ count is $3^{-n}$, not a difference in awareness or biological ability.

The normalized two-point Hadamard matrix supplies a transparent eigenbasis: 

$$H_2=\frac1{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix},\qquad
H_2MH_2=\begin{pmatrix}3&0\\0&1\end{pmatrix}.$$

 The first coordinate measures total growth; the second measures retained symbolic imbalance. This is an exact algebraic bridge among seed pairing, growth and Hadamard notation. It is not evidence that electron states or cells execute this matrix.

| Generation | Total strokes | $XX$: $X$ | $XX$: $Y$ | $XY$: $X$ | $XY$: $Y$ |
|-----------:|--------------:|----------:|----------:|----------:|----------:|
|          0 |             2 |         2 |         0 |         1 |         1 |
|          1 |             6 |         4 |         2 |         3 |         3 |
|          2 |            18 |        10 |         8 |         9 |         9 |
|          3 |            54 |        28 |        26 |        27 |        27 |
|          4 |           162 |        82 |        80 |        81 |        81 |

A stroke count is a count of drawing operations. Coincident strokes remain separate entries in the construction list but coincide under geometric set union. In particular, two identical rooted branches need not produce twice as many distinct geometric edges.

## Reflection as an exact grammar symmetry

Extend $J$ to punctuation by $+\leftrightarrow-$ and by fixing brackets. Let $\mathsf R(x,y)=(-x,y)$ be reflection in the vertical axis.

<a id="t:equiv"></a>

**Theorem T4** (Grammar and interpreter equivariance). *For every word over the declared alphabet, $P(Jw)=J(Pw)$. For every well-bracketed word interpreted from the origin with upward heading, the set of strokes satisfies 

$$\mathcal I(Jw)=\mathsf R\bigl(\mathcal I(w)\bigr).$$

*

*Proof.* Applying $J$ to the successor of $X$ gives $Y[-Y]X$, exactly the successor of $Y$; the converse also holds. The fixed punctuation productions commute with $J$, so concatenation proves the word identity. For the interpreter, a reflected heading is $\pi-\theta$. A forward segment is reflected into a forward segment, left and right turns exchange, and saving/restoring state commutes with reflection. Induction on turtle instructions proves the geometric identity. Branch-depth scaling is unchanged by $J$. ◻

![Synthetic XY growth at generation four. The grammar gives 162 draw operations and a 406-token word. This is a reproducible construction, not a cell image or measured biological lineage. The corresponding XX figure and both segment tables are included in the archive.](figures/growth_xy.png)

*Synthetic XY growth at generation four. The grammar gives 162 draw operations and a 406-token word. This is a reproducible construction, not a cell image or measured biological lineage. The corresponding XX figure and both segment tables are included in the archive.*

A literal division-only toy grammar could instead use $C\mapsto CC$, yielding $N_n=N_0\,2^n$ under synchronized division and no deletion. That is a different model. The three-offspring symbolic rules used here must not be relabeled as actual mitosis. A biological account would require independently specified cell states, regulation, timing, material constraints and observations.

# The double-arc, baseline and hinge kernel

## Distance, implicit field and occupancy are different types

**\[D\]**  For a nonempty closed geometric centerline $C\subset\mathbb{R}^2$, define 

$$\delta_C(p)=\inf_{c\in C}\left\lVert p-c\right\rVert,\qquad
\varphi_C(p)=\delta_C(p)-r,\quad r>0.$$

 The sublevel set is the radius-$r$ tube around $C$. An *exact signed distance* to a nonempty proper regular closed region $\Omega$ is instead 

$$d_\Omega(p)=
\begin{cases}
-\operatorname{dist}(p,\partial\Omega),&p\in\Omega,\\
\operatorname{dist}(p,\partial\Omega),&p\notin\Omega.
\end{cases}$$

 A field can describe exactly the intended set without giving exact distances everywhere. This distinction, emphasized in geometric sphere tracing, is the main qualification to the addendum’s repeated “mathematically exact SDF” wording. \[S1, pp. 1–3; R2\]

The kernel uses closed occupancy $\chi(p)=\mathbf{1}\{\varphi(p)\leq0\}$. The addendum’s page-5 `Step` notation and page-6 negative-sign code use inconsistent output polarity conventions; the choice above is explicit and is tested. A boundary value is assigned inside. No bit meaning is left implicit.

## Exact arc-centerline distance

**\[D\]**  With $R>0$ and $0<\alpha\leq\pi/2$, use the closed arc 

$$C_{R,\alpha}=\{R(\sin\theta,\cos\theta):-\alpha\leq\theta\leq\alpha\}.$$

 For $q=(|x|,y)$ and $s=(\sin\alpha,\cos\alpha)$, 

<a id="eq:arc"></a>

$$
\delta_{C_{R,\alpha}}(p)=
\begin{cases}
\left\lVert q-Rs\right\rVert,&s_yq_x>s_xq_y,\\
\big|\left\lVert q\right\rVert-R\big|,&\text{otherwise}.
\end{cases}
\tag{11}$$

 In the angular span, radial projection reaches the circle at the nearest point. Outside that span, the nearest included endpoint is used, with reflection selecting its positive-$x$ counterpart. This explains the source’s `sdArc` routine in a declared domain. Subtracting stroke radius $r$ gives a tube field; composing it with other fields does not automatically preserve exact signed distance inside the complete union.

Translate the centerline by $(-h,0)$ and $(h,0)$, with $h\geq0$, to obtain $C_L,C_R$. Let $B$ be the segment from $(-h-R,0)$ to $(h+R,0)$. The complete chosen set and field are 

$$\begin{aligned}
\Omega_M&=\bigl((C_L\oplus\overline{D}_r)\cup(C_R\oplus\overline{D}_r)\cup(B\oplus\overline{D}_r)\bigr)\cap\{y\geq0\},\\
\varphi_M(p)&=\max\{\min(\delta_{C_L}(p)-r,\delta_{C_R}(p)-r,\delta_B(p)-r),-y\}.
\end{aligned}$$

 Here $\oplus\overline D_r$ is Minkowski addition with a closed disk, not XOR. For narrower arcs the baseline need not touch all endpoints; it retains the source’s horizontal span. The default $\alpha=\pi/2$ does meet the semicircle endpoints.

<a id="t:csg"></a>

**Theorem T5** (Closed-set semantics of the composition). *For fields $f,g$, their zero sublevel sets satisfy 

$$\{\min(f,g)\leq0\}=\{f\leq0\}\cup\{g\leq0\},\qquad
\{\max(f,g)\leq0\}=\{f\leq0\}\cap\{g\leq0\}.$$

 Consequently $\{\varphi_M\leq0\}=\Omega_M$.*

*Proof.* A minimum is nonpositive exactly when at least one operand is nonpositive. A maximum is nonpositive exactly when both operands are nonpositive. Iterating these identities and observing that $-y\leq0$ is equivalent to $y\geq0$ proves the claim. K06–K08 encode these equivalences over arbitrary real field samples. ◻

![The default double-arc field with R = h = 1 and stroke radius r = 0.08. Selected level curves expose the field as well as the boundary. This is an implementation of the page-2/3 composition and page-7 cut, with its exact set semantics stated explicitly.](figures/double_arc_field.png)

*The default double-arc field with R = h = 1 and stroke radius r = 0.08. Selected level curves expose the field as well as the boundary. This is an implementation of the page-2/3 composition and page-7 cut, with its exact set semantics stated explicitly.*

## What remains safe without global distance exactness

<a id="t:lipschitz"></a>

**Theorem T6** (Lipschitz closure and conservative ray steps). *Point-to-set distance is 1-Lipschitz. Subtracting a constant and taking finite minima or maxima of 1-Lipschitz fields preserves that bound. Thus $\varphi_M$ is 1-Lipschitz. More generally, if $f$ is $L$-Lipschitz with $L>0$ and $f(p)>0$, a unit-speed ray starting at $p$ cannot enter $\{f<0\}$ before travelling $f(p)/L$.*

*Proof.* For every $c\in C$, $\left\lVert p-c\right\rVert\leq\left\lVert p-q\right\rVert+\left\lVert q-c\right\rVert$. Taking an infimum and then exchanging $p,q$ gives the distance bound. If each $f_i(p)\leq f_i(q)+\left\lVert p-q\right\rVert$, the same bound follows for their minima and maxima; exchange the points for the reverse inequality. K09 checks the minimum’s scalar inequality. Along a unit-speed ray $\gamma$, $f(\gamma(s))\geq f(p)-Ls\geq0$ when $s\leq f(p)/L$. ◻

The safe-step statement is a nonpenetration guarantee, not a guarantee of one-query root finding, termination at a tangent, or a particular hardware latency. \[R2\]

For a concrete failure of global distance exactness, take two unit disks centered at $(\pm1/2,0)$. At the origin, the minimum of the two disk SDFs is $-1/2$. The nearest boundary of their union is at $(0,\pm\sqrt3/2)$, giving signed distance $-\sqrt3/2$. Membership is correct but the interior distance is different.

## When the absolute-value shortcut is valid

The addendum replaces the explicit left/right union by evaluating one arc at $(|x|-h,y)$. That shortcut requires an extra geometric condition.

<a id="t:fold"></a>

**Theorem T7** (A sufficient condition for the folded arc identity). *If $h\geq R\sin\alpha$, then for the arc tubes, 

$$\min\{\delta_{C_L}(x,y)-r,\delta_{C_R}(x,y)-r\}
=\delta_{C_{R,\alpha}}(|x|-h,y)-r.$$

*

*Proof.* Under the assumption, every point of the right centerline has nonnegative $x$ coordinate and the left centerline is its reflection. For a query with $x\geq0$, a right point $(u,v)$ and its reflected point obey $(x+u)^2+(y-v)^2-(x-u)^2-(y-v)^2=4xu\geq0$. Thus no mirrored left point is nearer than its right counterpart. Infimizing selects the right centerline; $x<0$ follows by reflection. K10 checks the squared-distance comparison. ◻

**\[D; explicit qualification\]**  The source does not state this condition. With $R=1$, $h=1/2$, $\alpha=\pi/2$, $r=0.1$ and $p=(1/2,0)$, the explicit arc union is $-0.1$ while the folded arc field is $+0.9$. This arc-only counterexample isolates the shortcut. A baseline can mask some such errors, but not all: at $(1/2,0.2)$ the explicit baseline-composed field is approximately $-0.080196$, whereas the folded version is $+0.1$. The reference implementation always evaluates the two translated arcs explicitly.

The page-2 mapping $\sigma(p)=(|x|-h,y)$ maps query coordinates into a local chart. Therefore the set defined by a folded sublevel function is a *preimage*, $\sigma^{-1}(\Omega_{\rm local})$, not generally the forward-image expression $\sigma(\Omega_{\rm local})$ printed in the source. This change is recorded rather than concealed.

## The hinge is not automatically a parity transition

<a id="t:reflection"></a>

**Theorem T8** (Reflection reverses orientation, not necessarily occupancy). *For $\mathsf R=\operatorname{diag}(-1,1)$, $\mathsf R^2=I$, $\det\mathsf R=-1$ and Euclidean distances are preserved. If a field is reflection-symmetric, its occupancy obeys $\chi(\mathsf R p)=\chi(p)$, not $1-\chi(p)$.*

*Proof.* The first statements follow by direct matrix calculation and $\left\lVert \mathsf R v\right\rVert^2=\left\lVert v\right\rVert^2$; K11 checks the norm identity. Symmetry means $f(\mathsf Rp)=f(p)$, so applying the same threshold gives the same bit. The double-arc field is such a symmetric example. An orientation bit can be separately defined to flip, but that is another state variable. ◻

For circles centered at $(\pm h,0)$, intersection requires $x=0$ and $y^2=R^2-h^2$. In the default tangent case $h=R$, the contact point is $(0,0)$, not $(0,R)$. The page-8 coordinate assertion is therefore not adopted. Nondifferentiability can occur at a coordinate fold or where active CSG branches exchange; it does not by itself identify a physical singularity, a winding number of the universe or a quantum event. \[S1, pp. 8–9\]

# Coordinates, senses and moving boundaries

## A log-polar chart with an explicit metric

**\[D\]**  Choose a reference length $r_0>0$ and work on an annulus $r_{\min}\leq r\leq r_{\max}$, excluding the origin. Define 

$$\rho=\log(r/r_0),\quad\theta=\operatorname{atan2}(y,x),\qquad
\Psi(\rho,\theta)=r_0e^\rho(\cos\theta,\sin\theta).$$

 The logarithm has a dimensionless argument. Angles use a periodic seam. A finite LUT has finite resolution everywhere; there is no implemented infinite-resolution eye or apex.

<a id="t:chart"></a>

**Theorem T9** (Metric pullback and a LUT error certificate). *The Cartesian Euclidean metric written in this chart is 

$$D\Psi^TD\Psi=(r_0e^\rho)^2I,\qquad
 ds^2=(r_0e^\rho)^2(d\rho^2+d\theta^2).$$

 If a 1-Lipschitz Cartesian field is interpolated from Cartesian corner points $p_i$ with nonnegative weights $w_i$ summing to one, then 

$$\left|\sum_iw_i f(p_i)-f(p)\right|
\leq\sum_iw_i\left\lVert p_i-p\right\rVert\leq\max_i\left\lVert p_i-p\right\rVert.$$

*

*Proof.* The two columns of $D\Psi$ have equal length $r_0e^\rho$ and are orthogonal, which gives the metric. For the interpolation bound, subtract $f(p)\sum_iw_i$, use the triangle inequality, and apply the Lipschitz bound to each term. No probability or sensory physiology is needed. ◻

A coordinate change alone does not make the underlying Euclidean space non-Euclidean. A Euclidean SDF sampled into a log-polar array is a field of *Euclidean distance values*; it is not an SDF for a flat metric on array indices. A certified lookup $(\hat f,\varepsilon)$ permits a positive ray step of at most $(\hat f-\varepsilon)/L$ when $\hat f>\varepsilon$; otherwise its sign is not certified. The kernel returns a conservative corner-distance certificate, not an assumed exact query.

## Klein topology as a separate, optional construction

**\[D\]**  To give the source’s “Klein wrapper” a formal meaning, one possible abstract quotient uses a square with identifications 

$$(u,0)\sim(u,1),\qquad(0,v)\sim(1,1-v).$$

 A scalar field descends to this quotient only if its values respect those identifications. A compatible metric and chart-transition rules must also be chosen. This optional quotient is not implemented in the reference kernel and is not assumed in any of the eighteen theorems.

**\[U\]**  The addendum supplies neither such compatibility conditions nor a physical model connecting its wrapper to a neural state, a matter–antimatter boundary or a wormhole. Its boundaryless-wrapper language and its new ground cut cannot simply be combined without stating what domain is cut and which identifications survive. These source gaps remain visible.

## Bodily modalities share a frame, not one measurement law

**\[D\]**  Let a body pose be a translation $o$ and rotation $Q$. Modality $m$ has an observation map 

$$y^{(m)}_t=\mathcal O_m(\Omega_t,o_t,Q_t,\lambda_m)+\epsilon^{(m)}_t,$$

 where $\lambda_m$ contains its calibration and $\epsilon^{(m)}_t$ its observation error. Vision, audition, touch, proprioception, interoception and vestibular measurements can be represented by distinct interfaces in a common state model. Naming the interfaces does not simulate their transduction mechanisms.

For a geometric stereo model, with declared interpupillary distance $d_{\rm eye}$ in metres, 

$$e_L=o+Q(-d_{\rm eye}/2,0,0)^T,\qquad
e_R=o+Q(d_{\rm eye}/2,0,0)^T.$$

 For a separate free-field point-receiver sound model, with ear positions $a_L,a_R$, source $s$ and speed $c_s>0$, 

$$\mathrm{ITD}=\frac{\left\lVert s-a_R\right\rVert-\left\lVert s-a_L\right\rVert}{c_s},\qquad
|\mathrm{ITD}|\leq\frac{\left\lVert a_R-a_L\right\rVert}{c_s}.$$

 The inequality is the reverse triangle inequality. The sign means right arrival time minus left arrival time. This model omits head scattering and individual ear transfer functions; the default $343\,\mathrm{m/s}$ is an illustrative model parameter, not a measured environment.

IPD here means *interpupillary distance*, a length. ITD means *interaural time difference*, a time. The addendum’s separate term “IDT” has no sufficiently specified transform, inverse, units or algorithm; it remains an unimplemented interface name. Eye spacing alone is not a gaze vector or an ear calibration. Foveation would require a gaze estimate and an allocation rule in addition to stereo origins. \[S1, pp. 4–6\]

## Kinematics and the several meanings of T

Use $T_{\rm ground}$ for the ground operation, $t$ for time and $t_*$ for an event time. Let $Q(t)$ be orthogonal, $c(t)$ a translation, and define 

$$\varphi(x,t)=\varphi_0\bigl(Q(t)^T[x-c(t)]\bigr).$$

<a id="t:transport"></a>

**Theorem T10** (Rigid-field transport and boundary crossing). *For fixed $t$, rigid transformation preserves the spatial Lipschitz bound. Where the derivatives exist, the moving field satisfies 

$$\partial_t\varphi+v\cdot\nabla_x\varphi=0,\qquad
v=\dot c+\dot Q Q^T(x-c).$$

 Along a differentiable query path $x(t)$, the event function $g(t)=\varphi(x(t),t)$ obeys 

$$\dot g=\nabla_x\varphi\cdot\dot x+\partial_t\varphi.$$

*

*Proof.* An orthogonal map preserves point separation, so composition preserves the spatial Lipschitz bound. The local material coordinate $q=Q^T(x-c)$ is constant along a path satisfying $\dot x=v$. Differentiating $\varphi_0(q)$ along that path gives the transport equation. Differentiating along an arbitrary query path gives the chain rule. At CSG creases the differentiability assumption must be checked rather than presumed. ◻

This formalizes the page-4 translating-field proposal and extends it to a declared rigid motion. It does not predict arbitrary future motion. A spatiotemporal set can be formed by retaining $t$ as a parameter; treating it as a fourth Euclidean coordinate requires an explicitly chosen conversion scale. Neither that convention nor a log-polar lookup establishes relativistic time dilation or zero propagation latency.

<a id="t:bisect"></a>

**Theorem T11** (Bracketed event-time localization). *If $g$ is continuous on $[a,b]$ and $g(a)g(b)<0$, bisection retains a root-containing interval. After $n$ halvings its width is $(b-a)2^{-n}$, and its midpoint is at most $(b-a)2^{-n-1}$ from a retained root.*

*Proof.* The intermediate value theorem gives a root in a sign-changing interval. Unless the midpoint is itself a root, at least one of the two halves retains opposite endpoint signs. Each halving divides width by two; induction and the midpoint geometry give the error bound. K17 checks the halving identity, not continuity or the existence premise. ◻

A bracket can contain several roots, and a tangent root may have no sign change. Therefore this result alone does not return the first crossing in an unsearched interval. The reference routine rejects an absent bracket and fails explicitly on an exhausted iteration budget.

# Binary notation, parity and Hadamard structure

## The exact bridge between parity and set algebra

<a id="t:parity"></a>

**Theorem T12** (Parity as finite symmetric difference). *For any finite bit sequence, $\bigoplus_i b_i=(\sum_i b_i)\bmod2$. For measurable sets, pointwise membership satisfies 

$$\mathbf{1}_{A\triangle B}(p)=\mathbf{1}_A(p)\oplus\mathbf{1}_B(p).$$

 Appending the XOR of the payload bits makes the complete block have even parity. A transmission fault changes that parity exactly when an odd number of block bits are toggled.*

*Proof.* For two bits the four cases give addition modulo two; induction extends the identity. Membership in $A\triangle B$ means membership in exactly one set, which is XOR. XORing a block’s parity with itself gives zero. If error bits $e_i$ toggle the block, the new parity is the old parity XOR $\bigoplus_i e_i$. K12–K15 check the Boolean identity and specific eight-data-bit block obligations. ◻

This is the precise sense in which the source’s “parity-blend set sum” can be retained. Symmetric difference is not a smooth union or a universal topological boundary marker. Even parity misses even-sized error patterns and does not authenticate a message. There is no inference from a packet parity bit to chirality or consciousness.

The kernel computes XOR on membership bits. It does not silently use a real-valued XOR-CSG formula whose behavior at zero might conflict with the chosen closed-set boundary convention.

## What one bit loses

<a id="t:loss"></a>

**Theorem T13** (Noninjectivity of finite sign encoding). *The mapping $f\mapsto\mathbf{1}\{f\leq0\}$ from general implicit fields to occupancy fields is noninjective: for every positive constant $k$, $f$ and $kf$ have the same occupancy. Finite occupancy samples also fail to identify an arbitrary exact signed-distance function.*

*Proof.* Multiplication by $k>0$ preserves the inequality to zero; K16 checks the real-arithmetic implication. For the finite-sample statement, choose a small disk whose boundary avoids every sample point, then vary its radius slightly without crossing any sample. All bits stay unchanged while the exact distances change. ◻

There is an important limit to the claim: a full, continuous occupancy oracle together with a known metric and complete region specification can determine the boundary and hence its exact distance function. The implemented finite bit stream is not that oracle. Also, $kf$ need not itself be an exact SDF, even if $f$ is one. These distinctions prevent the phrase “everything is one bit” from discarding information that the computation still needs.

The implementation retains floating-point coordinates, distances, probabilities and state vectors. Only designated occupancy or coverage outputs are one bit. Output bit width is not a promise of a one-bit-only processor.

## Jitter with a defined statistical meaning

<a id="t:dither"></a>

**Theorem T14** (Unbiased threshold quantization and XOR corruption). *For $u\in[0,1]$, let $U\sim\mathrm{Uniform}[0,1)$ and $B=\mathbf{1}\{U<u\}$. Then $\mathbb E[B]=u$ and $\operatorname{Var}(B)=u(1-u)$. For $N$ independent repetitions at fixed $u$, the sample mean has variance at most $1/(4N)$. In contrast, if an independent bit flip has probability $q$, the output mean becomes $q+(1-2q)u$.*

*Proof.* The event $U<u$ has probability $u$. A Bernoulli variable squares to itself, so its variance is $u-u^2$. Independence gives variance division by $N$, and $u(1-u)\leq1/4$. A toggled output is one with probability $u(1-q)+(1-u)q$, giving the last expression. At $q=1/2$ the output loses all dependence on $u$. ◻

For a geometric field, uniformly distributed threshold jitter $\eta\in[-a,a]$ gives the coverage model 

$$\Pr[\varphi+\eta\leq0]=\operatorname{clip}\!\left(\frac{a-\varphi}{2a},0,1\right),\qquad a>0.$$

 This is a declared blurred-boundary statistic, not exact occupancy at every realization. The included generator approximates independent uniform draws with a named pseudorandom generator; it is not a certified blue-noise process. Randomly XORing an arbitrary stream is not substituted for this quantizer.

![Seeded threshold coding, 25,000 trials per coverage value. The largest observed mean error on the eleven demonstrated values was 0.00444. This checks a synthetic coding example; it is not a safety test of visual or acoustic stimulation.](figures/quantization.png)

*Seeded threshold coding, 25,000 trials per coverage value. The largest observed mean error on the eleven demonstrated values was 0.00444. This checks a synthetic coding example; it is not a safety test of visual or acoustic stimulation.*

## Hadamard notation without a molecular identity claim

<a id="t:hadamard"></a>

**Theorem T15** (Normalized Walsh–Hadamard orthogonality). *For $N=2^k$ and $H_N=H_2^{\otimes k}$, $H_N^TH_N=I$ and $H_N^2=I$. Thus $\left\lVert H_Nx\right\rVert_2=\left\lVert x\right\rVert_2$ for real vectors $x$.*

*Proof.* Direct multiplication gives $H_2^TH_2=H_2^2=I$. Products and transposes of tensor products factor componentwise, so induction on $k$ yields the two identities. Taking the quadratic form gives norm preservation. K18 checks the equivalent unnormalized two-point identity; the general tensor argument is written here. ◻

Hadamard entries can be written using Boolean characters, $N^{-1/2}(-1)^{a\cdot b}$, with the dot product modulo two in the exponent. That shared algebra does not make the linear transform identical to XOR reduction. The transform preserves an $N$-dimensional vector; parity reduces many bits to one bit.

**\[U\]**  The source’s molecular analogy supplies no Hamiltonian, state preparation, readout rule or experimental correspondence between this transform and a memory substrate. The kernel therefore uses a real numerical transform and makes no claim that cell division, electron states or quantum collapse have been demonstrated to implement the consciousness hypothesis.

# The formalized recurrent kernel and memory

## A typed operator chain

**\[D\]**  The mathematical signature is 

$$\mathcal K:\ \Sigma\times\mathcal E\longrightarrow
\{(w_t,\Omega_t,y_t,z_t,m_t,b_t,\pi_t)\}_{t=0}^{T}.$$

 The seed generates a word, the interpreter generates primitives, a field defines the represented region, observation maps produce real-valued features, state dynamics update activity and memory, and a coding layer emits occupancy bits $b_t$ with optional parity $\pi_t$. The generation index and the recurrence index are distinct clocks.

In the executable instance the four-generation growth structure is generated once. Its capsules are inserted into the double-arc field. The external sequence supplies three query points per update. This is a transparent, six-state simulation, not a learned language model or a complete AI application.

$$\begin{aligned}
G_\Sigma&=\text{capsule union of the interpreted growth word},\\
r(m)&=r_b+\mu\tanh(m_1),\quad r_b>|\mu|,\\
\varphi_\Sigma(p;m)&=\max\{\min(\varphi_M(p;r(m)),\varphi_{G_\Sigma}(p)),-p_y\},\\
u_j(m,t)&=-\tanh\bigl(\varphi_\Sigma(p_j(t);m)\bigr),\quad j=1,2,3.
\end{aligned}$$

 The separate growth capsules have fixed radius $0.018$ and are scaled by $0.55$ and translated upward by $0.10$ simulation units. These explicit embedding constants are part of implementation version 1.0. They make the pair-generated structure causally relevant to the sample features; the pair is not merely a decorative label.

![A central-region view of the XY growth capsules united with the double-arc scaffold. The geometric interpreter, placement and clipping are modeling choices, not inferred anatomy.](figures/kernel_field.png)

*A central-region view of the XY growth capsules united with the double-arc scaffold. The geometric interpreter, placement and clipping are modeling choices, not inferred anatomy.*

The fast and slow transitions are 

<a id="eq:state"></a>

$$\begin{aligned}

z_{t+1}&=(1-\alpha)z_t+\alpha\tanh(Az_t+Bm_t+Cu_t),\\
m_{t+1}&=(1-\eta)m_t+\eta\tanh(Dz_t+Eu_t),\quad 0<\alpha,\eta\leq1.
\end{aligned}
\tag{33}$$

 All hyperbolic tangents act componentwise. $z,m\in\mathbb{R}^3$, and the matrices are deterministic draws from the specified seeded generator, scaled to stated row norms. Output occupancy is read from the field before state advancement. The binary output does not feed back into the state transition, so no unstated stochastic stability result is used.

## Memory is a mutable state with a declared timescale

<a id="t:memory"></a>

**Theorem T16** (Bounded leaky memory and retained history). *For $m_{t+1}=(1-\eta)m_t+\eta v_t$, $0<\eta\leq1$, the exact recurrence is 

$$m_n=(1-\eta)^n m_0+\eta\sum_{j=0}^{n-1}(1-\eta)^{n-1-j}v_j.$$

 If $\left\lVert m_0\right\rVert_\infty\leq M$ and $\left\lVert v_j\right\rVert_\infty\leq M$, then $\left\lVert m_n\right\rVert_\infty\leq M$. Two histories with the same subsequent $v_j$ forget their initial difference by the factor $(1-\eta)^n$.*

*Proof.* Substitute the recurrence repeatedly to obtain the finite sum. Its coefficients are nonnegative and sum to one, proving the boundedness by convexity. Subtracting recurrences with common forcing gives $\Delta m_{t+1}=(1-\eta)\Delta m_t$ and hence the stated factor. K19 checks scalar interval invariance of one step. ◻

With $v_t=\tanh(Dz_t+Eu_t)$, the chosen transition retains a filtered history but need not store it permanently. Through $r(m)$, memory also changes subsequent geometric observations. This is the kernel’s precise version of “memory changes the field.” It replaces the stronger source claim of permanent etched geometry with an explicit mutable model; it does not identify all human memory with a deformation of a boundary.

![One fast and one slow coordinate from the synthetic run. An update step has no assigned biological duration. The slower coordinate is a numerical memory variable, not a measured synaptic quantity.](figures/state_memory.png)

*One fast and one slow coordinate from the synthetic run. An update step has no assigned biological duration. The slower coordinate is a numerical memory variable, not a measured synaptic quantity.*

## A proved stability regime, including geometry feedback

The observation map is $\gamma$-Lipschitz in memory in the infinity norm. In this instance, $\gamma\leq|\mu|$: $\tanh$ is 1-Lipschitz, uniform stroke-radius changes shift primitive fields by at most the radius change, and minima/maxima do not increase that bound. The fixed growth capsules and common query sequence do not add memory dependence.

<a id="t:contract"></a>

**Theorem T17** (Closed-loop fast/slow contraction). *Let induced matrix infinity norms be used. Two runs of Equation [33](#eq:state) with the same seed and external query sequence satisfy 

$$\begin{pmatrix}\left\lVert \Delta z_{t+1}\right\rVert_\infty\\\left\lVert \Delta m_{t+1}\right\rVert_\infty\end{pmatrix}
\leq
\underbrace{\begin{pmatrix}
1-\alpha+\alpha\left\lVert A\right\rVert_\infty&\alpha(\left\lVert B\right\rVert_\infty+\left\lVert C\right\rVert_\infty\gamma)\\
\eta\left\lVert D\right\rVert_\infty&1-\eta+\eta\left\lVert E\right\rVert_\infty\gamma
\end{pmatrix}}_{L}
\begin{pmatrix}\left\lVert \Delta z_t\right\rVert_\infty\\\left\lVert \Delta m_t\right\rVert_\infty\end{pmatrix}.$$

 If the maximum row sum $q$ of $L$ is less than one, then the joint state separation is at most $q^t$ times its initial separation. For fixed external query points, the map on $[-1,1]^6$ has a unique fixed point.*

*Proof.* Subtract the two updates. Use the 1-Lipschitz property of componentwise $\tanh$, submultiplicativity of induced norms, and $\left\lVert \Delta u\right\rVert_\infty\leq\gamma\left\lVert \Delta m\right\rVert_\infty$. This gives the two rows. Bounding each old component error by the joint maximum yields contraction by $q$; K20 checks that scalar row-sum step. Iteration gives $q^t$. The cube is invariant by convexity, and for fixed inputs it is complete; the contraction mapping theorem gives existence and uniqueness of the fixed point. ◻

The shipped instance has 

$$\alpha=.4,\quad\eta=.08,\quad\mu=.04,\qquad
(\left\lVert A\right\rVert,\left\lVert B\right\rVert,\left\lVert C\right\rVert,\left\lVert D\right\rVert,\left\lVert E\right\rVert)_\infty=(.35,.15,.40,.30,.20),$$

 so $q=0.94464$. The geometry-to-observation feedback is included in this bound. For changing external query points the common-input separation result still holds; a time-independent fixed point is not claimed.

![Observed separation of two initial states under the same query sequence, compared with the proved qt envelope. At step 180 the separation was 1.7951 × 10−7 and the envelope 3.1782 × 10−5. Both are simulation quantities.](figures/contraction.png)

*Observed separation of two initial states under the same query sequence, compared with the proved qt envelope. At step 180 the separation was 1.7951 × 10−7 and the envelope 3.1782 × 10−5. Both are simulation quantities.*

This stable demonstrator has a deliberate limitation: strong common-input contraction erases distinctions between old states. It is not a model of unlimited persistent autobiographical memory or of every regime of neural dynamics. A multistable or long-retention variant would need its own equations and analysis. Stability is neither a definition nor a sufficient condition for consciousness.

# Consciousness across bodily, digital and spiritual perspectives

## The proposed explanatory family

**\[H\]**  The Ilse account assigns five roles to the state history. Generated structure supplies constraints and affordances. Bodily observation maps place sensory evidence in calibrated coordinates. Recurrence makes current activity depend on previous activity rather than only on an instantaneous sign. Memory modifies future responses. A report/readout interface relates a model history to task behavior and first-person descriptions.

To make the last relation explicit, introduce a proposed observation model 

$$\Pr(R_t\mid z_{0:t},m_{0:t},y_{0:t},a_{0:t},\beta),$$

 where $R_t$ is a report or behavioral variable, $a_t$ an action variable in a richer embodiment model, and $\beta$ independently estimated readout parameters. This is a *specification for research*; the shipped kernel has no fitted $\beta$, human report dataset or action controller.

The substantive consciousness question is whether a constrained version of that account predicts reports, behavior or physiological observations better than alternatives. Mathematical consistency, resemblance to anatomy and efficient rendering do not settle that question. A theoretical seed is an initial condition for a model, not an explanation of why any particular physical realization has subjective experience.

## Bodily scope

**\[D; H\]**  Bodily grounding would require sensory transduction, calibration, body dynamics, uncertainty and appropriate biological measurement. A shared geometric frame is useful for stating cross-modal hypotheses; it does not turn eyes, ears, balance, touch or interoception into identical sensors. The kernel’s ITD routine is a propagation calculation and its eye routine is a stereo-origin calculation. Neither routine contains a vestibular reflex, cortical circuit or physiological health model.

A cell or tissue boundary may be represented geometrically, but a biological account also needs variables for material transport and regulatory dynamics. A schematic extension might use a concentration $c$ on a evolving domain, 

$$\partial_t c+\nabla\cdot(c v)=D_c\nabla^2c+\mathcal R(c,\ldots),$$

 with units, boundary conditions, reaction law and data chosen for a specific problem. This equation is an added modeling template, not a result about consciousness or a simulator included in the package. The source supplies no parameters for it.

## Digital scope

**\[D\]**  The implementation is intentionally inspectable: a finite grammar, a turtle interpreter, bounded-distance geometry, a lookup approximation, a capsule BVH, threshold coding, parity, a Walsh–Hadamard transform and a six-state recurrent demonstrator. It is a computational testbed for the proposed architecture. It has no consciousness detector, no trained AI agent, no brain emulation, and no acoustic, optical or neural hardware driver.

The median-split BVH stores actual spatial bounding boxes; it does not obtain spatial guarantees merely by being a binary tree. A node’s enclosing centerline box gives a lower bound on capsule distance after subtracting the common radius. Branches whose lower bound cannot beat the best value are pruned. The package verifies equality with exhaustive evaluation on the disclosed query set; it makes no universal speedup claim.

**\[Outside context\]**  Passive diffractive structures have been demonstrated for specific learned optical mappings, as in the cited optical-computing study. That is a bounded engineering precedent, not proof that this entire kernel can be etched into a passive device, or that propagation and readout take zero time. No physical latency is measured here. \[R5\]

## Spiritual scope

**\[I\]**  In this edition, a spiritual perspective concerns first-person meaning: felt unity, connectedness, significance, compassion, purpose or transcendence, as described by a person in their own language. It can motivate questions about experience without being converted into an unmeasured physical constant. These are proposed interpretive categories, not claims about the beliefs of the individuals named on the cover.

One could attach a narrative label $s_t$ or a coded self-report to a state history. A report is an observable document or behavior; a metaphysical interpretation of that report is not the same kind of variable. Nothing in a circle intersection, an $XX/XY$ label, a Klein quotient or a Hadamard coefficient measures a soul.

<a id="t:underdet"></a>

**Theorem T18** (Unobserved-label equivalence). *Suppose a model is extended by a label $s$ that does not enter the transition law, inputs or observation law. Two such extensions with the same initial dynamical state and different labels produce identical observable histories, or identical observable distributions if shared transition randomness is used.*

*Proof.* The initial observable state is the same. Because the transition and observation maps ignore the label, equal states under the same input and realized random value produce equal next states and outputs. Induction proves pathwise equality under coupling, and therefore equality of observable distributions. ◻

The theorem does not prove that a spiritual interpretation is false or that an immaterial aspect is impossible. It shows that a label disconnected from the measurement model is not tested by these outputs. A consciousness identity claim would need an additional bridge assumption or discriminating empirical prediction; no such bridge is smuggled in as a theorem.

# Executed verification and its limits

## Three levels of evidence

The *written mathematical layer* contains eighteen theorems with assumptions and proofs. Its infinite word inductions, differential statements and analytic convergence arguments are not fully encoded in a proof assistant.

The *solver layer* contains twenty standalone SMT-LIB counterexample queries. Each negates a specified Boolean, integer or real-arithmetic identity or implication. The installed Z3 4.13.3.0 returned `unsat` for all twenty and emitted a proof log for each. The formal files, results and logs are included. These are solver-checked obligations, not an independently replayed small-kernel proof of the entire Python implementation. The Z3 solver, its arithmetic theories and the translation are part of the trust boundary. \[R3; R6\]

The *execution layer* contains 55 passing regression tests, synthetic demonstrations and saved numerical data. Tests cover replay, pair rules, growth counts, reflection, arc evaluation, the invalid fold, clipping, Lipschitz samples, chart seams, LUT bounds, bracket handling, parity failure modes, Hadamard identities, stereo/ITD geometry, field feedback, contraction and BVH/exhaustive agreement. Passing tests are not a universal proof of floating-point behavior.

No human, animal or cell data were analyzed. No neural, genetic, spiritual or clinical mechanism was validated. No hardware latency or perceptual safety was measured. No claim is made that all Python functions satisfy a machine-checked refinement proof against the manuscript. Real-arithmetic SMT checks do not include IEEE rounding, trigonometric implementations, random-number quality or every program path.

## Recorded numerical outcomes

| Check or demonstration                              |       Recorded result |
|:----------------------------------------------------|----------------------:|
| Python regression tests                             |             55 passed |
| SMT-LIB obligations / proof logs                    |        20 / 20 passed |
| Generation-four draw operations / word tokens       |             162 / 406 |
| Closed-loop contraction bound $q$                   |               0.94464 |
| Step-180 state separation                           | $1.7951\times10^{-7}$ |
| Step-180 theoretical separation envelope            | $3.1782\times10^{-5}$ |
| LUT maximum error, 1,000 sampled queries            |             0.0266515 |
| LUT certificate violations, those queries           |                     0 |
| BVH maximum difference from exhaustive, 100 queries |                     0 |
| Median BVH primitive evaluations, those queries     |             10 of 162 |
| Largest threshold-coding mean error, 11 inputs      |               0.00444 |

The LUT is a $64\times128$ log-polar grid on radii $0.05$ to $4.0$ in simulation units. Its largest returned corner certificate on the query set was $0.298394$; this deliberately conservative bound need not be tight. The query sets, seeds and results are available, so the absence of observed violations is not confused with an exhaustive floating-point guarantee.

Bisection of the toy equation $t^2-2=0$ on $[1,2]$ returned $1.4142135623260401$ after 33 halvings, with retained interval $[1.4142135622678325,1.4142135623842478]$. It demonstrates a numerical event certificate; the variable is not assigned to a measured physiological event.

## The verification map

| Theorem | Mathematical target                    | Additional verification                                 |
|:--------|:---------------------------------------|:--------------------------------------------------------|
| T1      | Pair exchange and canonical invariance | K01–K03; pair tests                                     |
| T2      | Complete-seed replay                   | Same-environment replay tests; written induction        |
| T3      | Growth sum, imbalance, token count     | K04–K05; counts through generation six                  |
| T4      | Grammar/interpreter reflection         | Rewrite and numeric geometry tests; written induction   |
| T5      | CSG membership and ground clipping     | K06–K08; boundary tests                                 |
| T6      | Lipschitz closure, conservative steps  | K09 fragment; sampled field inequality                  |
| T7      | Conditional fold equality              | K10 fragment; valid regime and counterexample           |
| T8      | Reflection versus occupancy            | K11 fragment; mirrored occupancy tests                  |
| T9      | Chart metric and LUT error bound       | Roundtrip, seam and certificate tests; written calculus |
| T10     | Rigid transport and path derivative    | Written chain-rule proof; no full solver encoding       |
| T11     | Bracket localization                   | K17 fragment; root and invalid-bracket tests            |
| T12     | XOR, sets and parity                   | K12–K15; all 256 eight-bit payloads tested              |
| T13     | Finite sign loss                       | K16 fragment; written finite-sampling example           |
| T14     | Threshold statistics and flip bias     | Seeded empirical mean and endpoint tests                |
| T15     | Hadamard orthogonality                 | K18 fragment; numeric norm and involution tests         |
| T16     | Bounded filtered memory                | K19 fragment; numerical state invariance                |
| T17     | Closed-loop contraction                | K20 fragment; observed separation against bound         |
| T18     | Unobserved-label equivalence           | Written induction; no consciousness validation          |

# A testable research program

## From equations to discriminating observations

**\[H\]**  An empirical account needs a task, observations, parameter-fitting rules, controls and a failure criterion fixed before seeing confirmatory results. The cited adversarial-collaboration protocol is an external example of deriving contrasting predictions and preregistering tests; it did not test Ilse AI Engine and is not evidence in its favor. \[R4\]

The hypotheses below are proposed studies, not experiments already performed. Human studies would require an independently reviewed protocol, informed participation, data protection and appropriate sensory-safety oversight. The archive contains static explanatory plots and numerical data, not a participant stimulation protocol.

### H1: Boundary metric information

Under matched memory and query budgets, compare a boundary-distance representation, a sampled occupancy representation and a non-field baseline on independently generated spatial prediction tasks. Fix the training/test split and score future boundary-crossing or contact predictions. A repeatable absence of benefit over matched alternatives weakens a claimed explanatory advantage of the metric representation. Good synthetic performance alone would not establish consciousness.

### H2: Recurrence and slow state

Compare a recurrent-plus-memory model against a parameter-matched feedforward model and a recurrent model without slow state on delayed or partially occluded observations. Predict held-out behavioral response histories, not only the model’s own next state. A failure to improve out-of-sample prediction weakens the proposed role of these particular state mechanisms. Flexible extra parameters must not be mistaken for explanatory success.

### H3: Separate body calibration

In a professionally reviewed multisensory setting, estimate eye geometry and auditory geometry separately rather than converting one into the other. Compare predictions from independently calibrated modality maps against a forced shared-parameter map. The relevant outcome is a declared localization or temporal-judgment measure. This tests a measurement-model choice, not a claim that the two senses are physically identical or that the engine eliminates discomfort.

### H4: Memory-mediated field feedback

Compare the proposed geometry-feedback model ($\mu\ne0$) with a model that has the same recurrent capacity but no geometry feedback ($\mu=0$). The predicted advantage must concern an independently specified behavioral or sensory-adaptation history. If a generic hidden-state model explains the same data equally well, the special claim that memory must be represented geometrically is not supported.

### H5: First-person and spiritual interpretation

Use voluntary first-person descriptions and predeclared coding categories to study reported unity, meaning or connectedness. Preserve participants’ own distinctions and evaluate coding reliability. Any association with model variables would be an association between reports and measurements; it would not by itself identify an immaterial entity or establish an ontological identity. No inference about a person’s spiritual standing is permitted from seed labels or field outputs.

## Minimum conditions for a stronger theory claim

A stronger claim would require reproducible data beyond the synthetic kernel, independently fitted and validated observation maps, competitive model comparisons, and a precise account of what would count against the proposal. It would also need a bridge from a computed state to a claimed feature of experience that is not merely stipulated after the result. None of those requirements is supplied by multiplying theorem counts or by calling a rendering field a wave function.

**Current conclusion.** Ilse AI Engine is a defined seed-based research architecture with a proved mathematical component family and a reproducible implementation. Its proposed consciousness interpretation is explicit and investigable. The source’s geometry can be made rigorous without treating its unsupported cosmic or clinical extrapolations as discoveries.

# Source-to-formalization audit

This audit preserves the source’s terminology and records where this edition adds conditions, changes a convention, or leaves a claim unsupported. The supplied addendum is included as `sources/double_arc_addendum.pdf`; it contains unverified AI-generated assertions and is not an evidential endorsement. The complete audit is also supplied as CSV.

| ID  | Source item                            | Formal disposition                                                                                                                                       |
|:----|:---------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------|
| A01 | Arc routine; p. 1                      | Retained as exact centerline distance on the stated angular domain; stroke thickening is separately defined.                                             |
| A02 | Absolute-value duplication; p. 1       | Conditional fold theorem added. The source omits the lateral-containment condition; explicit union is used in code.                                      |
| A03 | $\sigma(A)$ set notation; p. 2         | Query-coordinate folding is represented by a preimage; the source’s forward-image notation is not silently reused.                                       |
| A04 | Baseline segment; pp. 2–3              | Retained as a bounded segment with a nondegenerate projection routine and a degenerate-point fallback.                                                   |
| A05 | “Exact” combined SDF; pp. 2–3          | Exact membership and a Lipschitz bound are proved. Global signed-distance exactness is not asserted; a disk-union counterexample is supplied.            |
| A06 | Domes, cones, pyramids, spheres; p. 4  | Preserved as possible primitive interfaces. No theorem equates these shapes or treats them as a complete bodily model.                                   |
| A07 | Log-polar infinite resolution; p. 4    | Finite annulus, finite table, reference length and interpolation error are added. The infinity claim is not adopted.                                     |
| A08 | Non-Euclidean chart; p. 4              | Euclidean geometry written in log-polar coordinates retains its pullback metric. A chart change alone is not a topology change.                          |
| A09 | Klein wrapper; p. 4                    | Optional quotient and seam compatibility are specified. The wrapper is not implemented or presumed to be an ordinary solid SDF.                          |
| A10 | Kinematic exact prediction; p. 4       | Translation/rotation and a chain-rule event equation are retained; unspecified future motion is not predicted.                                           |
| A11 | BST instant skipping; p. 5             | A median-split spatial BVH with actual bounds is implemented. No guarantee follows from an arbitrary binary search tree.                                 |
| A12 | IDT density/gradient; p. 5             | No complete definition is supplied. IDT is left as an unresolved, unimplemented interface; no density theorem depends on it.                             |
| A13 | IPD eye offsets; p. 5                  | Retained with an explicit length, origin and pose. IPD is not ITD and is not interaural phase here.                                                      |
| A14 | Stereo overlap/foveation; pp. 4–5      | Gaze and sampling policy would be additional inputs. Eye spacing alone does not supply them.                                                             |
| A15 | Discarding all floats; pp. 5–6         | The output can be one bit while the computation retains real-valued fields and state. The source’s stronger architectural claim is not implemented.      |
| A16 | Step/sign polarity; pp. 5–6            | The formulas differ in polarity. This edition chooses closed inside $\varphi\leq0$ and tests it.                                                         |
| A17 | Blue-noise jitter; pp. 5–6             | A specified pseudorandom threshold quantizer is implemented. Blue-noise spectral properties and universal perceptual benefit are not claimed.            |
| A18 | Self-correcting wave function; p. 6    | Preserved as source language, not a quantum or physical field equation. No wave-function ontology is inferred.                                           |
| A19 | T grounding and cuts; pp. 7–8          | Half-space intersection is formalized. Ground operation, orientation marker and event time are separate types.                                           |
| A20 | Hinge at $(0,R)$; p. 8                 | Circle intersection is derived from the stated centers. For the default tangent circles it is $(0,0)$.                                                   |
| A21 | Cosmic winding/CP/wormhole; pp. 8–9    | No relevant physical state, law or observation is supplied. These assertions do not enter any theorem.                                                   |
| A22 | Bit jitter as quantum collapse; p. 9   | Threshold randomness is a classical statistical construction. No quantum-measurement identification is established.                                      |
| A23 | Deterministic migraine cascade; p. 10  | The proposed shape-to-clinical causal chain is not established by the source. No diagnosis, causal guarantee or safety claim is carried into the kernel. |
| A24 | Vestibular diagram; p. 11              | Inconsistent diagram labels are noted. The sketch is not used as anatomical authority or evidence that the engine affects the balance organs.            |
| A25 | VOR/poisoning/glitch account; p. 12    | The specific reverse-reflex and inevitable nausea story is not demonstrated. The engine has no physiological reflex model.                               |
| A26 | $XX/XY$ pairings; current request      | Symbolic pair algebra and a stipulated mixing law are added. No genetic classification or hierarchy of consciousness follows.                            |
| A27 | L-system growth; earlier scope         | An explicit grammar, interpreter and budgets are added here; the addendum contains no such productions.                                                  |
| A28 | Hadamard/XOR analogy; earlier scope    | A real orthogonal transform is distinguished from modulo-two reduction. Their limited algebraic connection is made explicit.                             |
| A29 | Permanent etched memory; earlier scope | A bounded mutable memory coordinate and its feedback law replace an unqualified permanence claim. Biological identity remains untested.                  |
| A30 | Spiritual perspective; earlier scope   | Retained as first-person interpretation and research questions. Observable-label equivalence states its present measurement limit.                       |

# Kernel contract and reproduction

## Implemented interfaces

| Interface                            | Contract                                                                                                              |
|:-------------------------------------|:----------------------------------------------------------------------------------------------------------------------|
| `Pair`, `mix_pairs`                  | Validated symbolic pairs; ordered and canonical forms; exact rational mixing probabilities.                           |
| `grow`, `turtle`                     | Parallel grammar with a finite symbol budget; balanced brackets; numerical stroke coordinates.                        |
| `distance_arc`                       | Unsigned exact arc-centerline distance in the declared aperture domain.                                               |
| `paired_arcs`, `m_field`             | Explicit arc union, optional baseline and cut; sign-correct field. Folded mode is exposed only for comparison.        |
| `capsule_field`, `CapsuleBVH`        | Exhaustive field or median-split spatial hierarchy; same capsule semantics and radius.                                |
| `LogPolarLUT`                        | Annular bilinear lookup with an angular seam and a conservative error certificate for a 1-Lipschitz source field.     |
| `bisect_root`                        | Requires a bracket, finite evaluations and tolerance; returns a root estimate, retained interval and iteration count. |
| `stereo_eyes`, `itd_seconds`         | Separate length and propagation-time toy interfaces. No physiological calibration is inferred.                        |
| `parity`, `bernoulli_encode`, `fwht` | Validated bits, probability-domain encoding and a normalized real Hadamard transform.                                 |
| `IlseKernel`                         | Seeded three-fast/three-slow state model with memory-dependent geometry and a computable contraction bound.           |

The core raises explicit errors for invalid pairs, unsupported symbols, unbalanced brackets, nonfinite inputs, invalid chart domains, growth-budget exhaustion and invalid root brackets. Not every possible misuse has a formal refinement proof. Parameters and complete input conventions must remain visible when extending the code.

## Reproduce from the archive root

    python verify_package.py
    python -m pip install -r requirements.txt
    python -m unittest discover -s tests -v
    python -m kernel.demo
    python formal/check.py
    bash manuscript/build.sh

The solver step requires a separately installed Z3 executable or shared library. The adapter supports the official C API through `ctypes` when the executable is absent. Set `Z3_LIBRARY` to an explicit shared-library path if needed. No solver or font binary is redistributed.

The recorded environment is Python 3.13.5, NumPy 2.3.5, Matplotlib 3.10.8 and Z3 4.13.3.0 on Linux. The dependency file records the tested plotting/numerical versions. A standard LaTeX distribution with the listed packages is required to rebuild the PDF. Editable LaTeX and a Markdown conversion are supplied; LaTeX is the typesetting source of record.

The package manifest hashes the delivered files. Verification should be run before regenerating outputs: rebuilding images or changing the environment can legitimately change bytes and invalidate delivery checksums. Numeric replay is stated within a declared environment, not as a promise that independently rebuilt PDFs have identical metadata or timestamps.

## Extensions not yet implemented

The optional Klein quotient, a physiological transduction model, reaction–diffusion development, learned human-report readouts, a body action controller and physical optical hardware remain specifications or proposals. IDT remains undefined. No automatic substitute is supplied for any of these missing components. A later extension should state new assumptions, update its claim audit, and add discriminating tests instead of inheriting verification claims from an unrelated component.

# Sources and reference scope

Working research manuscript supplied in the conversation. Consulted for the continuing seed, L-system, bodily, digital, memory and spiritual scope. Not redistributed in this package. It is a framework source, not experimental evidence.

*Double-arc M with UU double-set SDF notation (signed-distance-field)*. Twelve-page exported AI conversation, supplied for this edition. Included as `sources/double_arc_addendum.pdf`. Page-specific mathematical and evidential dispositions are listed in Appendix A.

[*The Algorithmic Beauty of Plants*, Chapter 1: Graphical modeling using L-systems](https://algorithmicbotany.org/papers/abop/abop-ch1.pdf). Springer. Used for parallel rewriting and turtle interpretation; not evidence that the chosen grammar describes human development or consciousness.

[Sphere tracing: A geometric method for the antialiased ray tracing of implicit surfaces](https://graphics.stanford.edu/courses/cs348b-20-spring-content/uploads/hart.pdf). *The Visual Computer* 12, 527–545. DOI: 10.1007/s003710050084. The linked author manuscript is an earlier version. Used for geometric distance, distance bounds and conservative stepping; it does not validate a consciousness ontology.

[*Programming Z3*](https://z3prover.github.io/papers/programmingz3.html). Authors’ tutorial. Used for the solver-verification method and its logic/arithmetic scope; not an independent audit of this package.

[An adversarial collaboration protocol for testing contrasting predictions of global neuronal workspace and integrated information theory](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0268577). *PLOS ONE* 18(2), e0268577. DOI: 10.1371/journal.pone.0268577. Used only as a methodological example of contrasting predictions and preregistration. It did not test Ilse AI Engine.

[All-optical machine learning using diffractive deep neural networks](https://arxiv.org/abs/1804.08711). arXiv:1804.08711. Used as a bounded example of experimentally demonstrated optical mappings, not as a universal passive-kernel or zero-latency guarantee.

[*Z3 C API documentation*](https://z3prover.github.io/api/html/group__capi.html). Used for the library adapter and its official SMT-LIB evaluation entry point. Documentation accessed 11 September 2026; executed library version recorded separately.

**End of manuscript.** The accompanying source, proof obligations, tests and numerical files are part of the research record. A proved component relationship is not an empirical finding about a person, a brain or spiritual reality.
