"""The two actual source polynomial variants, with dimensionally valid times."""
from dataclasses import dataclass
import math
from .core import finite_scalar

PHI_MINUS=(math.sqrt(5)-1)/2


def toy_field(rho,theta,kappa=1.0):
    rho=finite_scalar(rho,'rho');theta=finite_scalar(theta,'theta')
    if kappa not in (.5,1.0): raise ValueError('kappa must select the half-angle or full-angle source variant')
    return (rho*rho-math.cos(theta/2)**2)*(rho*rho*math.sin(kappa*theta)**2-PHI_MINUS**2)

@dataclass(frozen=True)
class EventRoot:
    branch: str
    rho: float
    log_delay: float
    time: float | None
    status: str


def event_roots(theta,kappa=1.0,r0=1.0,speed=1.0,t0=0.0,singular_tolerance=1e-12):
    theta=finite_scalar(theta,'theta');r0=finite_scalar(r0,'r0')
    speed=finite_scalar(speed,'speed');t0=finite_scalar(t0,'t0')
    if r0<=0 or speed<=0 or kappa not in (.5,1.0): raise ValueError('Invalid root parameters')
    tol=finite_scalar(singular_tolerance,'singular_tolerance')
    if tol<=0: raise ValueError('Positive singular tolerance required')
    roots=[]
    def add(label,rho):
        ld=math.log(r0)-math.log(speed)+rho
        try:
            delay=math.exp(ld);t=t0+delay
            ok=delay>0 and math.isfinite(t) and t>t0
        except OverflowError: t=None;ok=False
        roots.append(EventRoot(label,rho,ld,t if ok else None,'finite' if ok else 'log-time-only'))
    a=math.cos(theta/2)
    add('inner-minus',-a);add('inner-plus',a)
    b=math.sin(kappa*theta)
    status='regular'
    if b==0.0: status='outer-absent-at-exact-zero'
    elif abs(b)<=tol: status='outer-near-singular-unresolved'
    else:
        add('outer-minus',-PHI_MINUS/b);add('outer-plus',PHI_MINUS/b)
    return roots,status
