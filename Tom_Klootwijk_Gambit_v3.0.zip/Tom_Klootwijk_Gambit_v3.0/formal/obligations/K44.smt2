; K44: Three pairwise distinct states cannot be encoded injectively in one bit
; Manuscript: L16. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Bool)
(declare-const b Bool)
(declare-const c Bool)
(assert (not (not (and (distinct a b) (distinct a c) (distinct b c)))))
(check-sat)
(get-proof)
