; K28: Fixed-point accumulator preserves residual interval
; Manuscript: L9. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const D Int)
(declare-const r Int)
(declare-const k Int)
(define-fun q () Int (ite (>= (+ r k) D) 1 0))
(define-fun rn () Int (- (+ r k) (* D q)))
(assert (not (=> (and (> D 0) (<= 0 r) (< r D) (<= 0 k) (<= k D)) (and (<= 0 rn) (< rn D) (or (= q 0) (= q 1))))))
(check-sat)
(get-proof)
