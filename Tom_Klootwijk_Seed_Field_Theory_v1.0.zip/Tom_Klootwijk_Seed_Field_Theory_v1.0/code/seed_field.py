"""Seed-Field Framework: small, offline mathematical reference components.

Conceptual synthesis: Tom Klootwijk. Formalization/code: AI-assisted draft, 2026.
These routines do not implement, measure, or establish consciousness.
No sound playback, hardware control, physiological stimulation, or networking.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Mapping
import math
import numpy as np

@dataclass(frozen=True)
class GrowthConfig:
    seed: int = 42
    generations: int = 3
    axiom: str = "F"
    rule: str = "F[+F]F[-F]F"
    step: float = 0.12
    radius: float = 0.035
    angle_deg: float = 25.0
    jitter_deg: float = 1.5
    branch_scale: float = 0.78

    def validate(self) -> None:
        if not isinstance(self.seed, int) or self.seed < 0:
            raise ValueError("seed must be a nonnegative integer")
        if not isinstance(self.generations, int) or not 0 <= self.generations <= 5:
            raise ValueError("generations must be an integer between 0 and 5")
        for value in (self.step, self.radius, self.angle_deg, self.jitter_deg, self.branch_scale):
            if not math.isfinite(value):
                raise ValueError("growth parameters must be finite")
        if self.step <= 0 or self.radius <= 0 or not 0 < self.branch_scale <= 1:
            raise ValueError("positive step/radius and branch_scale in (0,1] required")
        if self.jitter_deg < 0:
            raise ValueError("jitter_deg must be nonnegative")
        if not set(self.axiom + self.rule) <= set("F+-[]"):
            raise ValueError("unsupported turtle symbol")

def expand_lsystem(axiom: str, rules: Mapping[str, str], generations: int,
                   max_symbols: int = 200_000) -> str:
    """Parallel rewriting; unspecified symbols use identity productions."""
    if not isinstance(generations, int) or generations < 0:
        raise ValueError("generations must be a nonnegative integer")
    if not axiom or max_symbols < len(axiom):
        raise ValueError("nonempty bounded axiom required")
    word = axiom
    for _ in range(generations):
        size = sum(len(rules.get(symbol, symbol)) for symbol in word)
        if size > max_symbols:
            raise ValueError("expansion exceeds max_symbols")
        word = "".join(rules.get(symbol, symbol) for symbol in word)
    return word

def grow(config: GrowthConfig) -> tuple[str, np.ndarray]:
    """2-D turtle: rows are x0,y0,x1,y1,radius in arbitrary simulation units.

    The grammar is deterministic. The numerical seed controls only the explicitly
    specified Gaussian angular perturbation in its geometric interpretation.
    """
    config.validate()
    word = expand_lsystem(config.axiom, {"F": config.rule}, config.generations)
    rng = np.random.default_rng(config.seed)
    position, angle, depth = np.zeros(2), math.pi / 2, 0
    stack: list[tuple[np.ndarray, float, int]] = []
    segments = []
    for token in word:
        if token == "F":
            scale = config.branch_scale ** depth
            new = position + config.step * scale * np.array([math.cos(angle), math.sin(angle)])
            segments.append([*position, *new, config.radius * scale])
            position = new
        elif token in "+-":
            turn = config.angle_deg + rng.normal(0, config.jitter_deg)
            angle += math.radians(turn) * (1 if token == "+" else -1)
        elif token == "[":
            stack.append((position.copy(), angle, depth))
            depth += 1
        elif token == "]":
            if not stack:
                raise ValueError("unbalanced closing bracket")
            position, angle, depth = stack.pop()
    if stack:
        raise ValueError("unbalanced opening bracket")
    return word, np.asarray(segments, dtype=float).reshape(-1, 5)

def sphere_sdf(points: np.ndarray, center: np.ndarray, radius: float) -> np.ndarray:
    """Exact Euclidean signed distance to a circle or sphere (negative inside)."""
    points, center = np.asarray(points, float), np.asarray(center, float)
    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be finite and positive")
    if center.ndim != 1 or points.shape[-1] != center.shape[0]:
        raise ValueError("coordinate dimensions must agree")
    if not np.all(np.isfinite(points)) or not np.all(np.isfinite(center)):
        raise ValueError("coordinates must be finite")
    return np.linalg.norm(points - center, axis=-1) - radius

def capsule_sdf(points: np.ndarray, a: np.ndarray, b: np.ndarray,
                radius: float) -> np.ndarray:
    """Exact SDF of one capsule, including a degenerate zero-length segment."""
    points, a, b = np.asarray(points, float), np.asarray(a, float), np.asarray(b, float)
    if a.ndim != 1 or b.shape != a.shape or points.shape[-1] != a.size:
        raise ValueError("coordinate dimensions must agree")
    if not math.isfinite(radius) or radius <= 0 or not all(np.all(np.isfinite(v)) for v in (points,a,b)):
        raise ValueError("positive finite radius and finite coordinates required")
    ab = b - a
    length2 = float(ab @ ab)
    if length2 == 0:
        return sphere_sdf(points, a, radius)
    h = np.clip(((points - a) @ ab) / length2, 0, 1)
    return np.linalg.norm(points - a - h[..., None] * ab, axis=-1) - radius

def union_capsule_field(points: np.ndarray, segments: np.ndarray) -> np.ndarray:
    """CSG minimum: correct union sign; NOT generally exact distance inside union."""
    points, segments = np.asarray(points, float), np.asarray(segments, float)
    if segments.ndim != 2 or segments.shape[1] != 5 or len(segments) == 0:
        raise ValueError("nonempty 2-D segments with shape (N,5) required")
    values = np.full(points.shape[:-1], np.inf)
    for x0, y0, x1, y1, radius in segments:
        values = np.minimum(values, capsule_sdf(points, np.array([x0,y0]), np.array([x1,y1]), radius))
    return values

def normalize_distance(distance: np.ndarray, band: float) -> np.ndarray:
    if not math.isfinite(band) or band <= 0:
        raise ValueError("band must be finite and positive")
    distance = np.asarray(distance, float)
    if not np.all(np.isfinite(distance)):
        raise ValueError("distance must be finite")
    return np.clip(0.5 + distance / (2 * band), 0, 1)

def _unit_input(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, float)
    if not np.all(np.isfinite(values)) or np.any((values < 0) | (values > 1)):
        raise ValueError("finite values in [0,1] required")
    return values

def quantize8(values: np.ndarray) -> np.ndarray:
    return np.rint(255 * _unit_input(values)).astype(np.uint8)

def pulse_density(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """First-order accumulator PDM for numerical illustration, not an audio driver.

    In exact arithmetic, each prefix satisfies abs(sum(q-u)) < 1.
    """
    values = _unit_input(values)
    if values.ndim != 1:
        raise ValueError("one-dimensional sequence required")
    bits = np.zeros(len(values), dtype=np.uint8)
    residues = np.zeros(len(values))
    accumulator = 0.0
    for i, value in enumerate(values):
        accumulator += float(value)
        if accumulator >= 1.0:
            bits[i] = 1
            accumulator -= 1.0
        residues[i] = accumulator
    return bits, residues

def even_parity(bits: np.ndarray) -> int:
    bits = np.asarray(bits)
    if bits.ndim != 1 or np.any((bits != 0) & (bits != 1)):
        raise ValueError("one-dimensional binary sequence required")
    return int(np.count_nonzero(bits) % 2)

def walsh_hadamard(size: int) -> np.ndarray:
    """Normalized Sylvester matrix, in Sylvester (not sequency) ordering."""
    if not isinstance(size, int) or size <= 0 or size & (size - 1):
        raise ValueError("size must be a positive power of two")
    h = np.ones((1,1))
    while len(h) < size:
        h = np.block([[h,h],[h,-h]])
    return h / math.sqrt(size)

def learn_memory(patterns: np.ndarray) -> np.ndarray:
    """Toy outer-product associative memory; not a model of molecular storage."""
    patterns = np.asarray(patterns, float)
    if patterns.ndim != 2 or patterns.shape[1] == 0 or np.any(np.abs(patterns) != 1):
        raise ValueError("nonempty matrix of bipolar patterns required")
    weights = patterns.T @ patterns / patterns.shape[1]
    np.fill_diagonal(weights, 0)
    return weights

def recall(weights: np.ndarray, cue: np.ndarray, sweeps: int = 12) -> tuple[np.ndarray, np.ndarray]:
    weights, state = np.asarray(weights, float), np.asarray(cue, float).copy()
    if state.ndim != 1 or weights.shape != (len(state),len(state)):
        raise ValueError("weights and cue must have compatible dimensions")
    if np.any(np.abs(state) != 1) or not np.allclose(weights, weights.T) or not np.allclose(np.diag(weights), 0):
        raise ValueError("bipolar cue, symmetric weights and zero diagonal required")
    if not np.all(np.isfinite(weights)) or not isinstance(sweeps, int) or sweeps < 1:
        raise ValueError("finite weights and positive integer sweeps required")
    energy = [-0.5 * float(state @ weights @ state)]
    for _ in range(sweeps):
        previous = state.copy()
        for i in range(len(state)):
            local = float(weights[i] @ state)
            if local > 0:
                state[i] = 1
            elif local < 0:
                state[i] = -1
            energy.append(-0.5 * float(state @ weights @ state))
        if np.array_equal(previous, state):
            break
    return state, np.array(energy)

def bisect_root(function: Callable[[float], float], left: float, right: float,
                tolerance: float = 1e-10, max_steps: int = 200) -> float:
    """Find a bracketed root of a continuous scalar function.

    This does not discover brackets, detect all tangencies, or certify earliest roots.
    """
    if not all(math.isfinite(v) for v in (left,right,tolerance)) or not left < right or tolerance <= 0:
        raise ValueError("finite ordered bracket and positive tolerance required")
    fl, fr = function(left), function(right)
    if not math.isfinite(fl) or not math.isfinite(fr):
        raise ValueError("nonfinite endpoint value")
    if fl == 0: return left
    if fr == 0: return right
    if fl * fr > 0: raise ValueError("root is not bracketed")
    for _ in range(max_steps):
        middle = (left + right) / 2
        fm = function(middle)
        if not math.isfinite(fm): raise ValueError("nonfinite function value")
        if fm == 0 or right - left <= tolerance: return middle
        if fl * fm <= 0: right = middle
        else: left, fl = middle, fm
    raise RuntimeError("bisection failed to converge")

def interaural_time_difference(source: np.ndarray, ear_left: np.ndarray,
                               ear_right: np.ndarray, sound_speed: float) -> float:
    """Point-receiver, homogeneous-medium model: positive means left arrives later."""
    vectors = [np.asarray(v, float) for v in (source,ear_left,ear_right)]
    if any(v.shape != (3,) or not np.all(np.isfinite(v)) for v in vectors):
        raise ValueError("three finite 3-D positions required")
    if not math.isfinite(sound_speed) or sound_speed <= 0:
        raise ValueError("sound_speed must be finite and positive")
    source, left, right = vectors
    return float((np.linalg.norm(source-left)-np.linalg.norm(source-right))/sound_speed)
