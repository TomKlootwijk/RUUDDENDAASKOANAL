; K22: Two-node diffusion quadratic form is nonpositive
; Manuscript: L5. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const w Real)
(declare-const x Real)
(declare-const y Real)
(assert (not (=> (>= w 0) (and (= (+ (* x w (- y x)) (* y w (- x y))) (- (* w (- x y) (- x y)))) (<= (+ (* x w (- y x)) (* y w (- x y))) 0)))))
(check-sat)
(get-proof)
