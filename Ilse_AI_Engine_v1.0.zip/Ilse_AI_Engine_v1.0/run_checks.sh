#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python verify_package.py
python -m unittest discover -s tests -v
python formal/check.py
# The formal checker regenerates proof logs. Check delivery hashes before this step.
