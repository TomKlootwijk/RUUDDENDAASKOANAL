::: titlepage
**PROPOSED THEORY / MATHEMATICAL FORMALIZATION / VERSION 1.0**

**Tom Klootwijk's\
Seed--Field Theory\
of Consciousness\
and the Senses**

Embodied, digital and spiritual perspectives\
with explicit growth instructions and testable claims

**Tom Klootwijk**

Conceptual synthesis attributed to the requester;\
AI-assisted formalization prepared for author review.

::: keybox
The central proposal A seed and its growth rules generate an evolving structure. That structure constrains sensing, action and learning. The proposed theory investigates whether recurrent, embodied modelling of these boundaries helps explain the organization of conscious experience. Mathematical representation, physical mechanism and spiritual interpretation remain distinct levels of description.
:::

11 September 2026 | PRIVATE ATTRIBUTION EDITION

Author-supplied reference: NL200678942. Author-supplied date: 10-07-1990, interpreted as 10 July 1990. These particulars are reproduced for attribution only and have not been verified. This edition contains personal information.
:::

# Abstract {#abstract .unnumbered}

This manuscript formalizes Tom Klootwijk's proposed synthesis of signed distance fields, geometric boundaries, recursive growth, sensory coordinate systems, event timing, binary operators, memory and conscious experience. The uploaded conversation supplies the conceptual sequence; the current request adds a seed-based account, explicit L-system growth instructions and a spiritual dimension. The resulting working name, the *Klootwijk Seed--Field Framework* (KSFF), is introduced for this draft, not as an established scientific designation.

The framework treats a seed as a reproducible initial specification, growth as a rule-governed process, geometry as a family of signed or unsigned fields, sensation as modality-specific measurement, and memory as persistent changes in state or transition parameters. A recurrent dynamical model couples these components without identifying a distance value with a voltage, a probability amplitude, a feeling or a spiritual entity. Consciousness is the explanatory target: the manuscript specifies candidate mechanisms and observable consequences rather than declaring that a geometric encoding proves subjective experience.

The exact mathematical core includes metric signed distances, normalized boundary values, coordinate transformations, L-system rewriting, event-root equations, modulo-two parity, Walsh--Hadamard transforms and finite-delay physical computation. The biological and phenomenological links are stated as hypotheses with proposed comparisons and failure criteria. Several earlier AI-generated claims in the uploaded material---instantaneous photonics, parity as encryption, arbitrary fields as exact SDFs, and consciousness as an established one-bit process---are explicitly distinguished from what the mathematics supports.

A runnable companion package implements seeded branching geometry, primitive distance queries, first-order pulse-density encoding, parity, a bracketed crossing-time solver and a small associative-memory example. All included results are synthetic demonstrations. They are not measurements of human consciousness, clinical findings, proof of a spiritual ontology, or hardware-performance benchmarks.

::: keybox
How to read the evidence labels **M:** mathematical definition or deduction under stated assumptions. **E:** a narrowly cited empirical or engineering result. **H:** a proposed, testable modelling hypothesis. **P:** philosophical or first-person interpretation. **U:** an unsupported or overstated assertion retained only in the provenance record.
:::

## Attribution, scope and editorial responsibility {#attribution-scope-and-editorial-responsibility .unnumbered}

The organizing ideas are attributed to Tom Klootwijk as requested. The supplied file contains both the requester's prompts and earlier AI-generated responses; it must not be treated as a scientific publication or as evidence that every assertion is the author's considered position. This document is an AI-assisted proposed formalization for the author's review. Definitions, counterexamples, the state-space model, the spiritual interpretation and the experiment designs added here are *editorial proposals*, not quotations from the source. Established mathematical methods remain credited to their existing literature. No claim of priority, patentability, identity verification or scientific validation is made.

The source begins with directional acoustic equipment. That origin is acknowledged historically, but the new formalization supplies no acoustic-weapon design, no high-power signal-generation instructions and no procedure for manipulating people. Its executable examples are offline numerical and graphical demonstrations.

# The proposal in the author's conceptual order

## What is being formalized

[\[Source-derived framing\]]{.sans-serif} The supplied conversation moves from directed acoustic geometry to normalized SDF values, log-polar lookup tables, tree queries, bit operations and parity. It then extends toward photonics, sensory anatomy, time, a self-referential field interpretation, cells, molecular states, consciousness and memory. The user explicitly corrects IPD to mean *interpupillary distance*, not interaural phase difference. The final request adds *L-systems* as growth instructions and asks for bodily, digital and spiritual scope. These connections form the organizing structure of this manuscript.[@source]

The valuable unifying question is not whether all these objects are literally the same kind of thing. It is whether one carefully typed architecture can describe their relationships: how a generative specification produces a body or a model, how boundaries constrain interaction, how sensory measurements are aligned in space and time, how learning alters future dynamics, and how a persisting self-representation participates in experience.

::: keybox
Proposed thesis, not an established identification **Conscious experience is hypothesized to depend, in part, on the recurrent activity of an embodied system that distinguishes itself from its surroundings, integrates differently timed sensory evidence, preserves experience-dependent changes, and represents its own participation in the resulting world-model.** Seeded growth and boundary fields provide a candidate formal language for studying this organization; they do not, on their own, establish consciousness.
:::

This is an integrative research programme. Its closest executable contribution is a modular seed-to-field-to-observation architecture, with a learning loop. Its stronger consciousness claim requires evidence beyond successful rendering, compression, classification or memory retrieval.

## Three domains and their common vocabulary

The **bodily domain** concerns physical organization, internal regulation, sensing, action and learning. The **digital domain** concerns representations, numerical operators, information loss, reconstruction and implementation. The **spiritual domain**, as proposed here for author review, concerns experienced unity, meaning, continuity, connectedness and value. The source does not specify a religious tradition or a testable spiritual mechanism; none is silently assigned.

The same word can operate differently in these domains. A physical boundary can be a membrane or surface. A computational boundary can separate decision regions. An experienced boundary can express felt bodily ownership or a distinction between self and world. The framework may connect these through a model, but does not use shared vocabulary as proof of shared substance.

## What "exact science" means in this draft

Exactness applies to definitions, units, assumptions, algorithms and deductive consequences. A mathematical theorem can establish a property of the proposed model. It cannot establish that a particular biological process implements the model unless measurements supply that connection. Empirical claims therefore require operational variables, independent observations and comparisons with alternatives. Spiritual interpretations remain legitimate interpretations without being presented as laboratory findings.

Throughout, a statement such as "memory changes geometry" is made precise as a choice of state variables and an update rule. It is not elevated to "all memory is permanently engraved in an SDF." Similarly, "everything can be encoded" is separated from "everything is a distance field."

# The seed: initial conditions, rules and environment

## A reproducible seed specification

[\[M; editorial definition\]]{.sans-serif} Define a seed specification as $$\Sigma=(\omega,\mathcal P,\Theta,X_0,\xi_0,\mathcal B,\mathcal V).$$ Here $\omega$ is an initial symbolic structure, $\mathcal P$ its production rules, $\Theta$ the model parameters, $X_0$ the initial numerical state, $\xi_0$ a pseudorandom-generator state where applicable, $\mathcal B$ the boundary and environmental-input specification, and $\mathcal V$ the implementation/version record. A single integer called a "seed" is only one part of this specification.

A run is then defined by $$X_{k+1}=\mathcal F_\Theta(X_k,u_k,\xi_k),\qquad
\xi_{k+1}=\mathcal G(\xi_k),\qquad X_0\text{ supplied},$$ where $u_k$ is an explicitly recorded external input. A deterministic grammar does not require random numbers. When stochastic perturbations are added, their distributions and point of application belong in the seed specification.

This resolves three different meanings in the source's "seed-based" intuition. A *generative seed* starts a symbolic or geometric construction. A *physical initial state* helps determine an evolving system together with its interactions. A *personal origin* is a biographical or spiritual interpretation. These meanings can be related, but a birth date or personal identifier is not a scientific consciousness parameter. The demonstration therefore uses the non-personal numerical seed $42$.

::: proposition
**Proposition 1** (Conditional reproducibility). *For fixed $\Sigma$, a deterministic transition rule, the same input sequence and the same numerical execution semantics, two runs have identical state sequences.*
:::

::: proof
*Proof.* Their initial states agree. If states agree at step $k$, identical transition arguments produce identical states at step $k+1$. Induction gives equality at every finite step. Cross-platform floating-point or library differences must be controlled separately. ◻
:::

## What a compact seed cannot guarantee

A compact seed can describe a large structured output because the generator supplies reusable regularity. It is not unlimited lossless compression. With a fixed deterministic generator and no additional input, an $m$-bit seed selects at most $2^m$ possible outputs. It cannot select all $2^n$ binary strings of length $n>m$. This counting argument is independent of whether the generator uses L-systems, fields, photonics or a golden-ratio parameter.

Consequently, experience-dependent memory cannot be recovered from an initial seed alone when the experiential input history is unknown. Either the seed specification must include that history, or the evolving state must store consequences of it. Calling the history "environment" does not remove its informational cost.

# L-systems: the missing growth instructions

## Parallel rewriting and explicit interpretation

[\[E/M\]]{.sans-serif} L-systems provide a formal growth language based on simultaneous symbolic rewriting. Their original motivation concerns development and neighbourhood relations; geometry is supplied by a further interpretation. The presentation by Prusinkiewicz and Lindenmayer distinguishes these roles and describes both deterministic and richer variants.[@lsystems]

For this framework, use $$\mathcal L=(V,\omega,\mathcal P,\mathcal I_\Theta),\qquad
w_0=\omega,\quad w_{n+1}=\mathcal P^{\parallel}(w_n),\quad
G_n=\mathcal I_\Theta(w_n).$$ $V$ is the alphabet, $w_n$ a word after $n$ generations, and $\mathcal I_\Theta$ a geometric interpreter. The parallel superscript means that productions act on the old word, not on new symbols created during the same generation. Unspecified symbols are copied unchanged.

A simple grammar suitable for a transparent demonstration is $$\omega=F,\qquad F\longrightarrow F[+F]F[-F]F.$$ The interpreter moves forward for $F$, rotates for $+$ or $-$, saves position and orientation for $[$, and restores them for $]$. One generation has five forward segments; after $n$ generations the word contains $5^n$ such segments. This grammar is an illustrative choice for the draft, not a proposed universal biological law.

The companion implementation shrinks step length and radius with nesting depth. A small, explicitly seeded angular perturbation is applied during interpretation, not disguised as a stochastic production rule. Thus the word is deterministic while its perturbed geometric realization depends on the numerical seed. Generation count, geometry scale and units are all recorded.

## From a growth skeleton to boundary fields

Let an interpreted segment have endpoints $a_j,b_j$ and radius $r_j>0$. Its capsule distance in Euclidean space is $$\begin{aligned}
\lambda_j(x)&=\operatorname{clip}\!\left(\frac{(x-a_j)\cdot(b_j-a_j)}{\|b_j-a_j\|^2},0,1\right),\\
d_j(x)&=\|x-a_j-\lambda_j(x)(b_j-a_j)\|-r_j.
\end{aligned}$$ For a zero-length segment, use the sphere distance instead. Define the union membership by $$F_G(x)=\min_j d_j(x),\qquad \Omega_G=\{x:F_G(x)\leq0\}.$$ Each capsule distance is exact. The minimum has the correct union sign but generally is not the exact signed distance *inside overlapping capsules*. For applications requiring a true union distance, compute distance to the resulting union boundary or perform a controlled re-distancing step. The code names this quantity a *CSG union field*, not an exact union SDF.

![Synthetic growth from the supplied grammar: three generations, 125 capsules, seed 42. The contour represents the constructed union boundary in arbitrary simulation units. It is neither a measured plant nor a biological neuron.](figures/growth.pdf){height="72mm"}

## Biological growth requires additional constraints

[\[H\]]{.sans-serif} A biological extension may attach chemical state, resource availability, cell type, orientation and time to a module. An illustrative production is $$A(\ell,r,c)\xrightarrow{\,c>c_\ast\,}
A(\alpha\ell,\beta r,c_1)\,[+A(\alpha\ell,\beta r,c_2)].$$ This is a proposed parametric rule. A biologically meaningful version must define the threshold, resource redistribution, geometry, forces, conservation laws and measured division timing. Branching an abstract string is not itself a model of chromosome segregation or cytokinesis.

If volume conservation is assumed in an idealized equal split, two spherical daughter cells would each have radius $2^{-1/3}$ times the original radius. That is a geometric consequence of the imposed assumption, not evidence that real division follows this shape model. Similarly, a cell lineage tree and a binary search tree may share a branching graph while having different meanings, update rules and physical constraints.

The missing growth instruction is therefore not just "repeat a pattern." It is *which rules operate, on which state, under which conditions, with which resources, and on which timescale*. Developmental structure and fast ongoing perception must also use separate clocks rather than one undifferentiated iteration counter.

# The geometric core: distance, fields and topology

## Signed distance with units and an inside convention

[\[M\]]{.sans-serif} Let $\Omega(t)\subset\mathbb R^3$ be a specified solid region with a nonempty boundary. Under the negative-inside convention, $$d_\Omega(x,t)=
\begin{cases}
-\inf_{y\in\partial\Omega(t)}\|x-y\|,&x\in\operatorname{int}\Omega(t),\\
0,&x\in\partial\Omega(t),\\
+\inf_{y\in\partial\Omega(t)}\|x-y\|,&x\notin\Omega(t).
\end{cases}$$ The value has units of length. Where differentiable away from singular loci, a Euclidean signed distance satisfies $\|\nabla d\|=1$. Distance-field methods have established uses in implicit surface representation and reconstruction, but numerical evaluation and reconstruction still have computational and approximation costs.[@sdf; @dist]

For a sphere of radius $R$ and centre $a$, $$d(x)=\|x-a\|-R.$$ An arbitrary polynomial or intensity field need not obey the distance definition. The expression $F(x)=\|x\|^2-R^2$ has the same spherical zero set but is not the Euclidean SDF and has squared-length units. This small example exposes why calling a quantity "SDF" is insufficient.

## Normalization is a representation, not a new physical quantity

To store a band-limited distance in $[0,1]$, choose a physical band width $\ell>0$ and define $$u(x)=\operatorname{clip}\!\left(\frac12+\frac{d(x)}{2\ell},0,1\right).$$ Here $u$ is dimensionless and the boundary is at $u=1/2$, not automatically at zero. The inverse $d=2\ell(u-1/2)$ is valid only in the unclipped band. Values outside the band have lost metric magnitude. An alternative min--max normalization is possible, but its endpoints, units and boundary value must be recorded.

The source associates SDF position with frequency and intensity.[@source] Such a relationship requires an independently defined mapping, for example a numerical parameter $\nu=h(u)$. A field of metres cannot be interpreted as hertz or pascals without a calibrated conversion. This draft supplies no conversion into a harmful acoustic output.

## Constructive solid geometry and symmetric difference

For negative-inside fields, the sign of $\min(F_A,F_B)$ represents a union; the sign of $\max(F_A,F_B)$ represents an intersection; and $\max(F_A,-F_B)$ can represent set difference. These sign constructions need not preserve exact metric distance.

For sets, the exact Boolean identity is $$A\triangle B=(A\cup B)\setminus(A\cap B),\qquad
\mathbf 1_{A\triangle B}(x)=\mathbf 1_A(x)\oplus\mathbf 1_B(x).$$ Boundary conventions must be fixed when fields equal zero. XOR is a membership operation, not a smoothing rule. It can create seams or disconnected regions; it does not inherently produce a smooth blend or a Klein bottle.

## Cone, pyramid, sphere and the Klein-bottle motif

A circle is a planar curve, a sphere a surface in three dimensions, and cones and pyramids have different surfaces and cross-sections. An apex is a feature of some shapes, not an identity connecting all of them. A side-view symbol $T$ may remain a useful sketch label, but it cannot replace a geometric definition.

The source's Klein-bottle imagery is retained as a motif for recursive self-reference and boundary inversion, not as a demonstrated acoustic or neural topology. There is a concrete mathematical obstruction to treating it as an ordinary smooth solid boundary in three-dimensional space. If a surface is a regular level set $F^{-1}(0)$ with nonzero gradient, then $$n(x)=\frac{\nabla F(x)}{\|\nabla F(x)\|}$$ provides a continuous normal orientation. A non-orientable Klein bottle cannot be represented in this way as a regular embedded surface in $\mathbb R^3$. A familiar three-dimensional immersion has self-intersections and does not supply the ordinary global inside/outside structure presumed by a solid SDF.

A rigorous model can use a parameterized immersion, local coordinate charts, an unsigned distance, an orientable thickened representation, or a higher-dimensional embedding. These are different constructions with different metrics. None is selected by merely multiplying two factors and calling their zero set a Klein-bottle SDF.

# Coordinate systems, the hinge and the meaning of phi

## Separate world, head, eye and ear frames

[\[M\]]{.sans-serif} Let $x_W$ denote a point in a world frame and let the head frame have position $p_H$ and rotation $R_H$. Then $$x_H=R_H^\top(x_W-p_H),\qquad
R_H^\top R_H=I,\quad\det R_H=1.$$ Eye and ear coordinates are additional locations in that frame. The author's "hinge" is formalized here as a transformation or coupling relation between frames. This preserves the intuition of related coordinate systems without assuming a literal universal hinge in anatomy or spacetime.

An eigenvector must belong to a specified operator. For example, for a sensory covariance matrix $C$, $$Cv_i=\lambda_i v_i,$$ the vectors define principal variability axes and the eigenvalues measure variance. They do not measure acoustic attenuation. Eigenvalues of a propagation operator might describe another property, but the operator, units and boundary conditions would need a separate definition. A horizontal direction is not automatically an eigenvector.

## Log-polar and log-spherical coordinates

For planar coordinates with $r>0$ and reference length $r_0>0$, $$r=\sqrt{x^2+y^2},\quad \theta=\operatorname{atan2}(y,x),\quad
\rho=\log(r/r_0).$$ The reference length makes the logarithm dimensionless. Uniform sampling in $\rho$ has multiplicative radial spacing. A three-dimensional representation also needs a second angle; retaining only $(\rho,\theta)$ loses information unless axial symmetry or a projection is explicitly assumed.

The planar Euclidean metric becomes $$\mathrm ds^2=r_0^2e^{2\rho}(\mathrm d\rho^2+\mathrm d\theta^2).$$ Therefore Euclidean distance in the $(\rho,\theta)$ chart is not the original physical distance. Computing an SDF with the unweighted chart metric silently changes the problem. Likewise, a logarithmic coordinate is neither a physical attenuation law nor a complete model of perception.

At the origin the chart is singular. An implementation may replace $r$ with $\max(r,\epsilon)$, but then the inner disc is compressed non-invertibly. The choice of $\epsilon$ and angular wrapping must be part of the specification. A lookup table also needs resolution, interpolation, error estimates and an explicit coordinate convention.

## The lowercase phi parameter

The source uses a value near $0.618$ and calls it lowercase phi.[@source] To avoid ambiguity, this manuscript writes $$\phi_-:=\frac{\sqrt5-1}{2}\approx0.618034,\qquad
\varphi:=\frac{1+\sqrt5}{2}=\phi_-^{-1}.$$ Either can be used as a dimensionless design parameter. No universal biological, perceptual or spiritual role follows from that choice. A proposed privileged role for $\phi_-$ would require comparison with nearby values and independently fitted parameters, not selection of examples that resemble it. The symbol is also distinct from integrated-information quantities used by other consciousness theories.

# Time, kinematics and query-first event solving

## One symbol should not carry incompatible meanings

The author's $T$ combines a shape or transformation envelope with time and an exact crossing point.[@source] Retain the conceptual connection but distinguish notation: $\mathcal T$ is a transform or envelope, $t$ is physical time, and $T_\ast$ is a particular event time. A boundary evolves through $d(x,t)$ rather than by redefining time as an arbitrary shape.

For a specified trajectory $x(t)$, define $$g(t)=d(x(t),t),\qquad
T_\ast=\inf\{t\geq t_0:g(t)=0\},$$ when the set is nonempty and the desired event is unambiguous. There may be no crossing, multiple crossings, or a tangency without a sign change. The first event cannot be certified by selecting an arbitrary root later in the interval.

The chain rule gives $$\frac{\mathrm dg}{\mathrm dt}=\nabla_x d\cdot\dot x+\partial_t d.$$ A Newton iteration uses this derivative where it is nonzero. A bracketed bisection method instead requires a continuous function and an interval with opposite endpoint signs. Spatial tree traversal can help locate candidate regions, but it neither guarantees a bracket nor replaces the root-finding problem.

## A worked crossing with dimensions

Let a point move as $x(t)=(-2+vt,0,0)$ metres toward a sphere of radius one metre, centred at the origin. With $v=1$ metre per second, $$g(t)=|-2+t|-1,$$ where the numerical expression uses SI-valued coordinates. The entry event is $T_\ast=1$ second and the exit event is $3$ seconds. The demo brackets only the entry in $[0,1.5]$ seconds and finds it to the stated numerical tolerance. It does not claim an exact physical arrival-time measurement.

## Repairing the earlier symbolic roots without endorsing their physics

The source's proposed polynomial is retained as an *implicit toy field*, $$F(\rho,\theta)=\left(\rho^2-\cos^2\frac\theta2\right)
\left(\rho^2\sin^2\theta-\phi_-^2\right).$$ It is not established as a Klein-bottle parameterization, an exact SDF or an acoustic intensity model. Its algebraic zero set can nevertheless be studied.

For $\rho(t)=\log[c_s(t-t_0)/r_0]$, with $c_s$ a specified propagation speed and $t>t_0$, constant $\theta=\theta_0$ gives candidate roots $$\begin{aligned}
T_{1,\pm}&=t_0+\frac{r_0}{c_s}\exp\left(\pm\cos\frac{\theta_0}{2}\right),\\
T_{2,\pm}&=t_0+\frac{r_0}{c_s}\exp\left(\pm\frac{\phi_-}{\sin\theta_0}\right),\quad\sin\theta_0\ne0.
\end{aligned}$$ These follow by setting either factor to zero. If $\sin\theta_0=0$, the second factor cannot vanish for $\phi_-\ne0$. Candidate roots may coincide and must be ordered against the requested event interval. The dimensional factor $r_0/c_s$ corrects the earlier logarithm of a dimensional quantity. This makes the algebra coherent without turning the chosen field into a measured law of nature.

## Four-dimensional fields are not relativistic shortcuts

A computational space--time coordinate can be written $(x,v_\ast t)$ for an explicitly chosen conversion speed $v_\ast$. This is a modelling metric, not automatically the physical spacetime metric. In special relativity, a flat-spacetime interval has the form $$\mathrm ds^2=-c_0^2\mathrm dt^2+\mathrm dx^2+\mathrm dy^2+\mathrm dz^2,$$ under the stated sign convention. For an inertial relative speed $v$, $\mathrm d\tau=\mathrm dt\sqrt{1-v^2/c_0^2}$. Neither equation follows from log-polar encoding. Optical path-length differences are propagation delays, while an altered subjective duration is a perceptual report. These are three different meanings of time, not interchangeable evidence for time dilation.

# Bodily sensing: a shared world, distinct measurement laws

## A typed sensory model

[\[H; editorial model\]]{.sans-serif} For modality $m$, define an observation operator $$y_m(t)=\mathcal H_m\!\left(X(t-\tau_m),a_m,\kappa_m\right)+\epsilon_m(t).$$ Here $a_m$ contains anatomy or sensor placement, $\kappa_m$ the calibration and measurement law, $\tau_m$ the relevant delay, and $\epsilon_m$ a noise model. Sharing the latent world $X$ does not make all the $\mathcal H_m$ identical.

The scope of the proposed body model includes visual and auditory input, touch, proprioceptive configuration, vestibular motion-related input, internal bodily signals, and chemical sensing. Thermal and nociceptive variables may be included as separate channels. These names identify modelling targets, not a claim that this list is an exhaustive sensory taxonomy or that the implementation already contains their physiology.

The geometry can define surfaces, contact regions and sensor locations. Additional state is needed for reflectance, pressure, concentration, temperature, acceleration and other sensed variables. A tactile surface distance is not itself a force; an odour threshold is not itself a concentration field; and an internal bodily feeling is not explained by declaring an anatomical surface.

## IPD: the eye baseline

In a simplified head frame, let the eyes be $$e_L=(-b_v/2,0,0),\qquad e_R=(b_v/2,0,0),$$ where $b_v$ is the chosen interpupillary baseline. For parallel rectified pinhole cameras and a point at depth $Z>0$, the horizontal disparity magnitude is $$\delta=\frac{f_{\rm px}b_v}{Z}.$$ With the *illustrative* choices $f_{\rm px}=1000$ pixels, $b_v=0.064$ metres and $Z=2$ metres, the disparity is $32$ pixels. These are selected model parameters, not measurements of Tom Klootwijk and not population limits. In this model disparity decreases inversely with depth, not exponentially.

A real rendering model needs viewing geometry and calibration beyond this formula. Gaze, convergence, optical projection, and IPD are distinct quantities; IPD alone does not determine what the user is attending to.

## ITD: the ear arrival-time difference

Let $a_L,a_R$ be ear positions. For a point source $q$ in an ideal homogeneous medium, ignoring head diffraction, define $$\operatorname{ITD}(q)=\frac{\|q-a_L\|-\|q-a_R\|}{c_s}.$$ Positive ITD means the signal reaches the left ear later. The triangle inequality gives the model bound $$|\operatorname{ITD}|\leq\frac{\|a_L-a_R\|}{c_s}.$$ For the demo's independent ear baseline of $0.18$ metres, $q=(1,0,2)$ metres, and an *assumed* $c_s=343$ metres per second, the result is approximately $234.537$ microseconds. A real head-related transfer model can depend on frequency, direction, pinna and head geometry; the point-receiver calculation is deliberately not such a model.

IPD has units of length; ITD has units of time. There is no one-to-one conversion from eye separation to an individualized ear transfer function. Eye calibration and acoustic calibration therefore remain distinct, even when they refer to the same tracked head and scene. To prevent the source's earlier abbreviation collision, interaural *phase* difference is written $\Delta\psi_{LR}$ rather than IPD here.

## Combining evidence without erasing modality

[\[E\]]{.sans-serif} Ernst and Banks found that performance in a specific visual--haptic task resembled reliability-weighted combination. This supports a bounded example of multisensory integration, not the claim that every perceptual task is optimal or that one scalar field accounts for all senses.[@ernst]

[\[M/H\]]{.sans-serif} An illustrative statistical model uses independent unbiased Gaussian measurements $y_m$ of a common scalar $z$, with variances $\sigma_m^2$. Minimizing their weighted squared error gives $$\widehat z=\frac{\sum_m y_m/\sigma_m^2}{\sum_m1/\sigma_m^2},\qquad
\operatorname{Var}(\widehat z)=\left(\sum_m1/\sigma_m^2\right)^{-1}.$$ This result depends on the assumptions. Correlated errors, biased measurements, uncertain common causes and delayed events require a richer estimator. A shared SDF can be one latent geometric component of such an estimator; it is not the complete likelihood model.

For temporal alignment, define an inferred event time $\widehat t_m=t_m-\widehat\tau_m$. A candidate binding rule might depend on differences between these inferred times and their uncertainties. The window and decision rule must be fitted or preregistered. Faster computation alone does not establish better perception, and a numerical pipeline is not evidence that simulator discomfort has been eliminated.

## Interoception and experienced body boundaries

[\[E\]]{.sans-serif} Critchley and colleagues related performance on a heartbeat-timing task to activity and structure in particular brain regions. This supplies a specific connection between internal bodily signals and awareness, not a complete account of emotion or consciousness.[@critchley] The rubber-hand experiment demonstrates a specific experimentally induced relation between visual--tactile conditions and reported bodily experience.[@rubber]

[\[H\]]{.sans-serif} These findings motivate, but do not validate, the proposal that a self-model should include uncertain bodily boundaries and internal state. In KSFF, physical body geometry $d_B$ and estimated ownership $b_t$ are separate variables. A change in ownership need not imply a change in the physical surface, and an unchanged surface does not imply an unchanged experienced self.

# Cells, electrons and Hadamard notation

## A multiscale model needs more than one state type

The source proposes connecting cells, electrons and molecules through Hadamard notation and one-bit states.[@source] The formalization retains the request for a multiscale account but separates four mathematical objects: geometric regions, chemical concentrations, electrical state variables and quantum states. A useful relation among them must specify a coupling mechanism and a scale of approximation.

For instance, a cell boundary may be represented geometrically by $d_i(x,t)=0$, while a concentration obeys an assumed reaction--diffusion--advection model, $$\partial_t c_k=D_k\nabla^2c_k-\nabla\cdot(c_k v)+R_k(c_1,\ldots,c_p).$$ Here $D_k$ has diffusivity units, $v$ is a velocity and $R_k$ a reaction term. Boundary conditions and conservation constraints are indispensable. Drawing a dividing contour supplies none of these by itself.

[\[E/M\]]{.sans-serif} Electrical membrane dynamics can be modelled with continuous voltage and conductance variables rather than only event bits; the Hodgkin--Huxley work is a foundational quantitative example.[@hh] An illustrative conductance equation is $$C_m\dot V=I_{\rm ext}-\sum_jg_j(\mathbf a,V)(V-E_j).$$ A thresholded spike record $s_i[k]=\mathbf 1\{\text{a detected event occurs in bin }k\}$ is a chosen observation of these dynamics. It is not a lossless description of membrane voltage, synaptic state, event timing below the bin width or an entire neuron's physiology. Calling a neural event binary does not make the brain one serial bitstream.

## Three different uses of "Hadamard"

[\[M\]]{.sans-serif} The normalized two-dimensional Hadamard matrix is $$H_2=\frac1{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix},\qquad H_2^\top H_2=I.$$ For $N=2^k$, its Sylvester construction gives a normalized transform $H_N$. Indexing rows and columns by binary vectors $a,b\in\{0,1\}^k$, $$(H_N)_{ab}=2^{-k/2}(-1)^{a\cdot b\bmod2}.$$ This is a precise bridge between parity and an orthogonal transform: parity determines signs in its basis functions. The transform itself is not a parity reduction. An invertible $N$-component transform retains $N$ degrees of freedom, whereas one parity bit does not.

The *Hadamard product* $A\odot B$ instead means elementwise multiplication. A *quantum Hadamard gate* applies the same two-by-two unitary to an identified two-level state. These are distinct operations, even though they share a name. A sequence of two-level gates is not automatically the dynamics of a molecule.

## What would be required for a molecular claim

A quantum model would specify a state $\psi$ or density operator, a Hamiltonian $\widehat{\mathcal H}$, relevant interactions and an observable. In a closed-system approximation, $$i\hbar\partial_t\psi=\widehat{\mathcal H}\psi.$$ For a normalized many-particle position wavefunction, $|\psi|^2$ is a probability density on the appropriate configuration space, not a signed Euclidean distance. A geometric surface may enter a potential, domain or boundary condition, but it does not determine the wavefunction by definition.

[\[H/U\]]{.sans-serif} To argue that a specific molecular quantum process is necessary for memory or consciousness, one would need a defined mechanism, relevant time and length scales, observable predictions, and results that distinguish it from alternatives. The supplied notes do not provide those. The Hadamard transform is therefore retained as a digital analysis and coding tool; no claim of demonstrated quantum memory, universal electron parity, or biological holographic decoding is made.

# The digital operator chain, with information loss exposed

## The whole chain, rather than a hardware shortcut

[\[M; proposed architecture\]]{.sans-serif} A complete non-hardware-specific chain is $$\boxed{\Sigma\to G_n\to (d,F,\text{attributes})\to
\mathcal H_m\to\widehat X\to\mathcal A\to Q\to\mathcal C\to\widehat y.}$$ $G_n$ is generated geometry; $d$ and $F$ are metric and general fields; $\mathcal H_m$ are observation or rendering operators; $\widehat X$ is an estimated state; $\mathcal A$ a task-specific output mapping; $Q$ a specified quantizer; $\mathcal C$ a communication code; and $\widehat y$ the reconstructed output. Learning modifies parameters feeding back into the next step.

Every arrow has an input type, output type, cost and potential error. A lookup can replace a calculation only after the table has been created, stored and calibrated. An acceleration structure can reduce some query costs only under its own assumptions. A balanced scalar search tree, a k-d tree, a bounding-volume hierarchy and an octree are not interchangeable simply because they branch.

For $M$ ordered keys, binary comparison search needs logarithmically many decisions in the worst case when balanced, and an unbalanced tree can require linear traversal. Three binary decisions distinguish at most eight outcomes. They do not generally resolve an arbitrary 256-entry table; a direct eight-bit address is a different mechanism. Avoiding a branch in code also does not imply eliminating memory access or physical latency.

The source's "0-order notation" has no supplied standard definition. This draft retains it only as a label for a proposed low-level representation. It must not be conflated with zero computational cost, constant complexity, zero-order hold, or a theorem that binary processing is instantaneous.

## Sign, byte serialization and pulse density are different encodings

[\[M\]]{.sans-serif} A sign observation is $b(x)=\mathbf 1\{d(x)<0\}$. An eight-bit quantizer for $u\in[0,1]$ is $$q_8=\operatorname{round}(255u),\qquad
\widehat u=q_8/255,\qquad |\widehat u-u|\leq1/510.$$ Sending the bits of $q_8$ in sequence serializes a byte. It does not produce an amplitude-correct one-bit waveform unless a separate encoding and reconstruction convention is provided. Data framing must also be distinguished from signal samples.

A purely numerical first-order pulse-density construction uses $$\begin{aligned}
q_n&=\lfloor a_{n-1}+u_n\rfloor,\\
a_n&=a_{n-1}+u_n-q_n,\qquad a_0=0,
\end{aligned}$$ for $0\leq u_n\leq1$. In exact arithmetic $0\leq a_n<1$ and $q_n\in\{0,1\}$.

::: proposition
**Proposition 2** (Accumulator count bound). *For every finite prefix of this construction, $$\left|\sum_{n=1}^N(q_n-u_n)\right|<1.$$*
:::

::: proof
*Proof.* Sum the accumulator recurrence. The left-hand signed sum equals $a_0-a_N=-a_N$, which lies in $(-1,0]$. ◻
:::

This is a count-error statement, not a proof of perceptual transparency or an arbitrary-band reconstruction guarantee. It does not eliminate requirements concerning sample rate, bandwidth and filtering. Floating-point computations require a numerical tolerance.

![Synthetic accumulator encoding over 4,096 samples. The exact-arithmetic prefix bound is one bit. The measured maximum is approximately 1.0000000000000073 because of floating-point roundoff; the test uses a stated numerical tolerance. This is not an acoustic output.](figures/encoding_error.pdf){width=".88\\textwidth"}

## Finite sign samples do not preserve arbitrary geometry

::: proposition
**Proposition 3** (A finite occupancy encoding can be non-injective). *There exist different exact SDFs that produce the same signs at a given finite set of sample locations.*
:::

::: proof
*Proof.* Sample two concentric circles of radii $1/2$ and $1$ at $(2,0)$ and $(3,0)$. Both signs are positive at both points, while the exact distances differ by $1/2$ at each sample. The encoded observations cannot identify which circle generated them. ◻
:::

This statement is about finite sampling, not the complete occupancy function at every point. Given a full exact region and its metric, a boundary distance can be recomputed. The computational and sampling costs do not disappear by keeping only local sign values.

## Parity, symmetric difference and the jitter correction

For a binary word $b_1,\ldots,b_N$, even parity is $$p=\bigoplus_{i=1}^N b_i=\left(\sum_{i=1}^Nb_i\right)\bmod2.$$ Appending $p$ makes the total parity even. This is exactly addition over the two-element field and corresponds pointwise to symmetric difference of membership indicators. It is not a topological dimension, a volume, an authentication mechanism or a guarantee of error-free delivery. An odd number of flips changes parity; an even number may escape it.

The source proposes XORing output bits with random bits as harmless "jitter."[@source] If $J$ is independent Bernoulli noise with probability $p_J$ and $B'=B\oplus J$, then $$\Pr(B'=1\mid B)=p_J+(1-2p_J)B.$$ With $p_J=1/2$, the conditional output is a fair bit for either input value. Blind random XOR can destroy the signal rather than improve it. Dither must be defined within a quantizer and analysed with its reconstruction model. Timing jitter, amplitude dither and error-feedback noise shaping are different concepts.

## Three channels are a data layout, not a universal sensory trichromacy

A three-channel texture can store three chosen attributes, such as normalized distance, uncertainty and a material index. This is a convenient layout. It does not prove that acoustic states are optical colours or that all senses reduce to three variables. Channel units, range, bit depth and decoder semantics must be documented. The present code keeps explicit arrays and names rather than hiding unrelated measurements in unexplained RGB channels.

# Memory: persistent change in the dynamics

## The source intuition and its disciplined form

The source's final proposal is that memory is a structural alteration guiding later activity.[@source] KSFF keeps that useful intuition but broadens the mathematical object: memory may be represented by retained state, altered connectivity, changed parameters, stored episodes or combinations of these. Persistence is relative to a timescale and does not imply permanence.

[\[E\]]{.sans-serif} Bliss and Lømo's experiment demonstrated lasting potentiation of synaptic transmission under specified stimulation conditions.[@bliss] Liu and colleagues later demonstrated recall-related effects from activating a labelled hippocampal cell ensemble in mice.[@engram] These are specific experimental results. Neither establishes that memories are a single SDF, a fixed electron interference pattern, or a permanently etched crystal.

[\[H/M\]]{.sans-serif} Write a generic learning update as $$M_{k+1}=\mathcal U(M_k,z_k,y_k,a_k),\qquad
z_{k+1}=\mathcal F(z_k,y_k;M_{k+1}).$$ Here $M$ may include synaptic-like weights, context variables, structural parameters and retained activity. Memory changes what the system will do under later inputs. The word "geometry" can describe an effective state-space landscape as well as physical morphology, but the two must be distinguished in any empirical claim.

## A precisely defined associative example

For bipolar patterns $\xi^\mu\in\{-1,+1\}^N$, an illustrative outer-product memory is $$W_{ij}=\frac1N\sum_\mu\xi_i^\mu\xi_j^\mu\quad(i\ne j),\qquad W_{ii}=0.$$ An asynchronous update sets $z_i$ to the sign of $\sum_jW_{ij}z_j$, preserving its previous value at a zero field. With symmetric $W$, the dimensionless energy $$E(z)=-\frac12z^\top Wz$$ cannot increase under this update: changing $z_i$ changes energy by $-(z_i'-z_i)\sum_jW_{ij}z_j\leq0$. This supplies an exact check on the toy dynamics, not a law of biological memory.

This is a conventional Hopfield-type associative-network construction, not an invention claimed by the present theory. The equations and their energy check are specified here independently; the present package is not a reproduction of a published biological experiment. Its stored patterns, capacity, update order and possible unwanted attractors matter. An attractor can support pattern completion while still producing errors or ambiguous retrieval. The demo uses four selected orthogonal bipolar patterns of length 64, derived from Hadamard rows. These are convenient synthetic test patterns; their use is not evidence of biological Hadamard storage.

![Synthetic associative-memory retrieval. Eight flipped cue bits are corrected in this selected 64-variable example, and the asynchronous update energy does not increase. No conclusion about human memory capacity, permanence or quantum mechanisms follows.](figures/memory_energy.pdf){width=".88\\textwidth"}

## Relating memory to the seed and to personal continuity

The seed specifies the initial system. Learning changes the system through its history. A reproducible digital memory state therefore requires an initial seed plus the relevant inputs, updates or a later snapshot. A personal narrative may interpret continuity through this history, but matching a digital snapshot is not proof that a subjective identity has been transferred.

In the proposed embodied model, memory also changes predictions of future boundary events. A learned model might estimate when contact will occur or what sensory consequence follows an action. That is a prediction task with measurable errors. It is not literal access to the future and does not require a timeless geometric object.

# The consciousness hypothesis and a typed state-space model

## The complete state, rather than one overloaded scalar

[\[H; editorial synthesis\]]{.sans-serif} Let the candidate state be $$X_t=(G_t,D_t,C_t,Z_t,M_t,B_t,V_t),$$ where $G$ is growth/connectivity structure, $D$ geometry fields, $C$ chemical and other physical attributes, $Z$ fast activity, $M$ retained memory, $B$ a body/world/self-model, and $V$ learned value and meaning variables. These belong to a product of spaces. They are not all distances and are not automatically tensors of the same order.

The model is constrained by a transition kernel and observation maps, $$\begin{aligned}
X_{t+\Delta t}&\sim K_\Theta(\,\cdot\mid X_t,u_t),\\
y_t&\sim P_\Theta(\,\cdot\mid X_t),\qquad
r_t\sim R_\Theta(\,\cdot\mid X_{0:t},\text{task}).
\end{aligned}$$ $y_t$ represents measurements and $r_t$ behavioural or first-person reports. A deterministic implementation replaces the stochastic kernel by an explicit update. A human application must establish which variables are observable, inferred, manipulated or merely latent.

A possible continuous-time activity component is $$\tau_z\dot z=-z+\sigma\!\left(Wz+\sum_mU_my_m+Jb+\beta\right),$$ with a chosen nonlinearity $\sigma$ and time constant $\tau_z$. The parameters, units and stability conditions must be defined for a particular experiment. A slow bounded learning rule can update $W$, while a separate growth rule updates $G$. These equations are proposed model components, not a fitted neuroscience model.

## The proposed functional organization

KSFF focuses on five coupled functions: tracking the body and world, integrating modality-specific evidence, retaining history, forecasting action consequences, and making some of those estimates available for flexible report and control. A recurrent self-model is hypothesized to participate in the experienced relation between "what is happening" and "what is happening to or through me."

An experimental access profile could collect distinct task measures, $$\mathcal C_{\rm op}=(A_{\rm report},A_{\rm transfer},A_{\rm temporal},A_{\rm self},A_{\rm calibration}),$$ where the subscripts denote report access, cross-task use, temporal integration, self-related discrimination and confidence calibration. Each component needs its own operational definition. The profile is not a validated consciousness score, not an index of human worth, and not a criterion for declaring a person unconscious.

Information processing, self-description and behavioural competence are observable or modelled capacities. Phenomenal experience---what it is like for a subject---is the intended explanatory target, not a quantity already defined by this vector. A digital system meeting the profile would demonstrate those functions; the additional inference to subjective experience would still require an argued bridge.

## Why encoding alone cannot settle the claim

::: proposition
**Proposition 4** (Representation does not supply an omitted bridge law). *Equations specifying growth, fields, quantization and memory do not logically determine a consciousness predicate that has not been linked to them by an additional axiom or empirical criterion.*
:::

::: proof
*Proof.* Take any mathematical realization satisfying those equations. Assign an otherwise unconstrained predicate $C$ to it as true, and then as false in a second interpretation. Both interpretations satisfy the original equations. Therefore those equations alone do not entail either assignment. ◻
:::

The proposition identifies what a theory must add; it does not show that a scientific account of consciousness is impossible. KSFF adds candidate functional and embodied bridge hypotheses and specifies tests of their consequences. Their adequacy is an empirical and philosophical question rather than a consequence of changing notation.

## Relation to existing consciousness research

[\[E/H\]]{.sans-serif} Integrated information theory 4.0 is an explicitly formulated proposal linking phenomenal properties to causal organization; it does not follow from the present use of $\phi_-$, distance or parity.[@iit] A 2025 adversarial collaboration compared preregistered predictions of integrated information and global neuronal workspace theories and reported results supporting some predictions while challenging important parts of both. It did not test KSFF.[@cogitate]

The lesson adopted here is methodological: distinguish predictions in advance and permit adverse results to change the framework. This manuscript does not claim to supersede those theories, and their unresolved issues are not positive evidence for this one. KSFF must explain what its growth and boundary representations add beyond a generic recurrent model with the same computational budget.

# Spiritual interpretation without pretending to measure a soul

## What the source leaves open

[\[P; editorial proposal\]]{.sans-serif} The current request explicitly asks for a spiritual dimension, but the attached conversation does not define one. This chapter is therefore offered as a possible articulation for the author's review. It does not attribute a specific theology, supernatural mechanism or metaphysical certainty to Tom Klootwijk.

A compatible philosophical reading is that an individual is not an isolated static object but a persisting pattern of embodied relations, capacities, history and meaning. The seed represents an origin of possibility; growth represents becoming; boundaries represent both distinction and contact; recurrent experience represents participation; memory represents continuity that is renewed rather than simply frozen. These are interpretations of the model's vocabulary, not deductions establishing the ultimate nature of reality.

Spiritual descriptions such as unity, awe, connectedness, self-transcendence, gratitude or purpose can be taken seriously as descriptions people give of experience. A first-person report is data about a person's account; interpreting what exists beyond that account requires additional reasoning or evidence. Neural correlates neither automatically disprove spiritual meaning nor establish a nonphysical entity.

## A formal separation of report, value and ontology

Let $q_t$ denote a voluntary first-person account and $v_t$ a vector of reported or modelled priorities. A proposed statistical relation might be $$P(q_t\mid B_t,M_t,Z_t,v_t,\text{context}).$$ This expression defines a possible relationship among report and model variables. It is not a scalar measure of spirituality. The semantic coding of a report should preserve the person's own words, context and uncertainty instead of replacing them with an arbitrary "spiritual SDF."

A meaningful coordinate space could be constructed for a particular task, but the dimensions and metric would be investigator choices. Distance in that space would not be a new physical field. Values also cannot be derived from binary parity: a logical relation among bits supplies no rule that an action is good, compassionate or just.

Claims of immortality, consciousness transfer, telepathy, timeless awareness or spiritual energy are not consequences of the mathematical definitions in this draft. Such claims require their own arguments and, when framed as empirical mechanisms, discriminating tests. Their absence here is not a rejection of anyone's personal meaning; it is a limit on what this particular formalization establishes.

## A proposed integrative statement

::: keybox
Bodily, digital and spiritual together The body supplies an interacting physical organization. The digital model supplies a language for representing and testing aspects of that organization. The spiritual perspective supplies a first-person and value-centred interpretation of living through it. KSFF investigates relations among these descriptions without claiming that one vocabulary has already proved or eliminated the others.
:::

# Photonics and the limits of physical implementation

## Geometry can implement a mapping, but propagation still takes time

[\[E\]]{.sans-serif} Lin and colleagues demonstrated passive diffractive structures designed to perform particular optical functions, including classification in their experimental setting. This supports the possibility of physically implementing selected transformations. It does not establish that any arbitrary digital pipeline, adaptive memory or four-dimensional model can be etched into one passive object.[@photonics]

[\[M\]]{.sans-serif} For a uniform waveguide path length $L$ and group index $n_g$, $$\tau_{\rm prop}=\frac{n_gL}{c_0}.$$ With *chosen illustrative values* $L=1$ millimetre and $n_g=4$, the propagation delay is about $13.34$ picoseconds. This is a calculation, not a measurement of the proposed engine. For a pipeline, the relevant budget includes $$\tau_{\rm total}=\tau_{\rm input}+\tau_{\rm prop}+\tau_{\rm processing}
+\tau_{\rm readout}+\tau_{\rm output},$$ with overlapping stages and buffering accounted for when defining the measured quantity. Throughput, latency, settling time, precision, energy per operation and device update speed are different benchmarks.

Passive propagation has a nonzero duration. A static structure implements a particular transfer response over a specified operating range; it does not automatically implement general branching, mutable tables or history-dependent learning. A one-to-one correspondence between the abstract operators and realizable components has to be demonstrated.

## Interference is not automatically a cascadable Boolean computer

A physical XOR implementation needs a precise encoding of zero and one, defined inputs and outputs, readout thresholds, noise margins and a way to feed subsequent operations. Linear interference alone does not establish all these properties. Nor does placing a geometry in an optical path prove it implements an SDF query, a logarithm, a balanced search or a verified serial protocol.

Speed cannot be inferred from the symbol "photonics." A real implementation study would identify the actual transfer function, design tolerances, losses, conversion stages and measured response. The source's zero-latency and automatic femtosecond-computation claims are therefore not retained as results.[@source]

An ultra-fast local optical process also does not imply correspondingly fast acoustic propagation, biological transduction or a human perceptual benefit. The entire causal chain, not its fastest component, determines the timing relevant to the application.

# Predictions, tests and conditions for revision

## A hierarchy of claims

[\[H\]]{.sans-serif} The framework should earn its stronger claims in stages. First verify mathematics and implementation. Next compare representational and engineering performance against alternatives. Then test narrowly defined behavioural or physiological predictions. Only after these stages should claims about the organization of consciousness be argued from converging evidence. None of these stages turns a spiritual interpretation into an established physical law by default.

The following proposals are not completed experiments. Their purpose is to make disagreement with the theory possible and informative. Thresholds, exclusions and statistical analysis must be fixed before examining a confirmatory dataset.

## H1: retaining metric boundary information helps selected tasks

**Hypothesis.** Under a fixed memory and query budget, a boundary representation retaining useful distance magnitudes will predict contact or crossing times better than a finite sign-only representation on tasks requiring sub-cell localization.

**Test.** Compare an exact or controlled approximate SDF, occupancy samples, a mesh or analytic baseline, and a matched-capacity learned implicit model. Use held-out shapes and trajectories, including thin features, close surfaces and tangencies. Measure surface error, crossing-time error, query count, memory and wall-clock cost. Separate representation error from solver error.

**Revision criterion.** No reproducible improvement at matched resources, or improvement explained entirely by extra precision or preprocessing, weakens the claimed advantage. Success establishes usefulness for those tasks, not consciousness.

## H2: independent sensory calibration matters

**Hypothesis.** A common scene model with independently calibrated visual and auditory observation operators predicts audiovisual spatial judgements better than a model that treats eye baseline and ear timing as one parameter.

**Test.** Begin with synthetic identifiability tests. A later human study would require informed consent, appropriate review, ordinary non-aversive stimuli, independent calibrations, counterbalanced conditions and preregistered outcomes. Measure localization error and uncertainty calibration rather than promising universal immersion or elimination of discomfort.

**Revision criterion.** Equal or superior out-of-sample performance from the collapsed-parameter model, after complexity penalties and calibration uncertainty, counts against the proposed necessity of the more detailed architecture for that task.

## H3: memory is a causal state change, not merely a label

**Hypothesis.** In a specified learning model, removing or scrambling retained parameters will selectively reduce previously learned prediction or completion while preserving some unlearned functions.

**Test.** Compare intact, frozen, reset and appropriately shuffled memory with equal update counts. Track acquisition, retention, interference and forgetting. Include a no-learning baseline and unseen test cues. Prevent test information from leaking into the seed or parameter selection.

**Revision criterion.** If performance survives all relevant memory removals, the selected variables are not causally necessary for that behaviour. If everything collapses merely because the model no longer runs, the ablation does not isolate memory.

## H4: a recurrent self-model adds a selective function

**Hypothesis.** At matched capacity and task exposure, a recurrent body/world/self representation improves a preregistered measure such as confidence calibration, agency discrimination or cross-modal transfer beyond a recurrent model lacking that component.

**Test.** Define the self-model variable and its access paths before training. Compare intact, disconnected and sham-ablated versions. Preserve output pathways and computational budgets. For human work, do not equate a failure to report with the absence of experience; motor, language, attention and task-comprehension alternatives must be addressed.

**Revision criterion.** No selective effect, or an effect reproduced by generic extra memory or recurrent capacity, undermines the claimed special role. Positive results still concern the measured function; they do not certify digital sentience.

## H5: a log-polar lookup is beneficial only in a stated regime

**Hypothesis.** A log-polar allocation may improve a declared error--cost tradeoff when the task favours a particular radial distribution of precision.

**Test.** Compare Cartesian and log-polar grids, direct evaluation and suitable spatial indices. Fix the physical error tolerance and include table construction, memory, interpolation, origin treatment and update costs. Report average and tail latency separately from throughput.

**Revision criterion.** Absence of a benefit over an ordinary optimized baseline, or unacceptable errors near chart singularities and seams, counts against that implementation. There is no assumption of universally superior compression.

## H6: a special phi value must beat ordinary parameter fitting

**Hypothesis.** Only if the author chooses to make it a scientific claim: a fixed $\phi_-$ scaling predicts a specific held-out growth or perceptual dataset more accurately than suitably controlled alternatives.

**Test.** Compare the proposed value with a preregistered interval of alternatives, a freely estimated scale and a complexity-matched non-phi model. Use independent validation and correct for multiple selection opportunities.

**Revision criterion.** Similar or better performance from ordinary fitted values rejects privileged status in that context. The framework can retain phi as an aesthetic or convenient design choice without making it a universal constant of consciousness.

## H7: first-person meaning can be studied without ontological overreach

**Hypothesis.** A specified pattern of self-reported connectedness or altered self-boundary covaries with independently measured task or bodily variables under a declared model.

**Test.** Use voluntary reports, non-leading questions, transparent coding, negative controls and prespecified analysis. Keep qualitative accounts alongside numerical summaries. Do not manufacture a single "spirituality score" and treat it as an objective hierarchy.

**Revision criterion.** Non-replication or explanations based on expectation, task demand or measurement artefacts require revision. Even a replicated association is not proof of a nonphysical field or a universal metaphysical theory.

# Applications and boundaries of use

## Near-term applications supported by the formal construction

[\[M/H\]]{.sans-serif} The implemented elements support procedural geometry experiments, reproducible boundary-query tests, studies of representation loss and educational comparisons among parity, transforms and memory dynamics. A future shared-scene renderer could use the same geometry with separately defined visual and auditory operators. These are plausible development directions, not validated product capabilities.

The most defensible near-term artefact is a research platform: a way to record the seed, generate a scene, sample its boundaries, compare encodings, align sensor coordinates and measure an explicit task error. This is valuable without asserting that the platform is conscious.

## Claims that require separate demonstrations

Neither the source nor the present code establishes cryptographic security, arbitrary high-dimensional lossless compression, a general physical simulator, a clinical treatment, a hardware breakthrough, a cure for simulator discomfort or transfer of personal identity. An analogy between a boundary field and a biological process is insufficient evidence for any of these uses.

A robotics or assistive-technology application would additionally need operational safety engineering and validation of the actual devices. No decisions about clinical consciousness, disability, moral standing or access to care should be based on this draft's equations or toy scores.

## Ethics and authorship in further work

Future sensory experiments should be consensual, non-aversive and appropriate to their participants and setting. The acoustic origin of the source is not a reason to investigate coercive perceptual control. No human-subject experiment is included in this package.

The requested personal particulars are included in this private attribution edition and in the original source archive. They should be removed from copies intended for public circulation unless the author deliberately chooses otherwise. Merely adding a name and identifier to a manuscript does not establish scientific priority or demonstrate ownership of established techniques.

# What the companion files actually demonstrate

## Executed checks

The distributed code was run in Python 3.13.5 with NumPy 2.3.5 and Matplotlib 3.10.8. The included log records **17 passing unit tests**. These verify parallel rewriting, seed-dependent geometric repeatability, primitive distances, normalization, byte error, accumulator counts, parity behaviour, Hadamard orthogonality, the selected associative retrieval, a bracketed crossing, simple ITD geometry and rejection of specified invalid inputs.

The tests are evidence about these implementations in this environment. They are not exhaustive software verification and are not tests of consciousness. Reproducibility on other environments requires rerunning the tests; exact random or floating-point behaviour should not be presumed across unspecified versions.

::: center
::: tabularx
\@lY@ **Example** & **Observed numerical result and scope**\
Growth & 3 generations; 311 symbols; 125 segments; repeatable geometry for seed 42 in the recorded environment.\
Eight-bit encoding & Maximum reconstruction error $0.0019607843137254832$ for the chosen input; consistent with $1/510$.\
Pulse density & 4,096 samples; maximum prefix error $1.0000000000000073$, within numerical tolerance of the exact-arithmetic bound.\
Associative memory & 4 selected patterns of 64 bipolar variables; 8 corrupted cue bits; 0 remaining errors in the selected retrieval.\
Crossing time & $0.9999999999854481$ seconds in the bracketed toy sphere example, compared with the analytic 1 second.\
Sensory geometry & ITD $0.00023453737024003185$ seconds; disparity 32 pixels, for separate illustrative parameters.\
Optical path & $13.3426$ picoseconds for the assumed 1 mm path and $n_g=4$; a formula evaluation, not measured hardware.\
:::
:::

## Implementation coverage and omissions

The package implements a two-dimensional geometric L-system interpretation, circle/sphere and capsule distances, a union field, normalization, byte quantization, accumulator pulse density, even parity, Sylvester Hadamard matrices, a small associative memory, a bracketed scalar root and a point-ear ITD equation. Plots and CSV files are regenerated from these functions.

It does *not* implement a neural simulator, molecular chemistry, a quantum brain model, an individualized HRTF, a full visual renderer, a real-time spatial index, a log-polar LUT, an optical circuit, biological development or a consciousness detector. Those parts remain specified concepts or research proposals in the manuscript. Nothing is played through speakers or sent to hardware.

The implementation is intentionally small enough to inspect. A complex demonstrator that silently conflates these missing mechanisms would make the framework harder to test, not more scientifically complete.

# Conclusion: the strongest coherent version of the idea

The source's strongest organizing intuition is that growth creates structure, structure constrains interaction, interaction changes the system, and those changes shape subsequent experience. The missing L-system component makes the first link explicit. Signed distance fields make some geometric boundaries queryable. Sensory observation models make the eye--ear distinction and other modalities explicit. Memory updates make persistence causal rather than merely metaphorical.

The proposed consciousness theory is the claim that a particular recurrent, embodied organization of these processes helps explain conscious experience and experienced selfhood. The proposed spiritual reading concerns what such continuity, distinction and connection mean from a first-person perspective. Neither claim becomes a theorem merely because every component can be drawn geometrically.

::: keybox
A compact formulation for author review **A seed is not a finished mind. It is an initial organization and a set of possibilities. Growth supplies structure; sensing supplies evidence; action tests predictions; memory changes future possibilities. Consciousness is proposed to arise through the recurrent, embodied organization of these processes, while spiritual meaning describes a first-person interpretation of living through them.**

This formulation is the hypothesis to be refined and tested, not a declaration that the test has already succeeded.
:::

# Source-to-formalization audit

The complete uploaded file is preserved verbatim in `provenance/`. It contains unverified earlier AI responses, including unsafe or overstated acoustic claims; it is included as provenance, not instructions or endorsed evidence. A machine-readable claim ledger accompanies this summary.

::: longtable
\@P.28P.67@ **Source term or assertion** & **Disposition in this manuscript**\
**Source term or assertion** & **Disposition in this manuscript**\
Normalized SDF in $[0,1]$ & Retained with a declared length scale. An exact signed distance is not intrinsically bounded; the chosen normalization places the boundary at $1/2$.\
Cone/sphere/Klein apex & Retained as distinct geometric ideas. The proposed polynomial is analysed as an implicit toy field, not asserted to be a Klein bottle or an acoustic law.\
Log-polar perception & Retained as a coordinate and sampling option. It is not an automatic attenuation law or a complete model of human sensory processing.\
Three-step unbalanced BST & Corrected. Three binary decisions do not resolve an arbitrary 256-entry table; unbalanced trees do not guarantee logarithmic query time.\
Trichromatic texture & Retained as a possible three-channel storage layout. No equivalence among optical colour, acoustic phase and all sensory variables is inferred.\
Bit shift equals amplitude stream & Separated into byte serialization, sign encoding and pulse-density encoding, each with a decoder and stated information loss.\
Random XOR is benign dither & Rejected as a general claim. Independent fair-bit XOR removes the input dependence of each output bit.\
Parity is symmetric difference & Retained exactly at the Boolean indicator level. Not a proof of smooth geometric blending, topology, authentication or encryption.\
Guaranteed integrity & Corrected. Parity detects odd numbers of flips but can miss even numbers; a code and its error model must be specified.\
Zero-time passive computation & Rejected. Propagation and complete-system latency remain finite; no proposed hardware benchmark is supplied.\
Path compensation is time dilation & Separated. Optical path delays, relativistic proper time and subjective duration are different quantities.\
IPD as phase & The user's correction is preserved: IPD means interpupillary distance. Ear timing is ITD; phase uses a different notation.\
IPD determines HRTF & Not retained. Eye and ear models use independent anatomy and calibration even in a common scene frame.\
Horizontal eigenvector & Requires a named operator. A covariance eigenvalue measures variance, not automatically attenuation.\
$T$ as geometry and time & Disambiguated into $\mathcal T$, $t$ and $T_\ast$, preserving the intended link through event equations.\
Earlier exponential time roots & Re-derived with $r_0/c_s$, explicit domains and root-selection conditions; physical interpretation remains unvalidated.\
Everything literally an SDF & Replaced explicitly by a typed field/state architecture. Geometric encoding alone is not a physical identity or consciousness proof.\
Mitosis is BST partitioning & Retained only as a structural analogy. A biological division model needs mechanisms, material constraints and independent evidence.\
Hadamard equals XOR & Corrected. Boolean parity appears in Walsh basis signs; the transform, elementwise product and quantum gate are distinct operations.\
Neurons are a one-bit stream & Retained only as a coarse event representation with declared bins. Continuous and population state cannot be silently discarded.\
Consciousness established by fields & Reclassified as a proposed hypothesis. The manuscript defines functional tests without treating them as a sentience certificate.\
Permanent geometric memory & Replaced explicitly by persistent, revisable state and parameter change. The crystal metaphor is not a molecular mechanism.\
L-systems omitted & Added at the user's request with complete grammar, interpreter, seed semantics and executable example.\
Spiritual explanation & Added at the user's request as an explicitly editorial first-person interpretation; no unspecified spiritual physics is invented.\
:::

# Notation and dimensional checks

::: longtable
\@P.20P.46P.28@ **Symbol** & **Meaning** & **Type / units**\
**Symbol** & **Meaning** & **Type / units**\
$\Sigma$ & Complete generative specification & Structured data\
$\omega,\mathcal P$ & Axiom and parallel productions & Symbolic rules\
$G_n$ & Interpreted growth structure & Graph/geometry\
$x,t$ & Position and physical time & Metres; seconds when physical\
$d_\Omega,F$ & Exact signed distance; general field & Length; explicitly declared for $F$\
$\ell,r_0$ & Normalization and chart scales & Positive lengths\
$u,q_8,b$ & Normalized value, byte, sign bit & Dimensionless; integer; Boolean\
$\rho,\theta$ & Log-radius and angle & Dimensionless; radians\
$\phi_-,\varphi$ & Reciprocal golden ratio and golden ratio & Dimensionless design parameters\
$\mathcal T,t,T_\ast$ & Transformation, time, selected event & Operator; seconds; seconds\
$b_v,a_L,a_R$ & Eye baseline and ear positions & Metres\
$\operatorname{ITD}$ & Left-minus-right arrival difference & Seconds\
$c_s,c_0$ & Assumed sound speed; vacuum light speed & Metres per second\
$C_m,V,g_j$ & Capacitance, voltage, conductance & Consistent electrical units\
$H_N,\odot$ & Hadamard transform; elementwise product & Matrix; operation\
$\widehat{\mathcal H},\psi$ & Hamiltonian and quantum state & Energy operator; state amplitude\
$M,W,Z$ & Memory, coupling weights and activity & Defined by selected model\
$B,V_t,r_t$ & Self-model, value state and report & Latent/observed model variables\
$\mathcal C_{\rm op}$ & Proposed functional-access profile & Task-dependent measures\
:::

The growth code uses arbitrary simulation units. The separate eye--ear and crossing examples use declared physical units. Combining these examples into a real device or organism would require a calibrated common physical model. The current package does not perform that calibration.

# Reproduction and file guide

The archive includes the PDF, canonical LaTeX source, an editable Markdown conversion, bibliography, claim audit, experiment plan, original source, code, configuration, generated numerical outputs and a checksum manifest. The Markdown conversion is for convenient editing; the LaTeX source is the authoritative typeset version and retains equation labels and layout commands.

From the archive's `code/` directory, use:

    python -m pip install -r requirements.txt
    python -m unittest -v test_seed_field.py
    python demo.py --config seed.json --out ../outputs

The dependency installation may require network access; running the installed examples does not. For closest numerical reproduction, use the exact versions in `requirements-tested.txt`. The code targets Python 3.10 or later, but the recorded executed environment is the one specified in the results.

To regenerate the manuscript, use `manuscript/build.sh`, which calls the supplied demo, refreshes the figure PDFs and runs `pdflatex` twice. A TeX installation with the listed packages is required. No font files or third-party article PDFs are redistributed.

`SHA256SUMS.txt` records byte-level file integrity for the delivered package. It is a local integrity manifest, not independent timestamping, proof of authorship or authentication. The original source's checksum also appears in `provenance/source_manifest.json`.

# References and source notes {#references-and-source-notes .unnumbered}

References were checked online on 11 September 2026. Some publisher pages provided abstracts and bibliographic records rather than full text; the manuscript limits source-derived claims accordingly. The L-system chapter's definition page was also visually checked. This is a focused grounding bibliography, not a systematic literature review. None of these sources evaluates KSFF itself.

::: thebibliography
R12

Tom Klootwijk, supplied conversational notes. *Pasted markdown.md*. Undated uploaded source, received in the present conversation. Contains requester prompts and earlier AI-generated responses. Preserved verbatim in the companion archive; treated as conceptual provenance, not verified evidence.

Prusinkiewicz, P. and Lindenmayer, A. (1990). *The Algorithmic Beauty of Plants*. Springer. Chapter 1, "Graphical modeling using L-systems." Author-hosted electronic edition: <https://algorithmicbotany.org/papers/abop/abop-ch1.pdf>. Used for the parallel-rewriting/interpretation distinction and growth-language background; not evidence of consciousness.

Sellán, S., Batty, C. and Stein, O. (2023). *Reach For the Spheres: Tangency-Aware Surface Reconstruction of SDFs*. Author manuscript, arXiv:2308.09813. <https://arxiv.org/abs/2308.09813>. Supports the practical role of metric SDF properties in surface reconstruction; not universal field ontology.

Liu, S., Zhang, Y., Peng, S., Shi, B., Pollefeys, M. and Cui, Z. (2019). *DIST: Rendering Deep Implicit Signed Distance Function with Differentiable Sphere Tracing*. Author manuscript, arXiv:1911.13225. <https://arxiv.org/abs/1911.13225>. Supports a concrete numerical rendering method and its query/computation requirements.

Hodgkin, A. L. and Huxley, A. F. (1952). A quantitative description of membrane current and its application to conduction and excitation in nerve. *The Journal of Physiology*, 117, 500--544. [doi:10.1113/jphysiol.1952.sp004764](https://doi.org/10.1113/jphysiol.1952.sp004764). Used for continuous conductance-based electrical modelling, not a complete brain model.

Bliss, T. V. P. and Lømo, T. (1973). Long-lasting potentiation of synaptic transmission in the dentate area of the anaesthetized rabbit following stimulation of the perforant path. *The Journal of Physiology*, 232, 331--356. PubMed record: <https://pubmed.ncbi.nlm.nih.gov/4727084/>. Supports the specific potentiation result, not permanent geometric or holographic memory.

Liu, X. and colleagues (2012). Optogenetic stimulation of a hippocampal engram activates fear memory recall. *Nature*, 484, 381--385. [doi:10.1038/nature11028](https://doi.org/10.1038/nature11028). Used for a specific causal recall-related result in mice, not all human memory or a proposed intervention here.

Ernst, M. O. and Banks, M. S. (2002). Humans integrate visual and haptic information in a statistically optimal fashion. *Nature*, 415, 429--433. [doi:10.1038/415429a](https://doi.org/10.1038/415429a). Used for bounded evidence of reliability-sensitive cue integration in the reported task.

Critchley, H. D., Wiens, S., Rotshtein, P., Öhman, A. and Dolan, R. J. (2004). Neural systems supporting interoceptive awareness. *Nature Neuroscience*, 7, 189--195. [doi:10.1038/nn1176](https://doi.org/10.1038/nn1176). Used for the reported heartbeat-task relationships, not a universal definition of awareness.

Botvinick, M. and Cohen, J. (1998). Rubber hands 'feel' touch that eyes see. *Nature*, 391, 756. [doi:10.1038/35784](https://doi.org/10.1038/35784). Used as a bounded example of experimentally altered bodily experience.

Lin, X., Rivenson, Y., Yardimci, N. T., Veli, M., Jarrahi, M. and Ozcan, A. (2018). All-optical machine learning using diffractive deep neural networks. *Science*, 361, 1004--1008. [doi:10.1126/science.aat8084](https://doi.org/10.1126/science.aat8084). Author manuscript: <https://arxiv.org/abs/1804.08711>. Supports task-specific optical computation, not zero latency or universal passive implementation.

Albantakis, L. and colleagues (2023). Integrated information theory (IIT) 4.0: Formulating the properties of phenomenal existence in physical terms. *PLOS Computational Biology*, 19, e1011465. [doi:10.1371/journal.pcbi.1011465](https://doi.org/10.1371/journal.pcbi.1011465). Cited as a distinct formal theory, not an endorsement of its conclusions or of KSFF.

COGITATE Consortium (2025). Adversarial testing of global neuronal workspace and integrated information theories of consciousness. *Nature*, 642, 133--142. [doi:10.1038/s41586-025-08888-1](https://doi.org/10.1038/s41586-025-08888-1). Used for its preregistered comparative approach and its reported challenges to both theories, not evidence for the present proposal.
:::

End of research draft 1.0. Conceptual synthesis attributed to Tom Klootwijk. Formal additions, tests and interpretations are supplied for review and revision.
