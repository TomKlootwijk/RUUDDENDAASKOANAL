# Proposed research plan

These are hypotheses for future study, not experiments performed in this package.
They are derived from the proposed architecture and the manuscript's Section 10.
The mathematical demonstrations contain no participant or animal data.

## H1. Boundary metric information

Compare boundary distance, sampled occupancy and a non-field baseline on held-out
spatial prediction tasks, matching memory, training data and query budgets.
Predeclare the future boundary-crossing/contact prediction score and evaluation
split. Absence of a repeatable advantage weakens the claimed benefit of preserving
metric information. Synthetic success alone does not establish consciousness.

## H2. Recurrence and slow state

Compare the recurrent-plus-memory model with parameter-matched feedforward and
recurrent-without-slow-state alternatives on delayed or occluded observations.
Require out-of-sample prediction of independently observed response histories,
not merely agreement with the model's own next state. No improvement weakens the
claimed role of these particular recurrence and memory mechanisms.

## H3. Separate body calibration

Under a professionally reviewed multisensory protocol, calibrate eye and auditory
geometry independently. Compare the resulting prediction model against one that
forces a common calibration parameter. Predeclare localization or temporal-judgment
outcomes. This tests the interface choice, not sensory equivalence or freedom
from discomfort. The archive is not a participant stimulation specification.

## H4. Memory-mediated geometry feedback

Compare nonzero memory-to-field gain against zero gain while matching recurrent
capacity. Test independently specified adaptation or behavioral histories.
Equally good prediction by a generic hidden-state model leaves the claim that
memory needs a special geometric representation unsupported.

## H5. First-person and spiritual interpretation

Study voluntary descriptions of unity, meaning or connectedness using predeclared
coding categories and reliability checks. Preserve participants' own distinctions.
Associations would be between reports and measurements, not identification of an
immaterial entity or proof of an ontological identity. Seed labels cannot be used
to assign a person's spiritual standing or level of consciousness.

## Requirements before an empirical claim

Use independently reviewed protocols, informed participation, appropriate data
protection and sensory-safety oversight for any human study. Specify parameter
fitting, held-out evaluation, alternatives and failure criteria before confirmatory
analysis. A report readout must be defined and validated independently; the current
kernel has none. Do not retrospectively identify an arbitrary model coordinate
with conscious experience because its trajectory looks suggestive.

The external methodological example cited in the manuscript is Melloni et al.
(2023), DOI 10.1371/journal.pone.0268577. That protocol did not test this engine.
