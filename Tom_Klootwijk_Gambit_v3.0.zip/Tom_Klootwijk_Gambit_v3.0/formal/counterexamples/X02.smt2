; A field minimum does not automatically bridge separated components
(set-logic ALL)

(declare-const dot_distance Real) (declare-const stem_distance Real)
(assert (= dot_distance (/ 2 5))) (assert (= stem_distance (/ 1 4)))
(assert (> (ite (< dot_distance stem_distance) dot_distance stem_distance) 0))

(check-sat)
(get-model)
