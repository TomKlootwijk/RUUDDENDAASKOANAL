; K20: Nonnegative row-sum contraction bound
; Manuscript: L11. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(declare-const q Real)
(declare-const ez Real)
(declare-const em Real)
(declare-const e Real)
(assert (not (=> (and (>= a 0) (>= b 0) (>= e 0) (>= ez 0) (>= em 0) (<= ez e) (<= em e) (<= (+ a b) q) (< q 1)) (<= (+ (* a ez) (* b em)) (* q e)))))
(check-sat)
(get-proof)
