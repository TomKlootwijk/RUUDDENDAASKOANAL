"""Run with: python demo.py --config seed.json --out ../outputs.
All data are synthetic. Nothing is sent to an audio device or external hardware.
"""
from __future__ import annotations
import argparse, json, platform
from dataclasses import asdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from seed_field import *

def save_figure(fig, out: Path, name: str):
    fig.tight_layout()
    for extension in ('png','pdf','svg'):
        fig.savefig(out / f'{name}.{extension}',dpi=170,bbox_inches='tight')
    plt.close(fig)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path(__file__).with_name('seed.json'))
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'outputs')
    args=parser.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    cfg=GrowthConfig(**json.loads(args.config.read_text()))
    word,segments=grow(cfg)
    np.savetxt(args.out/'segments.csv',segments,delimiter=',',header='x0,y0,x1,y1,radius',comments='')
    (args.out/'lsystem_word.txt').write_text(word+'\n')
    ends=segments[:,:4].reshape(-1,2)
    low,high=ends.min(axis=0)-.2,ends.max(axis=0)+.2
    xs=np.linspace(low[0],high[0],150); ys=np.linspace(low[1],high[1],200)
    xx,yy=np.meshgrid(xs,ys); pts=np.stack([xx,yy],axis=-1)
    field=union_capsule_field(pts,segments)
    np.savetxt(args.out/'field_samples.csv',np.column_stack([xx.ravel(),yy.ravel(),field.ravel()]),
               delimiter=',',header='x,y,csg_union_field_not_exact_interior_sdf',comments='')
    fig,ax=plt.subplots(figsize=(7.1,5.3))
    ax.contour(xx,yy,field,levels=[0],linewidths=1.1)
    ax.set_aspect('equal'); ax.set_xlabel('x (simulation units)'); ax.set_ylabel('y (simulation units)')
    ax.set_title(f'Seeded L-system geometry: {len(segments)} capsules')
    save_figure(fig,args.out,'growth')
    n=4096; t=np.arange(n)
    u=.5+.38*np.sin(2*np.pi*t/1024)
    q8=quantize8(u); bits,residues=pulse_density(u)
    error=np.cumsum(bits-u)
    np.savetxt(args.out/'encoding.csv',np.column_stack([t,u,q8,bits,residues,error]),delimiter=',',
               header='sample,input,byte,pdm_bit,residue,cumulative_pdm_error',comments='')
    fig,ax=plt.subplots(figsize=(7.1,3.3))
    ax.plot(t,error,linewidth=.7)
    ax.set_xlabel('Sample index'); ax.set_ylabel('Cumulative count error')
    ax.set_title('Accumulator PDM: one-bit prefix bound, up to roundoff')
    save_figure(fig,args.out,'encoding_error')
    patterns=np.sign(walsh_hadamard(64)[1:5]); cue=patterns[0].copy()
    flipped=np.array([0,3,9,13,19,25,35,45]); cue[flipped]*=-1
    learned=learn_memory(patterns); final,energy=recall(learned,cue)
    np.savetxt(args.out/'memory_energy.csv',np.column_stack([np.arange(len(energy)),energy]),delimiter=',',
               header='asynchronous_update,dimensionless_energy',comments='')
    fig,ax=plt.subplots(figsize=(7.1,3.3))
    ax.plot(np.arange(len(energy)),energy)
    ax.set_xlabel('Asynchronous update'); ax.set_ylabel('Toy energy (dimensionless)')
    ax.set_title('Associative-memory demonstration: retrieval changes the state')
    save_figure(fig,args.out,'memory_energy')
    itd=interaural_time_difference(np.array([1.,0,2]),np.array([-.09,0,0]),np.array([.09,0,0]),343)
    root=bisect_root(lambda t: abs(-2+t)-1,0,1.5)
    metrics={
        'data_status':'Synthetic mathematical demonstrations; not biological or consciousness evidence',
        'configuration':asdict(cfg),'environment':{'python':platform.python_version(),'numpy':np.__version__,
        'matplotlib':matplotlib.__version__},'segment_count':len(segments),'symbol_count':len(word),
        'max_abs_byte_reconstruction_error':float(np.max(np.abs(q8/255-u))),
        'byte_error_bound':1/510,'max_abs_pdm_prefix_error':float(np.max(np.abs(error))),
        'pdm_mean_error':float(np.mean(bits-u)),'pdm_even_parity':even_parity(bits),
        'memory_bits':64,'stored_patterns':4,'cue_errors':int(np.count_nonzero(cue!=patterns[0])),
        'retrieved_errors':int(np.count_nonzero(final!=patterns[0])),
        'memory_energy_nonincreasing':bool(np.all(np.diff(energy)<=1e-10)),
        'itd_point_receiver_seconds':itd,'illustrative_visual_disparity_pixels':1000*.064/2,
        'bracketed_sphere_crossing_seconds':root,'optical_1mm_ng4_delay_seconds':4*.001/299792458,
        'same_seed_reproducible':bool(np.array_equal(segments,grow(cfg)[1]))
    }
    (args.out/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    summary='''# Synthetic demonstration results\n\nThese are generated numerical examples, not measurements of people, consciousness, spirituality, or hardware speed.\n\n'''
    summary+='```json\n'+json.dumps(metrics,indent=2)+'\n```\n'
    (args.out/'results.md').write_text(summary)
    print(json.dumps(metrics,indent=2))

if __name__=='__main__': main()
