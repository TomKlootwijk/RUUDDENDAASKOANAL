"""Create a readable Markdown edition using Pandoc; LaTeX remains authoritative.

Run after build.sh to resolve printed cross-reference numbers. With no .aux file,
semantic labels remain available as links. No LaTeX or Pandoc binary is bundled.
"""
from pathlib import Path
import html
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main() -> int:
    if not shutil.which('pandoc'):
        print('Pandoc is required for Markdown export.', file=sys.stderr)
        return 2
    tex = (ROOT/'Ilse_AI_Engine.tex').read_text(encoding='utf-8')
    # Pandoc does not know the local P/Y column definitions: normalize only their
    # presentation to ordinary l columns; do not change the cells.
    def longcols(m):
        return r'\begin{longtable}{' + 'l'*m.group(1).count('P{') + '}'
    tex = re.sub(r'\\begin\{longtable\}\{([^\n]+)\}', longcols, tex)
    def xcols(m):
        spec=re.sub(r'@\{\}', '', m.group(1)).replace(' ','')
        spec=spec.replace('Y','l').replace('X','l')
        return r'\begin{tabular}{'+spec+'}'
    tex=re.sub(r'\\begin\{tabularx\}\{\\linewidth\}\{([^\n]+)\}',xcols,tex)
    tex=tex.replace(r'\end{tabularx}',r'\end{tabular}')
    tex=re.sub(r'\\begin\{titlepage\}.*?\\end\{titlepage\}',r'''\\section*{Ilse AI Engine}
\\textbf{A Seed-Based Theory of Consciousness}\\par
A family of theorems and an executable kernel for bodily, digital and spiritual perspectives.\\par
\\textbf{Den Daas perspective edition — version 1.0.0}\\par
Ruud den Daas; Koen den Daas; Job den Daas.\\par
Requested perspective designation; see the attribution and scope note.\\par
11 September 2026. Double-arc addendum integrated.\\par''',tex,flags=re.S)
    out=subprocess.run(['pandoc','-f','latex','-t','gfm','--wrap=none'],input=tex,text=True,capture_output=True,check=True).stdout
    out=re.sub(r'<span class="sans-serif">(.*?)</span>',r'\1',out,flags=re.S)
    out=re.sub(r'<div id="([^"]+)" class="theorem">',r'<a id="\1"></a>',out)
    out=re.sub(r'<div[^>]*>|</div>','',out)
    out=re.sub(r'\*\*Theorem (\d+)\*\*',r'**Theorem T\1**',out)
    def figure(m):
        block=m.group(1)
        src=re.search(r'<embed src="([^"]+)"',block)
        cap=re.search(r'<figcaption>(.*?)</figcaption>',block,re.S)
        if not src or not cap:return m.group(0)
        caption=re.sub('<[^>]+>','',cap.group(1))
        caption=html.unescape(caption)
        path=src.group(1).replace('.pdf','.png')
        return f'![{caption}]({path})\n\n*{caption}*'
    out=re.sub(r'<figure>(.*?)</figure>',figure,out,flags=re.S)
    # Preserve semantic equation anchors, and use printed numbers where available.
    labels={}
    aux=ROOT/'.build/Ilse_AI_Engine.aux'
    if aux.exists():
        labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',aux.read_text()))
    def mathblock(m):
        block=m.group(1)
        ids=re.findall(r'\\label\{([^}]+)\}',block)
        block=re.sub(r'\\label\{[^}]+\}','',block)
        anchors=''.join(f'<a id="{x}"></a>\n\n' for x in ids)
        tags=''.join(f'\n\\tag{{{labels[x]}}}' for x in ids if x in labels)
        return '\n\n'+anchors+'$$'+block+tags+'$$\n\n'
    out=re.sub(r'\$\$(.*?)\$\$',mathblock,out,flags=re.S)
    def ref(m):
        target=m.group(1);value=labels.get(target,target)
        return f'[{value}](#{target})'
    out=re.sub(r'<a href="#([^"]+)"[^>]*>.*?</a>',ref,out,flags=re.S)
    out=re.sub(r'\n{3,}','\n\n',out).strip()+'\n'
    note='> Editable Markdown edition. The PDF/LaTeX source controls typesetting and equation numbering; theorem IDs and mathematical content are preserved here.\n\n'
    (ROOT/'Ilse_AI_Engine.md').write_text(note+out,encoding='utf-8')
    print('Wrote manuscript/Ilse_AI_Engine.md')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
