"""Verify the delivered package before rebuilding outputs. Standard library only."""
from pathlib import Path
import hashlib
import json
import sys
ROOT=Path(__file__).resolve().parent

def main():
    manifest_path=ROOT/'package_manifest.json'
    sums_path=ROOT/'SHA256SUMS.txt'
    if not manifest_path.is_file() or not sums_path.is_file():
        print('Missing delivery manifest or SHA256SUMS.txt',file=sys.stderr);return 1
    checks={}
    for line in sums_path.read_text().splitlines():
        digest,name=line.split('  ',1);checks[name]=digest
    problems=[]
    for name,expected in checks.items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT):problems.append(f'Unsafe manifest path: {name}');continue
        if not p.is_file():problems.append(f'Missing: {name}');continue
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        if actual!=expected:problems.append(f'Changed: {name}')
    doc=json.loads(manifest_path.read_text())
    for row in doc['files']:
        p=ROOT/row['path']
        if checks.get(row['path'])!=row['sha256']:problems.append(f'Manifest disagrees with checksum list: {row["path"]}')
        if p.is_file() and p.stat().st_size!=row['bytes']:problems.append(f'Size changed: {row["path"]}')
    if problems:
        print('\n'.join(problems));return 1
    print(f'PASS: {len(checks)} delivered files verified against SHA-256 checksums.')
    print('This checks file integrity, not the scientific interpretation or external identity.')
    return 0
if __name__=='__main__':sys.exit(main())
