; K25: Reversible reaction is nonnegative under the step bound
; Manuscript: L6. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const dt Real)
(declare-const a Real)
(declare-const b Real)
(declare-const u Real)
(declare-const v Real)
(assert (not (=> (and (>= dt 0) (>= a 0) (>= b 0) (>= u 0) (>= v 0) (<= (* dt a) 1) (<= (* dt b) 1)) (and (>= (+ (* (- 1 (* dt a)) u) (* dt b v)) 0) (>= (+ (* dt a u) (* (- 1 (* dt b)) v)) 0)))))
(check-sat)
(get-proof)
