# Delivery checks

Research draft 1.0, 11 September 2026.

- Final manuscript: 28 A4 pages with searchable/selectable text and linked contents.
- All pages were rendered and reviewed at contact-sheet scale; selected pages, including the cover, equations and references, were reviewed at full-page scale.
- The final LaTeX build reported no overfull/underfull boxes, unresolved references or warnings.
- All 17 included unit tests passed in the delivered environment.
- The original uploaded Markdown is preserved byte for byte; its SHA-256 value is recorded in the provenance manifest.
- The archive has local SHA-256 checksums. These attest only to byte consistency, not scientific validity or independent authorship.

This review is a layout and reproducibility check, not peer review, biological validation, a hardware benchmark or evidence of consciousness.
