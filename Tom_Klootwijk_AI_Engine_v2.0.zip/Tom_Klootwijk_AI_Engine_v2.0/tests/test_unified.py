"""Executed counterchecks of the composition theorem's finite implementation."""
import dataclasses
import json
import math
from pathlib import Path
import tempfile
import unittest
import numpy as np
from scipy import sparse
from kernel.transport import Grid,Graph,transport_step,reaction_step,conservative_remap
from kernel.unified import ModelSpec,UnifiedKernel
from kernel.coding import DyadicAccumulator
from kernel.events import toy_field,event_roots,PHI_MINUS
from kernel.core import fwht,capsule_field

class GraphTests(unittest.TestCase):
    def setUp(self):
        self.grid=Grid.regular(-.4,.4,0,.8,.2)
        self.mask=np.ones(len(self.grid.points),bool)
    def test_grid_area(self): self.assertAlmostEqual(self.grid.volume,.04)
    def test_grid_bad_spacing(self):
        with self.assertRaises(ValueError): Grid.regular(0,1,0,1,.3)
    def test_grid_budget(self):
        with self.assertRaises(ValueError): Grid.regular(h=.04,max_nodes=2)
    def test_empty_mask(self):
        with self.assertRaises(ValueError): Graph.build(self.grid,np.zeros(len(self.mask)))
    def test_generator_columns_zero(self):
        Q=Graph.build(self.grid,self.mask,.4,.2).generator(.1)
        np.testing.assert_allclose(np.asarray(Q.sum(axis=0)),0,atol=1e-14)
    def test_diffusion_symmetric(self):
        Q=Graph.build(self.grid,self.mask).generator(.1)
        np.testing.assert_allclose(Q.toarray(),Q.T.toarray(),atol=0)
    def test_diffusion_constant(self):
        Q=Graph.build(self.grid,self.mask).generator(.1)
        np.testing.assert_allclose(Q@np.ones(len(self.mask)),0,atol=1e-14)
    def test_diffusion_energy(self):
        g=Graph.build(self.grid,self.mask,.6);Q=g.generator(.1)
        x=np.random.default_rng(2).normal(size=len(self.mask))
        energy=-.1/self.grid.h**2*np.sum(g.gate*(x[g.source]-x[g.target])**2)
        self.assertAlmostEqual(float(x@(Q@x)),energy)
    def test_gate_zero_closes_edges(self):
        g=Graph.build(self.grid,self.mask,gate=0);Q=g.generator(.1)
        a=self.grid.points[:,0]<0;b=~a
        self.assertEqual(float(Q[np.ix_(a,b)].sum()),0)
    def test_transport_nonnegative_mass(self):
        Q=Graph.build(self.grid,self.mask,.4,.2).generator(.1)
        m=np.arange(len(self.mask),dtype=float)
        out,info=transport_step(m,Q,5)
        self.assertGreaterEqual(np.min(out),0);self.assertAlmostEqual(out.sum(),m.sum(),places=9)
        self.assertGreater(info['substeps'],1);self.assertLessEqual(info['max_cfl'],.9+1e-14)
    def test_transport_l1_nonexpansive(self):
        Q=Graph.build(self.grid,self.mask,.4,.2).generator(.1)
        rng=np.random.default_rng(3);a=rng.random(len(self.mask));b=rng.random(len(self.mask))
        aa,_=transport_step(a,Q,.2);bb,_=transport_step(b,Q,.2)
        self.assertLessEqual(np.sum(abs(aa-bb)),np.sum(abs(a-b))+1e-12)
    def test_masked_nodes_are_zero(self):
        mask=self.mask.copy();mask[:5]=False;Q=Graph.build(self.grid,mask).generator(.1)
        out,_=transport_step(mask.astype(float),Q,.5)
        self.assertTrue(np.all(out[~mask]==0))
    def test_non_generator_rejected(self):
        with self.assertRaises(ValueError): transport_step(np.ones(2),sparse.eye(2,format='csr'),.1)
    def test_budget_rejected(self):
        Q=Graph.build(self.grid,self.mask).generator(5)
        with self.assertRaises(ValueError): transport_step(np.ones(len(self.mask)),Q,10,max_substeps=1)
    def test_reaction_conserves_locally(self):
        u=np.arange(8.);v=np.arange(8.)[::-1]
        a,b=reaction_step(u,v,.4,.2,20)
        np.testing.assert_allclose(a+b,u+v,atol=1e-13)
        self.assertGreaterEqual(min(a.min(),b.min()),0)
    def test_reaction_no_negative_inputs(self):
        with self.assertRaises(ValueError): reaction_step(np.array([-1.]),np.array([2.]),.1,.2,.1)
    def test_remap_conserves_and_positive(self):
        old=self.mask;new=old.copy();new[:10]=False;m=np.arange(len(old),dtype=float)
        out=conservative_remap(m,old,new,self.grid.points)
        self.assertEqual(out.sum(),m.sum());self.assertTrue(np.all(out[~new]==0))
    def test_remap_expansion_adds_no_mass(self):
        old=self.mask.copy();old[:10]=False;m=old.astype(float)
        out=conservative_remap(m,old,self.mask,self.grid.points)
        np.testing.assert_array_equal(m,out)
    def test_remap_rejects_hidden_mass(self):
        old=self.mask.copy();old[0]=False
        with self.assertRaises(ValueError): conservative_remap(np.ones(len(old)),old,self.mask,self.grid.points)
    def test_remap_tie_uses_index(self):
        p=np.array([[-1.,0],[0,0],[1,0]])
        o=conservative_remap(np.array([0.,2.,0.]),[0,1,0],[1,0,1],p)
        np.testing.assert_array_equal(o,[2,0,0])
    def test_generator_permutation(self):
        Q=Graph.build(self.grid,self.mask,.5,.2).generator(.1).toarray()
        rng=np.random.default_rng(7);p=rng.permutation(len(self.mask));x=rng.random(len(self.mask))
        np.testing.assert_allclose(Q[np.ix_(p,p)]@x[p],(Q@x)[p],atol=1e-14)

class NewAlgebraTests(unittest.TestCase):
    def test_integer_codec_exhaustive_short_words(self):
        import itertools
        for word in itertools.product(range(5),repeat=4):
            a=DyadicAccumulator(bits=2)
            for k in word:
                self.assertIn(a.push_integer(k),(0,1));self.assertTrue(a.certificate())
                self.assertTrue(-1<a.discrepancy<=0)
    def test_codec_random_prefixes(self):
        rng=np.random.default_rng(44);a=DyadicAccumulator()
        for k in rng.integers(0,a.denominator+1,5000):
            a.push_integer(int(k));self.assertTrue(a.certificate())
    def test_codec_endpoints(self):
        a=DyadicAccumulator();self.assertEqual(a.push(0)[0],0);self.assertEqual(a.push(1)[0],1)
    def test_codec_rounding_error(self):
        a=DyadicAccumulator(bits=10)
        for value in np.linspace(0,1,1000):
            _,k=a.push(value);self.assertLessEqual(abs(k/a.denominator-value),1/(2*a.denominator)+1e-15)
    def test_codec_rejects_invalid(self):
        for value in [-1,math.inf,math.nan,1.01]:
            with self.assertRaises(ValueError): DyadicAccumulator().push(value)
    def test_time_roots_both_variants(self):
        for k in [.5,1.0]:
            roots,status=event_roots(1.1,k,r0=.3,speed=2,t0=4)
            self.assertEqual(status,'regular');self.assertEqual(len(roots),4)
            for r in roots:
                self.assertLess(abs(toy_field(r.rho,1.1,k)),1e-12)
                self.assertAlmostEqual(math.log((r.time-4)*2/.3),r.rho)
    def test_time_reciprocity(self):
        roots,_=event_roots(1.1)
        self.assertAlmostEqual(roots[0].time*roots[1].time,1)
        self.assertAlmostEqual(roots[2].time*roots[3].time,1)
    def test_half_angle_mismatch_is_real(self):
        wrong=PHI_MINUS/math.sin(1.1)
        self.assertGreater(abs(toy_field(wrong,1.1,.5)),.01)
    def test_root_singular_absent(self):
        r,s=event_roots(0);self.assertEqual(len(r),2);self.assertEqual(s,'outer-absent-at-exact-zero')
    def test_root_near_singular_unresolved(self):
        r,s=event_roots(1e-14);self.assertEqual(len(r),2);self.assertIn('unresolved',s)
    def test_root_overflow_keeps_log(self):
        r,s=event_roots(.0001);self.assertTrue(any(x.time is None and math.isfinite(x.log_delay) for x in r))
    def test_hadamard_accepts_asymmetry(self):
        x=np.array([1.,0,0,0]);np.testing.assert_allclose(fwht(fwht(x)),x)
    def test_local_geometry_edit_is_defined(self):
        s=np.array([[[-1.,0],[0,1]],[[1.,0],[0,1]]]);p=np.array([[0.,0],[1.,1]])
        a=capsule_field(p,s);b=capsule_field(p,s[:1]);self.assertTrue(np.all(np.isfinite(b)))
        self.assertTrue(np.all(b>=a))
    def test_linear_reaction_diffusion_spectrum(self):
        for lam in np.linspace(0,200,40):
            R=np.array([[-.24-.05*lam,.12],[.24,-.12-.025*lam]])
            self.assertLessEqual(np.max(np.linalg.eigvals(R).real),1e-14)

class CompositionTests(unittest.TestCase):
    def test_config_roundtrip(self):
        s=ModelSpec()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';s.save(p);self.assertEqual(ModelSpec.load(p),s)
    def test_config_grammar_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';ModelSpec().save(p);data=json.loads(p.read_text());data['grammar']['X']='Y';p.write_text(json.dumps(data))
            with self.assertRaises(ValueError): ModelSpec.load(p)
    def test_identity_not_numerical_seed(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';s=ModelSpec();s.save(p);a=ModelSpec.load(p)
            data=json.loads(p.read_text());data['author']={'name':'different narrative'};p.write_text(json.dumps(data));b=ModelSpec.load(p)
            self.assertEqual(a,b);self.assertEqual(UnifiedKernel(a).fingerprint(),UnifiedKernel(b).fingerprint())
    def test_replay_bit_identical(self):
        s=ModelSpec(steps=8);a=UnifiedKernel(s);b=UnifiedKernel(s)
        aa,ar=a.run();bb,br=b.run()
        self.assertEqual(ar,br);np.testing.assert_array_equal(aa.u,bb.u);np.testing.assert_array_equal(aa.memory,bb.memory)
    def test_full_loop_invariants_and_growth(self):
        k=UnifiedKernel(ModelSpec(pair='XX'));initial=k.initial_state();state,rows=k.run()
        m0=float(sum(initial.u+initial.v))
        self.assertTrue(all(abs(r['mass']-m0)<1e-12 for r in rows))
        self.assertTrue(all(r['min_mass']>=0 and r['z_max']<=1 and r['memory_max']<=1 for r in rows))
        self.assertTrue(all(r['frame_even'] and r['codec_certificate'] for r in rows))
        self.assertEqual([r['step'] for r in rows if r['growth']],[31,61,91])
    def test_pair_can_change_mask(self):
        a=UnifiedKernel(ModelSpec(pair='XX'));b=UnifiedKernel(ModelSpec(pair='XY'))
        fa=a.field(a.grid.points,4,np.zeros(3));fb=b.field(b.grid.points,4,np.zeros(3))
        self.assertTrue(np.any((fa<=0)!=(fb<=0)))
    def test_distinct_seeds_not_injective(self):
        a=UnifiedKernel(ModelSpec(pair='XX'));b=UnifiedKernel(ModelSpec(pair='XY'))
        np.testing.assert_array_equal(a.initial_state().mask,b.initial_state().mask)
    def test_state_input_not_mutated(self):
        k=UnifiedKernel(ModelSpec(steps=2));s=k.initial_state();old=s.copy();new,_=k.advance(s)
        np.testing.assert_array_equal(s.u,old.u);self.assertEqual(s.accumulator.count,0);self.assertEqual(new.accumulator.count,1)
    def test_invalid_parameters(self):
        for kwargs in [dict(dt=0),dict(gate_gain=2),dict(max_generation=9),dict(omega=math.nan),dict(codec_bits=0)]:
            with self.assertRaises(ValueError): ModelSpec(**kwargs)

if __name__=='__main__': unittest.main(verbosity=2)
