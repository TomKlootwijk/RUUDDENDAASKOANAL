# KSFF research plan — proposed, not executed

## Claim hierarchy

The included numerical demonstration checks implementation properties only.
Representational advantages, biological validity, phenomenal consciousness and
spiritual ontology are different claims. Evidence for one does not automatically
establish another. The manuscript's Section 14 contains the full H1–H7 proposals.

## Registration fields required before a confirmatory study

Record the exact claim, model version, dataset or recruitment plan, inclusion
and exclusion rules, primary outcome, minimally meaningful effect, uncertainty
estimation, baseline models, capacity/cost matching, planned ablations, stopping
rule, missing-data treatment and multiplicity correction. Choose sample size
using an appropriate prospective power or precision analysis rather than a
number invented after viewing outcomes. Keep pilot data distinct from a locked
confirmatory evaluation. Store failed as well as successful trials.

## H1 — Distance versus finite occupancy

Compare true/controlled approximate signed distance, occupancy, mesh or analytic
geometry, and matched-capacity learned implicit alternatives. Use independent
shapes and trajectories, including thin features and tangencies. Outcomes:
geometry error, crossing-time error, memory, construction time and query cost.
A claimed benefit fails when it disappears after resources are matched or is
explained by extra precision. This is an engineering/representation test.

## H2 — Independent eye and ear calibration

First test parameter identifiability on simulated observations. Compare a shared
scene with distinct eye and ear observation maps to a model collapsing their
calibration. A later human study would require consent, appropriate ethics
review, ordinary non-aversive stimuli, counterbalancing and an approved stopping
procedure. Do not infer an individualized acoustic transfer function from eye
separation alone. Outcomes: held-out localization error and calibrated uncertainty.

## H3 — Persistent memory parameters

Compare intact, reset, frozen and shuffled memory, with appropriate sham changes
and equal compute. Include acquisition, interference and retention tests with
unseen cues. Selective loss of learned behaviour is the intended prediction;
a complete system failure is not a selective memory effect. No performance
change implies the chosen variable was not shown necessary for that task.

## H4 — Recurrent self-model

Define the self-model variable before training. Match capacity and exposure
against a recurrent model lacking the targeted component. Test confidence
calibration, agency discrimination or cross-modal transfer, with one declared
primary outcome. Disconnecting generic compute is not an informative self-model
ablation. Successful functions do not certify digital sentience. A human's
inability to report is not, by itself, evidence of absent experience.

## H5 — Coordinate/LUT tradeoff

Compare Cartesian and log-polar allocation, direct computation and relevant
indices at matched physical error. Include origin and angle-seam handling,
lookup construction, interpolation, updates, memory and conversion costs. Report
latency distributions and throughput separately. This study has not been
implemented by the present code.

## H6 — Optional privileged phi hypothesis

Only assert this claim if the author deliberately adopts it. Specify a predicted
quantity and independently held-out data. Compare the reciprocal golden ratio
with preregistered nearby values and a freely fitted parameter. Avoid selecting
favourable patterns from many unreported possibilities. Similar or superior
ordinary fitted scales reject privileged status in that setting.

## H7 — First-person meaning

Use voluntary non-leading reports and transparent, preregistered coding. Retain
qualitative accounts alongside numerical categories. Control expectation and
task-demand explanations. An association between reports and bodily or task
variables does not establish a nonphysical field, and an absence of association
does not eliminate a person's spiritual meaning. No such participant data are
included in this archive.

## Reporting template

For every study, publish the hypothesis, assumptions, materials, algorithm and
version, complete exclusion accounting, primary and secondary outcomes,
uncertainty intervals, baseline comparisons, ablations, failed tests, limitations,
and a statement identifying which claim level the evidence actually concerns.
Do not retrofit a new definition of success after observing the result.
