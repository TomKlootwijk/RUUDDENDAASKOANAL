"""Tom Klootwijk Gambit: Unified Seed--Field Engine, edition 3.0."""
__version__ = "3.0.0"
