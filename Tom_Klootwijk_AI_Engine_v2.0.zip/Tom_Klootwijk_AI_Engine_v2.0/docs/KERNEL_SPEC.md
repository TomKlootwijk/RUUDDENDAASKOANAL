# Executable kernel contract

## Objects and types

The numerical seed is `ModelSpec`, loaded from a strict `ksfe-seed-2.0` JSON schema. `author`, `engine` and `scope` are documentary fields. `grammar` must exactly match the complete production map. `model` contains every adjustable numeric parameter; initialization/probe laws and matrix normalization constants are part of versioned code. The configuration fingerprint hashes the model, grammar, PCG64 convention and realized recurrent matrices. Package hashes additionally cover all code bytes.

`UnifiedState.u` and `.v` are nonnegative per-node simulation mass, not concentration, probabilities or neural activations. `Grid.volume = h^2` converts to/from concentration on the equal-area grid. `.mask` is the domain used in the stored prior update. `.z` and `.memory` are three-component dimensionless recurrent variables. `.generation`, `.last_growth` and `.step` are finite integers. `.accumulator` contains exact integer coding state.

## Geometry and ambient field

The ambient model is Euclidean R^2. A finite window discretizes only a portion of it. The smooth ambient velocity law is `omega * (-y, x)`; local SDF masks do not define its global domain. The L-system is X -> X[+X]Y and Y -> Y[-Y]X, with identity rules on turns and brackets. The pair axiom is [a][b]. Geometry is the clipped union of double arcs, a baseline and generated capsule strokes. Composite fields are 1-Lipschitz and sign-correct; they are not promised to be exact signed distances inside overlaps.

The default v2 embedding scale is 1.0, translation (0, 0.10), turtle step 0.12, shrink 0.72 and angle pi/7. Arc stroke thickness is 0.105 + 0.025*tanh(m[0]); capsule thickness is 0.045. Default arcs have radius and spacing 1.0. XX and XY are symbolic tokens, not a genetic or consciousness classification.

## One macro step

1. On the stored mask, compute the maximum U/(U+V) fraction at graph-boundary nodes. Zero total at a node yields zero. A threshold/dwell/budget predicate permits at most one rewrite.
2. Compile the selected generation using the old memory. Build its new grid mask.
3. Keep mass on retained nodes. Transfer removed-node mass to the nearest new active node, with smallest-index tie break. New nodes receive no fresh material. An empty mask is an error.
4. Assemble a column generator for each species: nonnegative off-diagonal incoming rates, diagonal minus total outgoing rate, zero column sums. The x=0 interface has gate 0.65 + 0.15*tanh(m[1]). Absent exterior edges form a closed graph.
5. Substep transport so dt_sub * maximum_exit_rate <= 0.9. Apply nonnegative sparse transition matrices directly. No clipping of negative masses is used.
6. Apply positive reversible U <-> V conversion with rates 0.24 and 0.12, substepping as needed. This law preserves total simulation mass; it is not actual molecular chemistry.
7. Evaluate three prescribed probes. Observation is 0.6*(-tanh(field)) + 0.4*(2*global_U_fraction - 1). Use fraction 1/2 for zero total mass. Apply the bounded fast/slow recurrence with alpha=0.4 and eta=0.08.
8. Convert (1+mean(z_new))/2 to a 16-bit dyadic value by explicit nearest-half-up conversion. The integer accumulator emits one pulse with an exact prefix certificate. Store occupancy, pulse and even parity separately.
9. Store updated state and mask. The new memory influences the next compilation, not the already completed material update.

`advance` returns a new state and does not mutate its input. The default grid is 61 by 31, h=0.08; the macro step is 0.04 and there are 120 steps. The growth dwell is 30 and threshold 0.55. Starting generation is one, with maximum four. All remaining defaults are in the seed JSON files.

## Auxiliary modules, not hidden feedback

`KlootwijkKernel` in core.py retains the intermediate three-fast/three-slow geometry-only recurrence for the conditional contraction demonstration. Its q=0.94464 is NOT a global contraction factor for `UnifiedKernel`.

`events.py` defines the full-angle (kappa=1) and half-angle (kappa=1/2) auxiliary polynomial. Its analytic roots are diagnostic functions, not the material solver's growth law or a fertilization model. Zero denominator, near-singular unresolved denominator and exponent overflow are distinct statuses. General bisection requires a valid sign bracket and does not claim to find tangent roots.

`LogPolarLUT` is a finite annular approximation storing Cartesian field values with a conservative corner-distance certificate. `CapsuleBVH` is a spatial acceleration utility. `stereo_eyes` and `itd_seconds` are toy length/time interfaces, not anatomy calibration. `fwht` is a real normalized Walsh-Hadamard transform. `bernoulli_encode` is a separate classical threshold utility; it is not used as proof of a blue-noise spectrum.

## Mathematical trust boundary

Real-arithmetic graph conservation and positivity follow from U1 and L5–L7. Finite floating-point traces are compared with tolerances. Dyadic codec certificates use Python integers and are exact for the k values produced. Source-to-dyadic rounding is a separate operation. Full hybrid contraction, continuum convergence, physiological fidelity, Turing-pattern formation, infinite precision, optical latency and conscious experience are not implemented guarantees.

Every new reaction law, grammar, remap, open boundary or coordinate quotient needs a revised contract and matching tests. A raw source assertion does not supply one.
