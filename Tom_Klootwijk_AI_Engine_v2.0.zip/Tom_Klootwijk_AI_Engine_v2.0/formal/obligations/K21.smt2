; K21: Two-node diffusion generator conserves total mass
; Manuscript: L5. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const w Real)
(declare-const x Real)
(declare-const y Real)
(assert (not (= (+ (* w (- y x)) (* w (- x y))) 0)))
(check-sat)
(get-proof)
