# Tom Klootwijk AI Engine — Unified Research Edition 2.0

**Author: Tom Klootwijk · NL200678942 · 10-07-1990**

The PDF and its editable manuscript formulate one unified seed-field composition theorem with twelve supporting lemmas. The kernel implements symbolic XX/XY L-system growth; capsule/double-arc fields; a finite gated diffusion/advection graph; conservative remapping; reversible reaction; bounded recurrence and memory; and exact integer pulse-density coding.

## Read first

- `Tom_Klootwijk_AI_Engine.pdf`: the author-attributed manuscript.
- `docs/UNIFIED_THEOREM.md`: extracted theorem, assumptions and proof.
- `docs/KERNEL_SPEC.md`: implemented model, types, ordering, defaults and scope.
- `docs/claim_audit.csv`: 48 page-specific source dispositions.
- `results/VERIFICATION_SUMMARY.md`: executed checks and numerical outcomes.

The theorem proves properties of a declared computation. It does not prove that the engine is conscious, that chromosomes determine awareness, or that the corpus's biological/spiritual interpretations are empirical findings. Raw source conversations are preserved as provenance, not endorsement. The new source's inconsistent event equations are maintained as distinct full-angle and half-angle polynomial variants.

## Reproduce

Run these commands from the extracted package root, using an environment with Python and the pinned numerical dependencies:

```bash
python verify_package.py
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m kernel.demo
python formal/check.py
bash manuscript/build.sh
```

The full delivery was tested on Python 3.13.5. Other Python/library/platform combinations were not verified. The formal step needs an installed Z3 executable or shared library. Set `Z3_LIBRARY` to the library path when automatic discovery fails. No solver binary is included. PDF rebuilding requires a LaTeX installation and the packages named in the `.tex` preamble; no font files are included. Optional Markdown regeneration uses `python manuscript/export_markdown.py` and requires Pandoc.

For one run:

```bash
python -m kernel.demo --config config/seed_xy.json --out rerun_xy
```

For a smaller experiment, edit the `model` values in a copied configuration. The supplied version accepts only its complete declared grammar; an unsupported production change is rejected, not silently ignored. A new grammar requires an interpreter/model revision and new proofs/tests.

## Package map

`kernel/` is executable source. `config/` has the two full seeds. `tests/` has 99 regression tests. `formal/` contains 34 inspectable SMT-LIB counterexample queries and the solver runner. `results/` holds complete numerical histories, CSV data, final fields, fingerprints, test output and solver proof logs. `manuscript/` contains authoritative LaTeX, an editable Markdown reading edition, a bibliography and figure PDF/PNG/SVG files. `docs/` contains the theorem, audit, specification and research plan. `sources/` preserves C0/C1/C2/C4 unchanged. `provenance/` records the lineage and hashes of all supplied inputs.

## Recorded verification

99 tests passed. Z3 4.13.3.0 returned UNSAT on all 34 negated algebraic obligations and emitted proof logs. U1/L1–L12 are written proofs, not a complete proof-assistant verification of the Python program. No independent replay of the Z3 proof objects is claimed.

Both default runs execute 120 steps. The largest recorded total-mass drift is approximately 1.832e-15 simulation-mass units. Nonnegativity, recurrent bounds, exact dyadic prefix certificates and even-parity frames hold in the disclosed runs. XX grows at steps 31, 61 and 91; XY grows at steps 31 and 61 and stops at generation three because its later score is below threshold. These are synthetic outcomes, not biological classifications.

## Checksums and privacy

Run `verify_package.py` before regenerating outputs. Rebuilding figures/PDFs may alter timestamps and hashes even with equivalent numerical results. Same-environment numerical replay is distinct from cross-platform or artifact-byte identity. The archive contains supplied personal details; review `ATTRIBUTION_AND_SCOPE.md` and the raw sources before sharing publicly.
