; K02: Symbol exchange is an involution
; Manuscript: T1. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Bool)
(declare-const b Bool)
(assert (not (and (= (not (not a)) a) (= (not (not b)) b))))
(check-sat)
(get-proof)
