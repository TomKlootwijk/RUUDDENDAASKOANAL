"""Generate reviewable SMT-LIB counterexample queries for the discrete core.

A query being unsatisfiable establishes its stated identity/implication in the
encoded mathematical theory. It is not a proof of the numerical Python program.
"""
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
OBLIGATIONS=[]
def add(id,title,theorem,decl,formula):
    OBLIGATIONS.append(dict(id=id,title=title,theorem=theorem,declarations=decl,formula=formula))
B='(declare-const a Bool)\n(declare-const b Bool)\n'
R='(declare-const a Real)\n(declare-const b Real)\n'
minimum='(define-fun mn ((x Real) (y Real)) Real (ite (<= x y) x y))\n'
maximum='(define-fun mx ((x Real) (y Real)) Real (ite (>= x y) x y))\n'
absolute='(define-fun ab ((x Real)) Real (ite (>= x 0) x (- x)))\n'
add('K01','Pair parity is exchange-invariant','T1',B,'(= (xor a b) (xor b a))')
add('K02','Symbol exchange is an involution','T1',B,'(and (= (not (not a)) a) (= (not (not b)) b))')
add('K03','Boolean sorted-pair canonicalization is idempotent','T1',B,'(and (= (and (and a b) (or a b)) (and a b)) (= (or (and a b) (or a b)) (or a b)))')
add('K04','Growth count update triples the sum','T3','(declare-const x Int)\n(declare-const y Int)\n','(= (+ (+ (* 2 x) y) (+ x (* 2 y))) (* 3 (+ x y)))')
add('K05','Growth count update preserves the difference','T3','(declare-const x Int)\n(declare-const y Int)\n','(= (- (+ (* 2 x) y) (+ x (* 2 y))) (- x y))')
add('K06','Minimum is closed-set union at zero','T5',R+minimum,'(= (<= (mn a b) 0) (or (<= a 0) (<= b 0)))')
add('K07','Maximum is closed-set intersection at zero','T5',R+maximum,'(= (<= (mx a b) 0) (and (<= a 0) (<= b 0)))')
add('K08','Ground clipping equals membership and y nonnegative','T5','(declare-const f Real)\n(declare-const y Real)\n'+maximum,'(= (<= (mx f (- y)) 0) (and (<= f 0) (>= y 0)))')
add('K09','Minimum preserves a shared Lipschitz difference bound','T6',R+'(declare-const c Real)\n(declare-const d Real)\n(declare-const e Real)\n'+minimum+absolute,'(=> (and (>= e 0) (<= (ab (- a c)) e) (<= (ab (- b d)) e)) (<= (ab (- (mn a b) (mn c d))) e))')
add('K10','Near-side reflection distance comparison','T7','(declare-const x Real)\n(declare-const u Real)\n','(=> (and (>= x 0) (>= u 0)) (<= (* (- x u) (- x u)) (* (+ x u) (+ x u))))')
add('K11','Reflection preserves squared Euclidean norm','T8','(declare-const x Real)\n(declare-const y Real)\n','(= (+ (* (- x) (- x)) (* y y)) (+ (* x x) (* y y)))')
add('K12','XOR equals integer sum modulo two','T12',B,'(= (ite (xor a b) 1 0) (mod (+ (ite a 1 0) (ite b 1 0)) 2))')
# Eight data bits and one even parity bit.
decl='\n'.join(f'(declare-const b{i} Bool)' for i in range(8))+'\n'
def xor(xs):
    xs=list(xs)
    if len(xs)==1:return xs[0]
    return f'(xor {xs[0]} {xor(xs[1:])})'
p=xor(f'b{i}' for i in range(8))
add('K13','Appended even parity gives an even nine-bit block','T12',decl,f'(= (xor {p} {p}) false)')
p1=xor(['(not b0)']+[f'b{i}' for i in range(1,8)])
add('K14','One selected payload-bit fault flips block parity','T12',decl,f'(= {p1} (not {p}))')
p2=xor(['(not b0)','(not b1)']+[f'b{i}' for i in range(2,8)])
add('K15','Two selected payload-bit faults preserve block parity','T12',decl,f'(= {p2} {p})')
add('K16','Positive field rescaling preserves the occupancy predicate','T13','(declare-const k Real)\n(declare-const x Real)\n','(=> (> k 0) (= (<= (* k x) 0) (<= x 0)))')
add('K17','Either bisection half has half the old width','T11',R,'(and (= (- (/ (+ a b) 2) a) (/ (- b a) 2)) (= (- b (/ (+ a b) 2)) (/ (- b a) 2)))')
add('K18','Unnormalized two-point Hadamard squared is twice identity','T15','(declare-const x Real)\n(declare-const y Real)\n','(and (= (+ (+ x y) (- x y)) (* 2 x)) (= (- (+ x y) (- x y)) (* 2 y)))')
add('K19','Convex slow-memory update preserves a bounded interval','T16','(declare-const m Real)\n(declare-const v Real)\n(declare-const eta Real)\n(define-fun nxt () Real (+ (* (- 1 eta) m) (* eta v)))\n','(=> (and (<= -1 m) (<= m 1) (<= -1 v) (<= v 1) (<= 0 eta) (<= eta 1)) (and (<= -1 nxt) (<= nxt 1)))')
add('K20','Nonnegative row-sum contraction bound','T17','(declare-const a Real)\n(declare-const b Real)\n(declare-const q Real)\n(declare-const ez Real)\n(declare-const em Real)\n(declare-const e Real)\n','(=> (and (>= a 0) (>= b 0) (>= e 0) (>= ez 0) (>= em 0) (<= ez e) (<= em e) (<= (+ a b) q) (< q 1)) (<= (+ (* a ez) (* b em)) (* q e)))')

def main():
    target=BASE/'obligations';target.mkdir(exist_ok=True)
    for o in OBLIGATIONS:
        text=f'; {o["id"]}: {o["title"]}\n; Manuscript: {o["theorem"]}. Prove by unsatisfiability of its negation.\n'
        text+='(set-option :produce-proofs true)\n(set-option :timeout 10000)\n(set-logic ALL)\n'
        text+=o['declarations']+f'(assert (not {o["formula"]}))\n(check-sat)\n(get-proof)\n'
        (target/(o['id']+'.smt2')).write_text(text)
    (BASE/'obligation_index.json').write_text(json.dumps([{k:v for k,v in o.items() if k not in ['declarations','formula']} for o in OBLIGATIONS],indent=2)+'\n')
if __name__=='__main__':main()
