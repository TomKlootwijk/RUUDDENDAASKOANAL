# Attribution and scope

**Ilse AI Engine — Den Daas perspective edition, version 1.0.0**

The requested perspective designation is:

**Ruud den Daas · Koen den Daas · Job den Daas**

The edition uses these names at the request of the user. The supplied sources do
not independently establish a joint publication, quotations, individual beliefs,
authorship contributions or endorsement by the named people. No such statements
are invented. The formalization, proof organization, added symbolic grammar and
reference implementation were prepared with AI assistance for this request.

The phrase “family of theorems” denotes related mathematical propositions. It is
not a claim about hereditary properties of any family. XX, XY, YX and YY are
symbols in a construction grammar, not classifications of the named individuals
or claims about anyone's biology or consciousness.

The submitted double-arc addendum is included as a research source. Its original
AI-generated statements remain unverified unless a particular mathematical
statement has been separately qualified and proved in this edition. Consult the
page-specific claim audit rather than assuming that inclusion is endorsement.
The earlier research framework was consulted for continuity and is not bundled.

No priority is claimed for established L-system methods, distance fields, parity,
Hadamard transforms or contraction arguments. The exact organization of these
components into the present consciousness proposal remains a model choice.
This package does not grant rights in third-party source material or imply that
its named individuals have approved public distribution.
