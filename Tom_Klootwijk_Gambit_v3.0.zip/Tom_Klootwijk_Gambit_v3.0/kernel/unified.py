"""Tom Klootwijk Gambit 3.0 inherited composition core: seed -> field -> transport -> recurrence -> code.

All numerical constants are simulation choices. There is no claim that this
state is a brain, a soul, a genotype, or a measured consciousness variable.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import copy
import hashlib
import json
import math
import numpy as np
from .core import (Pair, RULES, grow, turtle, capsule_field, m_field,
                   finite_array, parity, VERSION)
from .transport import Grid, Graph, conservative_remap, transport_step, reaction_step
from .coding import DyadicAccumulator

@dataclass(frozen=True)
class ModelSpec:
    version: str = VERSION
    pair: str = 'XY'
    random_seed: int = 20260911
    initial_generation: int = 1
    max_generation: int = 4
    growth_threshold: float = .55
    growth_dwell: int = 30
    steps: int = 120
    max_symbols: int = 200000
    max_nodes: int = 20000
    max_substeps: int = 10000
    turtle_step: float = .12
    turtle_angle: float = math.pi/7
    turtle_shrink: float = .72
    embedding_scale: float = 1.0
    embedding_y: float = .10
    capsule_thickness: float = .045
    arc_radius: float = 1.0
    arc_spacing: float = 1.0
    arc_thickness: float = .105
    memory_geometry_gain: float = .025
    xmin: float = -2.4
    xmax: float = 2.4
    ymin: float = -.16
    ymax: float = 2.24
    grid_h: float = .08
    dt: float = .04
    diffusion_u: float = .05
    diffusion_v: float = .025
    omega: float = .06
    gate_base: float = .65
    gate_gain: float = .15
    gate_x: float = 0.0
    reaction_a: float = .24
    reaction_b: float = .12
    alpha: float = .4
    eta: float = .08
    codec_bits: int = 16

    def __post_init__(self):
        if self.version!=VERSION: raise ValueError('Unsupported model version')
        Pair.parse(self.pair)
        ints=['random_seed','initial_generation','max_generation','growth_dwell','steps',
              'max_symbols','max_nodes','max_substeps','codec_bits']
        for name in ints:
            v=getattr(self,name)
            if not isinstance(v,int) or isinstance(v,bool) or v<0: raise ValueError(f'{name} must be a nonnegative integer')
        if not 0<=self.initial_generation<=self.max_generation<=8: raise ValueError('Invalid generation range')
        if min(self.growth_dwell,self.steps,self.max_symbols,self.max_nodes,self.max_substeps)<=0:
            raise ValueError('Budgets, dwell and steps must be positive')
        if not 1<=self.codec_bits<=32: raise ValueError('codec_bits must be in 1..32')
        for name,value in asdict(self).items():
            if isinstance(value,float) and not math.isfinite(value): raise ValueError(f'{name} must be finite')
        positive=['turtle_step','embedding_scale','capsule_thickness','arc_radius',
                  'grid_h','dt','arc_thickness']
        if any(getattr(self,n)<=0 for n in positive): raise ValueError('Positive scale required')
        if not 0<self.turtle_shrink<=1 or self.arc_spacing<0: raise ValueError('Invalid geometry')
        if self.arc_thickness<=abs(self.memory_geometry_gain): raise ValueError('Memory can invalidate stroke width')
        if self.gate_base-abs(self.gate_gain)<0 or self.gate_base+abs(self.gate_gain)>1:
            raise ValueError('Gate range must stay in [0,1]')
        if not 0<=self.growth_threshold<=1 or not 0<self.alpha<=1 or not 0<self.eta<=1:
            raise ValueError('Invalid threshold or update rates')
        if min(self.diffusion_u,self.diffusion_v,self.reaction_a,self.reaction_b)<0:
            raise ValueError('Transport/reaction rates must be nonnegative')
        if 5*3**self.max_generation+1>self.max_symbols: raise ValueError('Growth cannot fit symbol budget')
        Grid.regular(self.xmin,self.xmax,self.ymin,self.ymax,self.grid_h,self.max_nodes)

    @classmethod
    def load(cls,path):
        data=json.loads(Path(path).read_text())
        expected={'engine','author','schema','grammar','model','scope'}
        if set(data)!=expected: raise ValueError('Unexpected or missing top-level configuration field')
        if data['schema']!='ksfe-model-3.0': raise ValueError('Unknown seed schema')
        if data['grammar']!=RULES: raise ValueError('This reference build supports only the declared complete grammar')
        # Documentary fields are not used as numerical initial conditions.
        try: return cls(**data['model'])
        except TypeError as e: raise ValueError('Unknown model field') from e

    def save(self,path):
        data={'engine':'Tom Klootwijk Gambit (composition baseline)',
              'author':{'name':'Tom Klootwijk','identifier':'NL200678942','date_as_supplied':'10-07-1990'},
              'schema':'ksfe-model-3.0','grammar':RULES,'model':asdict(self),
              'scope':'XX/XY are symbolic tokens. Simulation only; not a biological model or consciousness detector.'}
        Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

@dataclass
class UnifiedState:
    u: np.ndarray
    v: np.ndarray
    mask: np.ndarray
    z: np.ndarray
    memory: np.ndarray
    generation: int
    last_growth: int
    step: int
    accumulator: DyadicAccumulator

    def copy(self): return copy.deepcopy(self)

class UnifiedKernel:
    def __init__(self,spec: ModelSpec):
        self.spec=spec
        self.grid=Grid.regular(spec.xmin,spec.xmax,spec.ymin,spec.ymax,spec.grid_h,spec.max_nodes)
        self.rng=np.random.Generator(np.random.PCG64(spec.random_seed))
        def matrix(bound):
            x=self.rng.normal(size=(3,3));return x*bound/np.max(np.sum(np.abs(x),axis=1))
        self.A=matrix(.35);self.B=matrix(.15);self.C=matrix(.40)
        self.D=matrix(.30);self.E=matrix(.20)
        self._segments={}

    def segments(self,generation):
        if generation not in self._segments:
            word=grow(Pair.parse(self.spec.pair),generation,self.spec.max_symbols)
            seg=turtle(word,self.spec.turtle_step,self.spec.turtle_angle,self.spec.turtle_shrink)
            self._segments[generation]=self.spec.embedding_scale*seg+np.array([0,self.spec.embedding_y])
        return self._segments[generation]

    def field(self,points,generation,memory):
        p=finite_array(points,last_dim=2);m=finite_array(memory)
        if m.shape!=(3,): raise ValueError('Memory must be a three-vector')
        s=self.spec;thickness=s.arc_thickness+s.memory_geometry_gain*math.tanh(float(m[0]))
        arch=m_field(p,s.arc_radius,s.arc_spacing,thickness)
        branches=capsule_field(p,self.segments(generation),s.capsule_thickness)
        return np.maximum(np.minimum(arch,branches),-p[...,1])

    def initial_state(self):
        n=len(self.grid.points);zero=np.zeros(3)
        mask=self.field(self.grid.points,self.spec.initial_generation,zero)<=0
        if not np.any(mask): raise ValueError('Seed geometry misses the finite grid')
        p=self.grid.points
        # Nonrandom input law, specified in the versioned kernel; matrices use PCG64.
        u=.1+.8*np.exp(-((p[:,0]+1.0)**2+(p[:,1]-.75)**2)/.18)
        v=.05+.15*np.exp(-((p[:,0]-1.0)**2+(p[:,1]-.5)**2)/.25)
        u=u*mask*self.grid.volume;v=v*mask*self.grid.volume
        return UnifiedState(u,v,mask,zero.copy(),zero.copy(),self.spec.initial_generation,
                            0,0,DyadicAccumulator(self.spec.codec_bits))

    def input_points(self,step):
        """Three prescribed simulated probes; not anatomical measurements."""
        t=step*self.spec.dt
        return np.array([[-1+.08*math.sin(.7*t),1.02],
                         [1+.08*math.cos(.6*t),1.02],
                         [.10*math.sin(.9*t),.65]])

    def growth_score(self,state):
        boundary=Graph.build(self.grid,state.mask).boundary_nodes()
        total=state.u+state.v
        values=np.divide(state.u,total,out=np.zeros_like(total),where=total>0)
        return float(np.max(values[boundary])) if np.any(boundary) else 0.0

    def advance(self,state: UnifiedState, gate_multiplier: float = 1.0):
        s=self.spec
        gate_multiplier=float(gate_multiplier)
        if not math.isfinite(gate_multiplier) or not 0<=gate_multiplier<=1:
            raise ValueError('Gate multiplier must be finite and in [0,1]')
        if state.step>=s.steps: raise ValueError('Step budget reached')
        if state.u.shape!=(len(self.grid.points),) or state.v.shape!=state.u.shape:
            raise ValueError('State dimension mismatch')
        for a in [state.u,state.v,state.z,state.memory]: finite_array(a)
        if state.z.shape!=(3,) or state.memory.shape!=(3,): raise ValueError('Invalid recurrent state')
        if np.min(state.u)<0 or np.min(state.v)<0: raise ValueError('Negative chemical mass')
        if np.max(np.abs(state.z))>1+1e-12 or np.max(np.abs(state.memory))>1+1e-12:
            raise ValueError('Recurrent state outside invariant cube')
        score=self.growth_score(state)
        trigger=(state.generation<s.max_generation and state.step-state.last_growth>=s.growth_dwell
                 and score>=s.growth_threshold)
        generation=state.generation+int(trigger)
        last=state.step if trigger else state.last_growth
        phi=self.field(self.grid.points,generation,state.memory)
        mask=phi<=0
        u=conservative_remap(state.u,state.mask,mask,self.grid.points)
        v=conservative_remap(state.v,state.mask,mask,self.grid.points)
        gate=(s.gate_base+s.gate_gain*math.tanh(float(state.memory[1])))*gate_multiplier
        graph=Graph.build(self.grid,mask,gate,s.omega,s.gate_x)
        u,info_u=transport_step(u,graph.generator(s.diffusion_u),s.dt,s.max_substeps)
        v,info_v=transport_step(v,graph.generator(s.diffusion_v),s.dt,s.max_substeps)
        u,v=reaction_step(u,v,s.reaction_a,s.reaction_b,s.dt,s.max_substeps)
        points=self.input_points(state.step)
        field_obs=-np.tanh(self.field(points,generation,state.memory))
        total_mass=float(np.sum(u+v));fraction=float(np.sum(u)/total_mass) if total_mass>0 else .5
        # Chemistry contributes a bounded dimensionless aggregate. It is not an SDF.
        observation=.6*field_obs+.4*(2*fraction-1)
        z=(1-s.alpha)*state.z+s.alpha*np.tanh(self.A@state.z+self.B@state.memory+self.C@observation)
        memory=(1-s.eta)*state.memory+s.eta*np.tanh(self.D@state.z+self.E@observation)
        acc=copy.deepcopy(state.accumulator);coverage=float((1+np.mean(z))/2)
        pulse,k=acc.push(coverage)
        occupied=(field_obs>=0).astype(int)
        payload=tuple(map(int,occupied))+(pulse,)
        parity_bit=parity(payload)
        next_state=UnifiedState(u,v,mask,z,memory,generation,last,state.step+1,acc)
        trace={'step':state.step+1,'time':(state.step+1)*s.dt,'generation':generation,
               'growth':bool(trigger),'growth_score':score,'active_nodes':int(mask.sum()),
               'mass':total_mass,'min_mass':float(min(np.min(u),np.min(v))),
               'gate':gate,'cfl':max(info_u['max_cfl'],info_v['max_cfl']),
               'substeps':max(info_u['substeps'],info_v['substeps']),
               'z_max':float(np.max(np.abs(z))),'memory_max':float(np.max(np.abs(memory))),
               'coverage':coverage,'fixed_input':k,'pulse':pulse,'parity':parity_bit,
               'frame_even':parity(payload+(parity_bit,))==0,
               'prefix_error':acc.discrepancy,'codec_certificate':acc.certificate(),
               'observation':observation.tolist(),'z':z.tolist(),'memory':memory.tolist()}
        return next_state,trace

    def run(self):
        state=self.initial_state();history=[]
        for _ in range(self.spec.steps):
            state,row=self.advance(state);history.append(row)
        return state,history

    def fingerprint(self):
        doc={'model':asdict(self.spec),'grammar':RULES,'rng':'NumPy PCG64','version':VERSION,
             'matrices':{k:getattr(self,k).tolist() for k in ['A','B','C','D','E']}}
        return hashlib.sha256(json.dumps(doc,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
