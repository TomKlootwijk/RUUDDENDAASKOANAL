; Occupancy does not give an autonomous next-state law
(set-logic ALL)

(declare-const x Real) (declare-const y Real)
(assert (= x (- 2))) (assert (= y (- (/ 1 2))))
(assert (and (<= x 0) (<= y 0)))
(assert (distinct (<= (+ x (/ 3 4)) 0) (<= (+ y (/ 3 4)) 0)))

(check-sat)
(get-model)
