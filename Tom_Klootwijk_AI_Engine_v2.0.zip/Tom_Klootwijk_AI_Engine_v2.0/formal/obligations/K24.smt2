; K24: Directed two-node Euler transport conserves mass
; Manuscript: L5. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const dt Real)
(declare-const a Real)
(declare-const b Real)
(declare-const u Real)
(declare-const v Real)
(assert (not (= (+ (+ (* (- 1 (* dt a)) u) (* dt b v)) (+ (* dt a u) (* (- 1 (* dt b)) v))) (+ u v))))
(check-sat)
(get-proof)
