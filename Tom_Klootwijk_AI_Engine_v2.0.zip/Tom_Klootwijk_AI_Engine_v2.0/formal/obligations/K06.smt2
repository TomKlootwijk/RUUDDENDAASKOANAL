; K06: Minimum is closed-set union at zero
; Manuscript: L2. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(define-fun mn ((x Real) (y Real)) Real (ite (<= x y) x y))
(assert (not (= (<= (mn a b) 0) (or (<= a 0) (<= b 0)))))
(check-sat)
(get-proof)
