; K31: Two-species modal determinant has no negative value
; Manuscript: L12. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(declare-const D1 Real)
(declare-const D2 Real)
(declare-const l Real)
(assert (not (=> (and (>= a 0) (>= b 0) (>= D1 0) (>= D2 0) (>= l 0)) (>= (+ (* (+ (* a D2) (* b D1)) l) (* D1 D2 l l)) 0))))
(check-sat)
(get-proof)
