; K38: XOR transition bits telescope over three steps
; Manuscript: L14. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Bool)
(declare-const b Bool)
(declare-const c Bool)
(declare-const d Bool)
(assert (not (= (xor (xor (xor a b) (xor b c)) (xor c d)) (xor a d))))
(check-sat)
(get-proof)
