# Revision lineage and explicit Edition 3.0 decisions

**Tom Klootwijk Gambit · Edition 3.0 / Kernel 3.0.0**  
**Author: Tom Klootwijk · NL200678942 · 10-07-1990**

## Continuity

C0 supplies the original operator-chain and consciousness/memory themes. C1 formalizes complete seeds, distance fields, L-system growth, event-time roots and interpretive limits. C2 adds double-arc geometry, a baseline and hinge narrative. C3 is an intermediate theorem-and-kernel revision; its alternate title and perspective designation are historical metadata only. C4 adds the reaction–diffusion, membrane/sieve and ambient-field discussion. C5 composes those ingredients in Edition 2.0 and is the direct code ancestor of this package. C6 adds the Gambit latching, one-bit universality, typography, Christian interpretation, quintessence and set/seed questions.

The six archived source copies match the uploaded bytes. Historical archives and the intermediate edition are fingerprinted in `source_manifest.json` but not nested inside this ZIP. `edition_2_retest.txt` records re-execution of the extracted Edition 2.0 suite: 99 tests passed. The current 145-test suite retains those 99 tests and adds 46 Gambit tests. A test pass is evidence for its specified target, not a certificate of the source narrative.

## Computational changes

The inherited geometry, coding, roots, conservative transport, remapping and recurrence remain visible in separate modules. `UnifiedKernel.advance` now accepts an explicitly bounded gate multiplier, defaulting to one so the composition baseline remains available. Version tags and command-line branding are updated.

`kernel/gambit.py` adds complete current seed records, strict JSON validation, explicit positive-threshold hysteretic latches, a one-step causal gate connection, configurable moving probes, separate raw occupancy and event bits, payload framing and full-source fingerprints. The latch is not substituted for the material or memory state.

`kernel/quotient.py` adds an exact finite-state checker for a supplied partition. The new theorem proves the general deterministic representative-independence criterion; the checker verifies only its supplied finite tables. `kernel/editing.py` adds validated word edits and finite geometric edit demonstrations, not genome or molecular operations.

The demo now exports latch samples, transitions, gate multipliers and framed bits, alongside the inherited mass and memory histories. The new 46 algebraic obligations contain the 34 inherited targets and twelve additions. Three separate SAT cases intentionally witness the failure of stronger claims. No past verification total has simply been relabeled as a new result.

## Formal and interpretive changes

U3 retains the conditional composition invariants and adds the hinge law, exact quotient criterion, fixed-decoder cardinality boundary and edit/margin clauses. Six new lemmas extend the previous twelve. Capital Sigma is explicitly reassigned to the alphabet; the complete seed family and a seed record have distinct symbols. The tagged-set representation preserves structure without erasing order or repeated letters.

The full-angle and half-angle polynomial/root variants are presented separately because the corpus does not supply one consistent equation. The source's broader claims about universal one-bit biology, mirrored structures preventing editing, glyph union filling a gap, cultural chirality, zero delay and quantum effects are not silently promoted into results. The 84-entry audit gives their dispositions.

The Word, Christian interpretation, V/hourglass, quintessence and field language is retained as the requested author's interpretation. It is not a numerical control parameter, an established physical law or a claim to speak for all Christian doctrine. The bodily/digital consciousness bridge remains a prospective empirical hypothesis with explicit tests.

## Attribution and release status

This is a finalized research edition and reproducible reference implementation, not a claim of clinical, biological, quantum or hardware validation. The requested author details are documentary metadata supplied by the requester; no external identity, exclusive invention or priority is verified. AI-assisted formalization and coding are disclosed in `ATTRIBUTION_AND_SCOPE.md`. The source documents and private attribution details require review before public release.
