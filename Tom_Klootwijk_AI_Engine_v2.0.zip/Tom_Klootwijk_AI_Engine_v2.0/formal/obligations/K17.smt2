; K17: Either bisection half has half the old width
; Manuscript: L4. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(assert (not (and (= (- (/ (+ a b) 2) a) (/ (- b a) 2)) (= (- b (/ (+ a b) 2)) (/ (- b a) 2)))))
(check-sat)
(get-proof)
