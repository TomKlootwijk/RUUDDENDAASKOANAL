#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
name=Tom_Klootwijk_Gambit_Edition_3.0
mkdir -p _build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=_build "$name.tex"
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=_build "$name.tex"
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=_build "$name.tex"
cp "_build/$name.pdf" "../$name.pdf"
