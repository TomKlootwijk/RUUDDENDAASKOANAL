# Tom Klootwijk's Seed–Field Theory of Consciousness and the Senses

**Research draft 1.0 · 11 September 2026 · Private attribution edition**

A proposed integrative framework covering seeds, L-system growth instructions,
signed distance fields, bodily sensing, IPD and ITD, event timing, digital
encoding, Hadamard notation, memory, consciousness and spiritual interpretation.

## Start here

Open **Tom_Klootwijk_Seed_Field_Theory.pdf**. The canonical editable source is
`manuscript/Tom_Klootwijk_Seed_Field_Theory.tex`; a Markdown conversion is beside
it. The PDF distinguishes mathematics, cited findings, testable hypotheses,
philosophical interpretation and unsupported earlier claims. The original
uploaded conversation is preserved unchanged as provenance, not endorsed science.

## What's in the package

| Location | Contents |
|---|---|
| `Tom_Klootwijk_Seed_Field_Theory.pdf` | Complete typeset manuscript, audit, notation and references. |
| `manuscript/` | LaTeX, editable Markdown, BibTeX, reference-scope CSV, 30-entry claim audit and experiment plan. |
| `manuscript/figures/` | The three vector figure PDFs used in the manuscript. |
| `code/` | Offline reference functions, a runnable demo, 17 unit tests, seed configuration and dependency records. |
| `outputs/` | Numerical metrics, complete test log, CSV data and figures in PDF, PNG and SVG. |
| `provenance/` | Byte-for-byte uploaded source and its integrity metadata. |
| `PRIVATE_ATTRIBUTION.txt` | Personal attribution particulars supplied by the requester. |
| `AUTHORS_AND_SCOPE.md` | Attribution and boundaries of the draft. |
| `SHA256SUMS.txt` | Checksums of the delivered package files, excluding the manifest itself. |

## Run the demonstrations

With a compatible Python environment, open a terminal in this folder:

```bash
cd code
python -m pip install -r requirements.txt
python -m unittest -v test_seed_field.py
python demo.py --config seed.json --out ../outputs
```

The delivered run used **Python 3.13.5, NumPy 2.3.5 and Matplotlib 3.10.8**.
`requirements-tested.txt` pins those package versions for closest reproduction.
The source code targets Python 3.10+, using dependency versions compatible with
the chosen interpreter. Installing dependencies may require internet access;
the installed examples run offline. Results can differ slightly across numerical
or library environments. Rerun the tests rather than presuming equivalence.

The deterministic grammar is `F -> F[+F]F[-F]F`. Three generations produce 125
forward segments. Numerical seed 42 controls a declared angular perturbation
in the geometric interpretation. It does not encode anyone's identity.

## What was actually tested

The delivered test log records **17 passing tests**: rewriting, seeded geometry,
primitive distances, normalization, quantization error, pulse-density counts,
parity limitations, Hadamard orthogonality, one selected associative recall,
a bracketed crossing, point-ear timing and specified invalid inputs.
The selected 64-variable associative example corrects eight corrupted cue bits.
These are synthetic examples, not general performance or biological claims.

The exact-arithmetic accumulator prefix bound is less than one bit. The recorded
floating-point maximum is approximately 1.0000000000000073; the test explicitly
allows a numerical tolerance. This is rounding behaviour, not hidden evidence
of perfect arithmetic.

## Rebuild the PDF

A TeX distribution with `pdflatex`, the packages listed in the source, and the
Python dependencies is required. From the package root, on a shell supporting Bash:

```bash
bash manuscript/build.sh
```

Pandoc is optional for refreshing the Markdown conversion. No font files or
third-party research PDFs are included. Editing the Markdown does not silently
change the LaTeX source; choose and maintain one source of truth for revisions.
The supplied canonical source is LaTeX.

## Integrity and privacy

Run `python verify_package.py` from any directory to check delivered file hashes.
The manifest verifies byte integrity locally; it is not an independent timestamp,
identity check, authorship proof or authentication scheme. Rebuilding or editing
files can legitimately change their hashes.

**This is a private copy.** The PDF, editable sources, original uploaded notes and
attribution record contain the personal particulars supplied in the request.
Review these before sharing publicly. No identity or identifier meaning has been
verified.

## Scientific and practical limits

The code does not implement a conscious being, brain simulator, spiritual
measurement, molecular mechanism, individualized audiovisual renderer, log-polar
LUT, real-time spatial index or optical circuit. It emits no sound and controls
no external hardware. The manuscript proposes tests for some unimplemented
components and explicitly labels them as proposed work. No human-subject data
were collected. The framework is not a clinical or coercive-perception tool.
