"""Seed, growth, field, coding and recurrent-state reference implementation.

All coordinates are simulation units unless an API explicitly specifies metres
or seconds. Composite fields preserve set membership; they are not advertised
as globally exact signed distances. No hardware or biomedical output is used.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Callable, Iterable
import hashlib
import json
import math
import numpy as np

VERSION = "3.0.0"
RULES = {"X": "X[+X]Y", "Y": "Y[-Y]X", "[": "[", "]": "]", "+": "+", "-": "-"}
SWAP = str.maketrans({"X": "Y", "Y": "X", "+": "-", "-": "+"})


def finite_array(value, *, last_dim: int | None = None) -> np.ndarray:
    a = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(a)):
        raise ValueError("All values must be finite")
    if last_dim is not None and (a.ndim == 0 or a.shape[-1] != last_dim):
        raise ValueError(f"Expected final dimension {last_dim}")
    return a


def finite_scalar(value: float, name: str) -> float:
    x = float(value)
    if not math.isfinite(x):
        raise ValueError(f"{name} must be finite")
    return x


@dataclass(frozen=True)
class Pair:
    """Ordered symbolic pair; X and Y are tokens, not a person classifier."""
    first: str
    second: str

    def __post_init__(self):
        if self.first not in {"X", "Y"} or self.second not in {"X", "Y"}:
            raise ValueError("Pair symbols must be X or Y")

    @classmethod
    def parse(cls, text: str) -> "Pair":
        if not isinstance(text, str) or len(text) != 2:
            raise ValueError("A pair must be a two-character string")
        return cls(text[0], text[1])

    @property
    def word(self) -> str:
        return self.first + self.second

    @property
    def canonical(self) -> str:
        return "".join(sorted(self.word))

    @property
    def parity(self) -> int:
        return int(self.first != self.second)

    @property
    def axiom(self) -> str:
        return f"[{self.first}][{self.second}]"


def mix_pairs(a: Pair, b: Pair) -> dict[str, Fraction]:
    """Exact formal one-token-from-each mixing law: four equiprobable draws."""
    out: dict[str, Fraction] = {}
    for x in a.word:
        for y in b.word:
            k = Pair(x, y).canonical
            out[k] = out.get(k, Fraction(0)) + Fraction(1, 4)
    return dict(sorted(out.items()))


def rewrite(word: str, max_symbols: int = 200_000) -> str:
    if any(x not in RULES for x in word):
        raise ValueError("Unknown grammar token")
    new_size = sum(len(RULES[x]) for x in word)
    if new_size > max_symbols:
        raise ValueError("Growth exceeds the configured symbol budget")
    return "".join(RULES[x] for x in word)


def grow(pair: Pair, generations: int, max_symbols: int = 200_000) -> str:
    if not isinstance(generations, int) or isinstance(generations, bool) or generations < 0:
        raise ValueError("generations must be a nonnegative integer")
    if max_symbols < len(pair.axiom):
        raise ValueError("Budget is smaller than the axiom")
    word = pair.axiom
    for _ in range(generations):
        word = rewrite(word, max_symbols)
    return word


def swap_word(word: str) -> str:
    if any(x not in RULES for x in word):
        raise ValueError("Unknown grammar token")
    return word.translate(SWAP)


def turtle(word: str, step: float = 0.12, angle: float = math.pi / 7,
           shrink: float = 0.72) -> np.ndarray:
    """Interpret X/Y as forward strokes; brackets save/restore full state."""
    if step <= 0 or not (0 < shrink <= 1):
        raise ValueError("step > 0 and 0 < shrink <= 1 are required")
    for x, name in [(step, "step"), (angle, "angle"), (shrink, "shrink")]:
        finite_scalar(x, name)
    pos = np.zeros(2); heading = math.pi / 2
    stack: list[tuple[np.ndarray, float]] = []; segments = []
    for token in word:
        if token in "XY":
            nxt = pos + step * shrink ** len(stack) * np.array([math.cos(heading), math.sin(heading)])
            segments.append(np.stack([pos.copy(), nxt.copy()])); pos = nxt
        elif token == "+": heading += angle
        elif token == "-": heading -= angle
        elif token == "[": stack.append((pos.copy(), heading))
        elif token == "]":
            if not stack: raise ValueError("Unbalanced closing bracket")
            pos, heading = stack.pop()
        else: raise ValueError("Unknown turtle token")
    if stack: raise ValueError("Unbalanced opening bracket")
    return np.asarray(segments, dtype=float).reshape(-1, 2, 2)


def distance_segment(points, a, b) -> np.ndarray:
    p = finite_array(points, last_dim=2)
    a = finite_array(a, last_dim=2); b = finite_array(b, last_dim=2)
    if a.shape != (2,) or b.shape != (2,):
        raise ValueError("Segment endpoints must be two-vectors")
    v = b - a; den = float(np.dot(v, v))
    if den == 0: return np.linalg.norm(p-a, axis=-1)
    t = np.clip(np.sum((p-a)*v, axis=-1) / den, 0.0, 1.0)
    return np.linalg.norm(p - a - t[..., None]*v, axis=-1)


def distance_arc(points, radius: float = 1.0, aperture: float = math.pi/2) -> np.ndarray:
    """Exact unsigned distance to R(sin theta, cos theta), |theta| <= aperture."""
    radius = finite_scalar(radius, "radius"); aperture = finite_scalar(aperture, "aperture")
    if radius <= 0 or not 0 < aperture <= math.pi/2:
        raise ValueError("radius > 0 and 0 < aperture <= pi/2 required")
    p = finite_array(points, last_dim=2).copy(); p[..., 0] = np.abs(p[..., 0])
    sc = np.array([math.sin(aperture), math.cos(aperture)])
    endpoint = np.linalg.norm(p - radius*sc, axis=-1)
    radial = np.abs(np.linalg.norm(p, axis=-1) - radius)
    return np.where(sc[1]*p[...,0] > sc[0]*p[...,1], endpoint, radial)


def paired_arcs(points, radius: float = 1.0, spacing: float = 1.0,
                thickness: float = 0.08, aperture: float = math.pi/2,
                folded: bool = False) -> np.ndarray:
    p = finite_array(points, last_dim=2)
    spacing = finite_scalar(spacing, "spacing"); thickness = finite_scalar(thickness, "thickness")
    if spacing < 0 or thickness <= 0: raise ValueError("spacing >= 0 and thickness > 0 required")
    if folded:
        q = p.copy(); q[...,0] = np.abs(q[...,0]) - spacing
        return distance_arc(q, radius, aperture) - thickness
    off = np.array([spacing, 0.0])
    return np.minimum(distance_arc(p-off, radius, aperture),
                      distance_arc(p+off, radius, aperture)) - thickness


def m_field(points, radius: float = 1.0, spacing: float = 1.0,
            thickness: float = 0.08, aperture: float = math.pi/2,
            baseline: bool = True, clipped: bool = True) -> np.ndarray:
    """Explicit two-arc union, optional baseline and y>=0 clipping.

    Uses the explicit union, not the conditionally valid fold shortcut.
    The returned field is 1-Lipschitz and sign-correct, not generally an exact SDF.
    """
    p = finite_array(points, last_dim=2)
    phi = paired_arcs(p, radius, spacing, thickness, aperture)
    if baseline:
        phi = np.minimum(phi, distance_segment(p, [-spacing-radius,0], [spacing+radius,0]) - thickness)
    if clipped: phi = np.maximum(phi, -p[...,1])
    return phi


def capsule_field(points, segments, thickness: float = 0.03) -> np.ndarray:
    p = finite_array(points, last_dim=2); s = finite_array(segments)
    if s.ndim != 3 or s.shape[1:] != (2,2) or len(s) == 0:
        raise ValueError("segments must be nonempty with shape (N,2,2)")
    if not math.isfinite(thickness) or thickness <= 0: raise ValueError("thickness > 0 required")
    out = np.full(p.shape[:-1], np.inf)
    for a,b in s: out = np.minimum(out, distance_segment(p,a,b)-thickness)
    return out


def occupancy(field) -> np.ndarray:
    return (finite_array(field) <= 0).astype(np.uint8)


def log_polar(points, reference: float = 1.0, minimum: float = 1e-6) -> np.ndarray:
    p = finite_array(points, last_dim=2)
    if not math.isfinite(reference) or not math.isfinite(minimum) or reference <= 0 or minimum <= 0:
        raise ValueError("Positive finite chart scales required")
    r = np.linalg.norm(p,axis=-1)
    if np.any(r < minimum): raise ValueError("Point is outside the annular chart")
    return np.stack([np.log(r/reference), np.arctan2(p[...,1],p[...,0])],axis=-1)


def inverse_log_polar(coords, reference: float = 1.0) -> np.ndarray:
    q = finite_array(coords,last_dim=2)
    if not math.isfinite(reference) or reference <= 0: raise ValueError("reference must be positive")
    r = reference*np.exp(q[...,0])
    out = np.stack([r*np.cos(q[...,1]),r*np.sin(q[...,1])],axis=-1)
    if not np.all(np.isfinite(out)): raise ValueError("Chart inverse overflow")
    return out


@dataclass
class LogPolarLUT:
    """Bilinear scalar LUT storing Cartesian field values, not chart distances."""
    values: np.ndarray
    rho_min: float
    rho_max: float
    reference: float

    @classmethod
    def build(cls, field: Callable, r_min=0.05, r_max=4.0, radial=64, angular=128, reference=1.0):
        if not 0 < r_min < r_max or radial < 2 or angular < 4 or reference <= 0:
            raise ValueError("Invalid LUT domain or resolution")
        lo,hi = math.log(r_min/reference),math.log(r_max/reference)
        rho,theta = np.meshgrid(np.linspace(lo,hi,radial),np.arange(angular)*2*math.pi/angular,indexing="ij")
        p = inverse_log_polar(np.stack([rho,theta],-1),reference)
        return cls(finite_array(field(p)),lo,hi,reference)

    def query(self, points) -> tuple[np.ndarray, np.ndarray]:
        """Return interpolant and a conservative error bound for 1-Lipschitz fields."""
        p=finite_array(points,last_dim=2); q=log_polar(p,self.reference,minimum=np.finfo(float).tiny)
        nr,nt=self.values.shape
        if np.any(q[...,0] < self.rho_min-1e-12) or np.any(q[...,0] > self.rho_max+1e-12):
            raise ValueError("Query is outside LUT radial range")
        fr=np.clip((q[...,0]-self.rho_min)/(self.rho_max-self.rho_min)*(nr-1),0,nr-1)
        i=np.minimum(np.floor(fr).astype(int),nr-2); wr=fr-i
        ft=(q[...,1]%(2*math.pi))*nt/(2*math.pi); j=np.floor(ft).astype(int)%nt; wt=ft-np.floor(ft)
        value=np.zeros(p.shape[:-1]); bound=np.zeros_like(value)
        for di,dj,w in [(0,0,(1-wr)*(1-wt)),(1,0,wr*(1-wt)),(0,1,(1-wr)*wt),(1,1,wr*wt)]:
            ii=i+di; jj=(j+dj)%nt
            value+=w*self.values[ii,jj]
            corner=inverse_log_polar(np.stack([self.rho_min+ii/(nr-1)*(self.rho_max-self.rho_min),jj/nt*2*math.pi],-1),self.reference)
            bound=np.maximum(bound,np.linalg.norm(corner-p,axis=-1))
        return value,bound


@dataclass(frozen=True)
class RootResult:
    value: float
    lower: float
    upper: float
    iterations: int


def bisect_root(f: Callable[[float], float], lower: float, upper: float,
                tolerance: float = 1e-10, max_iterations: int = 200) -> RootResult:
    a=finite_scalar(lower,"lower"); b=finite_scalar(upper,"upper")
    if not a < b or not math.isfinite(tolerance) or tolerance <= 0 or max_iterations < 1:
        raise ValueError("Invalid bracket, tolerance or iteration budget")
    fa=finite_scalar(f(a),"f(lower)"); fb=finite_scalar(f(b),"f(upper)")
    if fa == 0: return RootResult(a,a,a,0)
    if fb == 0: return RootResult(b,b,b,0)
    if (fa < 0) == (fb < 0): raise ValueError("No sign-changing bracket")
    for n in range(max_iterations):
        if b-a <= 2*tolerance: return RootResult((a+b)/2,a,b,n)
        mid=(a+b)/2; fm=finite_scalar(f(mid),"f(mid)")
        if fm == 0: return RootResult(mid,mid,mid,n+1)
        if (fm < 0) == (fa < 0): a,fa=mid,fm
        else: b,fb=mid,fm
    raise RuntimeError("Bisection did not meet the requested tolerance")


def stereo_eyes(ipd_m: float, origin=(0.,0.,0.)) -> np.ndarray:
    o=finite_array(origin,last_dim=3)
    if o.shape != (3,) or not math.isfinite(ipd_m) or ipd_m <= 0: raise ValueError("Invalid origin or IPD")
    return np.stack([o+[-ipd_m/2,0,0], o+[ipd_m/2,0,0]])


def itd_seconds(source, left_ear, right_ear, sound_speed_m_s: float=343.0) -> float:
    """Free-field point-receiver model: right arrival time minus left arrival time."""
    s=finite_array(source,last_dim=3); l=finite_array(left_ear,last_dim=3); r=finite_array(right_ear,last_dim=3)
    if any(x.shape != (3,) for x in [s,l,r]) or not math.isfinite(sound_speed_m_s) or sound_speed_m_s<=0:
        raise ValueError("Three-vector positions and positive speed required")
    return float((np.linalg.norm(s-r)-np.linalg.norm(s-l))/sound_speed_m_s)


def parity(bits: Iterable[int]) -> int:
    p=0
    for b in bits:
        if b not in (0,1): raise ValueError("Parity accepts bits only")
        p ^= int(b)
    return p


def append_even_parity(bits: Iterable[int]) -> tuple[int,...]:
    word=tuple(bits)
    return word+(parity(word),)


def bernoulli_encode(values, rng: np.random.Generator) -> np.ndarray:
    u=finite_array(values)
    if np.any((u<0)|(u>1)): raise ValueError("Coverage values must lie in [0,1]")
    return (rng.random(u.shape)<u).astype(np.uint8)


def fwht(values) -> np.ndarray:
    """Normalized real Walsh-Hadamard transform; not Boolean XOR reduction."""
    a=finite_array(values).copy()
    if a.ndim != 1 or len(a)==0 or len(a)&(len(a)-1):
        raise ValueError("Length must be a positive power of two")
    h=1
    while h<len(a):
        for i in range(0,len(a),2*h):
            x=a[i:i+h].copy(); y=a[i+h:i+2*h].copy()
            a[i:i+h]=x+y; a[i+h:i+2*h]=x-y
        h*=2
    return a/math.sqrt(len(a))


@dataclass(frozen=True)
class Seed:
    pair: str = "XY"
    generations: int = 4
    random_seed: int = 20260911
    radius: float = 1.0
    spacing: float = 1.0
    thickness: float = 0.08
    memory_geometry_gain: float = 0.04
    alpha: float = 0.4
    eta: float = 0.08
    version: str = VERSION

    def __post_init__(self):
        Pair.parse(self.pair)
        if not isinstance(self.generations,int) or not 0<=self.generations<=9: raise ValueError("generations must be in 0..9")
        if not isinstance(self.random_seed,int) or self.random_seed<0: raise ValueError("random_seed must be nonnegative")
        for name in ["radius","spacing","thickness","memory_geometry_gain","alpha","eta"]:
            finite_scalar(getattr(self,name),name)
        if self.radius<=0 or self.spacing<0 or self.thickness<=abs(self.memory_geometry_gain):
            raise ValueError("Invalid geometry or memory thickness margin")
        if not 0<self.alpha<=1 or not 0<self.eta<=1: raise ValueError("Update rates must be in (0,1]")
        if self.version != VERSION: raise ValueError("Unsupported seed version")

    @classmethod
    def load(cls,path: str | Path) -> "Seed":
        data=json.loads(Path(path).read_text())
        return cls(**data["seed"])


@dataclass
class State:
    z: np.ndarray
    memory: np.ndarray
    step: int = 0

    def copy(self) -> "State":
        return State(self.z.copy(),self.memory.copy(),self.step)


class KlootwijkKernel:
    """Three-state fast/slow demonstrator driven by three field sample points."""
    def __init__(self, seed: Seed):
        self.seed=seed
        # Explicit generator type; the seed alone is not the complete specification.
        self.rng=np.random.Generator(np.random.PCG64(seed.random_seed))
        def matrix(norm):
            a=self.rng.normal(size=(3,3))
            return a*(norm/np.max(np.sum(np.abs(a),axis=1)))
        self.A=matrix(.35);self.B=matrix(.15);self.C=matrix(.40)
        self.D=matrix(.30);self.E=matrix(.20)
        self.word=grow(Pair.parse(seed.pair),seed.generations)
        self.segments=turtle(self.word)
        self.embedded_segments=.55*self.segments+np.array([0.0,0.10])

    def initial_state(self) -> State:
        return State(np.zeros(3),np.zeros(3),0)

    def observation(self,state: State,points) -> np.ndarray:
        p=finite_array(points,last_dim=2)
        if p.shape!=(3,2): raise ValueError("Exactly three 2D field samples required")
        m=finite_array(state.memory)
        if m.shape!=(3,): raise ValueError("Memory must be a three-vector")
        thickness=self.seed.thickness+self.seed.memory_geometry_gain*math.tanh(float(m[0]))
        phi=m_field(p,self.seed.radius,self.seed.spacing,thickness)
        growth=capsule_field(p,self.embedded_segments,thickness=.018)
        phi=np.maximum(np.minimum(phi,growth),-p[...,1])
        return -np.tanh(phi)

    def advance(self,state: State,points) -> tuple[State, dict]:
        z=finite_array(state.z); m=finite_array(state.memory)
        if z.shape!=(3,) or m.shape!=(3,): raise ValueError("State vectors must have length three")
        u=self.observation(state,points)
        a,e=self.seed.alpha,self.seed.eta
        next_z=(1-a)*z+a*np.tanh(self.A@z+self.B@m+self.C@u)
        next_m=(1-e)*m+e*np.tanh(self.D@z+self.E@u)
        bits=occupancy(-u) # u=-tanh(phi), so -u and phi have the same sign.
        return State(next_z,next_m,state.step+1), {"field_observation":u,"occupancy":bits,"parity":parity(bits)}

    def contraction_bound(self) -> float:
        norm=lambda x:float(np.max(np.sum(np.abs(x),axis=1)))
        a,e,g=self.seed.alpha,self.seed.eta,abs(self.seed.memory_geometry_gain)
        return max(1-a+a*(norm(self.A)+norm(self.B)+norm(self.C)*g),
                   1-e+e*(norm(self.D)+norm(self.E)*g))

    def configuration_digest(self) -> str:
        payload={"seed":self.seed.__dict__,"rules":RULES,"version":VERSION,"rng":"PCG64",
                 "matrices":{k:getattr(self,k).tolist() for k in ["A","B","C","D","E"]}}
        return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()
