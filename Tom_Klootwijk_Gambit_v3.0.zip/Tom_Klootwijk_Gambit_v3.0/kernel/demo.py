"""Reproduce Gambit 3.0 numerical results and plot files. No hardware output."""
from pathlib import Path
import argparse
import csv
import dataclasses
import json
import platform
import sys
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .gambit import GambitSpec,GambitKernel
from .quotient import examples
from .core import KlootwijkKernel,Seed,State,m_field,LogPolarLUT,inverse_log_polar,fwht,parity
from .events import event_roots,toy_field

ROOT=Path(__file__).resolve().parents[1]

def savefig(fig,directory,name):
    directory.mkdir(parents=True,exist_ok=True)
    for ext in ['pdf','png','svg']:
        fig.savefig(directory/(name+'.'+ext),bbox_inches='tight',dpi=160)
    plt.close(fig)

def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path)
    parser.add_argument('--out',type=Path,default=ROOT/'results');args=parser.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    figdir=ROOT/'manuscript'/'figures' if out==ROOT/'results' else out/'figures'
    configs=[args.config] if args.config else [ROOT/'config/seed_xx.json',ROOT/'config/seed_xy.json']
    results={};histories={}
    for config in configs:
        configuration=GambitSpec.load(config);spec=configuration.model;k=GambitKernel(configuration);initial=k.initial_state();state,rows=k.run()
        pair=spec.pair;histories[pair]=rows
        pd=out/pair;pd.mkdir(exist_ok=True)
        (pd/'history.json').write_text(json.dumps(rows,indent=2)+'\n')
        scalar=[{key:value for key,value in r.items() if not isinstance(value,list)} for r in rows]
        write_csv(pd/'trajectory.csv',scalar)
        np.savez_compressed(pd/'final_fields.npz',points=k.grid.points,mask=state.mask,
                            u_mass=state.u,v_mass=state.v,z=state.z,memory=state.memory,
                            generation=state.generation,cell_volume=k.grid.volume,latches=state.latches)
        np.savetxt(pd/'segments.csv',k.segments(state.generation).reshape(-1,4),delimiter=',',header='ax,ay,bx,by',comments='')
        (pd/'configuration_fingerprint.txt').write_text(k.fingerprint()+'\n')
        m0=float(np.sum(initial.u+initial.v));max_mass_error=max(abs(r['mass']-m0) for r in rows)
        results[pair]={'fingerprint':k.fingerprint(),'steps':spec.steps,'initial_mass':m0,
                      'final_mass':rows[-1]['mass'],'maximum_mass_drift':max_mass_error,
                      'minimum_mass':min(r['min_mass'] for r in rows),
                      'max_fast_abs':max(r['z_max'] for r in rows),
                      'max_memory_abs':max(r['memory_max'] for r in rows),
                      'growth_steps':[r['step'] for r in rows if r['growth']],
                      'final_generation':state.generation,'final_active_nodes':int(state.mask.sum()),
                      'maximum_substep_cfl':max(r['cfl'] for r in rows),
                      'prefix_error_min':min(r['prefix_error'] for r in rows),
                      'prefix_error_max':max(r['prefix_error'] for r in rows),
                      'all_codec_certificates':all(r['codec_certificate'] for r in rows),
                      'all_frames_even':all(r['frame_even'] for r in rows),
                      'latch_events':[sum(r['latch_events'][i] for r in rows) for i in range(3)],
                      'gate_multiplier_min':min(r['gate_multiplier'] for r in rows),
                      'gate_multiplier_max':max(r['gate_multiplier'] for r in rows)}
        # Same-generation comparison shows geometry, not a chromosomal model.
        xx=np.linspace(-2.3,2.3,381);yy=np.linspace(-.12,1.7,181);X,Y=np.meshgrid(xx,yy)
        p=np.stack([X,Y],axis=-1);F=k.field(p,spec.max_generation,np.zeros(3))
        fig,ax=plt.subplots(figsize=(7.3,3.65));ax.contour(X,Y,F,levels=[0],linewidths=1.7)
        for a,b in k.segments(spec.max_generation):ax.plot([a[0],b[0]],[a[1],b[1]],linewidth=.6,alpha=.5)
        ax.set_aspect('equal');ax.set_xlabel('x (simulation units)');ax.set_ylabel('y (simulation units)')
        ax.set_title(f'{pair}: seed-generated field at generation {spec.max_generation}')
        savefig(fig,figdir,'geometry_'+pair.lower())
        fig,ax=plt.subplots(figsize=(7.3,3.9))
        values=np.ma.array(state.u/k.grid.volume,mask=~state.mask).reshape(k.grid.shape)
        image=ax.pcolormesh(k.grid.points[:,0].reshape(k.grid.shape),k.grid.points[:,1].reshape(k.grid.shape),values,shading='nearest')
        fig.colorbar(image,ax=ax,label='U concentration (simulation units)')
        ax.set_aspect('equal');ax.set_xlabel('x');ax.set_ylabel('y')
        ax.set_title(f'{pair}: conservative transport, final generation {state.generation}')
        savefig(fig,figdir,'transport_'+pair.lower())
    fig,ax=plt.subplots(figsize=(7.3,3.3))
    for pair,rows in histories.items():
        m0=results[pair]['initial_mass'];ax.plot([r['step'] for r in rows],[(r['mass']-m0)/m0 for r in rows],label=pair)
    ax.set_xlabel('Step');ax.set_ylabel('Relative total-mass drift');ax.set_title('Floating-point conservation residual');ax.legend()
    savefig(fig,figdir,'mass_conservation')
    fig,ax=plt.subplots(figsize=(7.3,3.3))
    for pair,rows in histories.items():ax.plot([r['step'] for r in rows],[r['prefix_error'] for r in rows],label=pair,alpha=.8)
    ax.axhline(-1,linestyle='--',linewidth=.8);ax.axhline(0,linestyle='--',linewidth=.8)
    ax.set_xlabel('Step');ax.set_ylabel('Output count minus dyadic input sum');ax.set_title('One-bit accumulator: every prefix lies in (-1, 0]');ax.legend()
    savefig(fig,figdir,'codec_prefix')
    rows=histories.get('XY',next(iter(histories.values())))
    fig,ax=plt.subplots(figsize=(7.3,3.3))
    for j in range(3):ax.plot([r['step'] for r in rows],[r['z'][j] for r in rows],label=f'z{j+1}')
    for j in range(3):ax.plot([r['step'] for r in rows],[r['memory'][j] for r in rows],linestyle='--',label=f'm{j+1}')
    ax.set_xlabel('Step');ax.set_ylabel('State value');ax.set_title('Fast recurrence and slower memory (synthetic XY run)');ax.legend(ncol=3)
    savefig(fig,figdir,'state_memory')
    roots=[]
    for kappa in [.5,1.0]:
        rr,status=event_roots(1.1,kappa,r0=.3,speed=2,t0=4)
        for r in rr: roots.append({'kappa':kappa,**dataclasses.asdict(r),'residual':toy_field(r.rho,1.1,kappa)})
    write_csv(out/'root_variants.csv',roots)
    # Auxiliary legacy geometry/memory contraction check: not the hybrid chemical loop.
    k=KlootwijkKernel(Seed());a=State(np.array([1.,-.3,.2]),np.array([-.5,.2,.4]));b=k.initial_state()
    bound=k.contraction_bound();sep=[];points=np.array([[.09,.31],[-.09,.31],[.04,.68]])
    for step in range(181):
        d=max(np.max(abs(a.z-b.z)),np.max(abs(a.memory-b.memory)))
        sep.append({'step':step,'separation':float(d),'envelope':float(bound**step)})
        a,_=k.advance(a,points);b,_=k.advance(b,points)
    write_csv(out/'frozen_loop_contraction.csv',sep)
    fig,ax=plt.subplots(figsize=(7.3,3.3));ax.semilogy([r['step'] for r in sep],[r['separation'] for r in sep],label='Observed separation')
    ax.semilogy([r['step'] for r in sep],[r['envelope'] for r in sep],linestyle='--',label='q^n bound')
    ax.set_xlabel('Step');ax.set_ylabel('Infinity-norm separation');ax.set_title('Auxiliary fixed-input recurrence only; not global hybrid stability');ax.legend()
    savefig(fig,figdir,'frozen_contraction')
    lut=LogPolarLUT.build(m_field);rng=np.random.default_rng(70)
    coords=rng.uniform([-.8,-np.pi],[1,np.pi],(1000,2))
    p=inverse_log_polar(coords);approx,cert=lut.query(p);error=abs(approx-m_field(p))
    results['auxiliary']={'frozen_contraction_bound':bound,'separation_at_180':sep[-1]['separation'],
                          'envelope_at_180':sep[-1]['envelope'],
                          'root_max_residual':max(abs(r['residual']) for r in roots),
                          'lut_max_error_1000':float(np.max(error)),
                          'lut_certificate_violations_1000':int(np.sum(error>cert+1e-12))}
    results['environment']={'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,
                             'matplotlib':matplotlib.__version__,'platform':platform.platform()}
    (out/'quotient_examples.json').write_text(json.dumps(examples(),indent=2)+'\n')
    rows=histories.get('XY',next(iter(histories.values())))
    fig,ax=plt.subplots(figsize=(7.3,3.6))
    for j in range(3):
        ax.step([r['step'] for r in rows],[r['latches'][j]+1.4*j for r in rows],where='post',label=f'Hinge {j+1}')
    ax.set_xlabel('Step');ax.set_ylabel('Latch bit (vertically offset)')
    ax.set_title('Three one-bit hinges with explicitly configured causal gate control')
    ax.legend(ncol=3);savefig(fig,figdir,'hinge_history')
    fig,ax=plt.subplots(figsize=(7.3,3.4))
    ax.plot([r['step'] for r in rows],[r['field_values'][0] for r in rows],label='Sampled field')
    threshold=rows[0]['hinge_threshold']
    ax.axhline(threshold,linestyle='--',label='+ threshold');ax.axhline(-threshold,linestyle=':',label='- threshold')
    ax.set_xlabel('Step');ax.set_ylabel('Boundary-field value');ax.set_title('Hysteresis sample stream (XY first probe)')
    ax.legend();savefig(fig,figdir,'hinge_thresholds')
    (out/'metrics.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
