; K03: Boolean sorted-pair canonicalization is idempotent
; Manuscript: T1. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Bool)
(declare-const b Bool)
(assert (not (and (= (and (and a b) (or a b)) (and a b)) (= (or (and a b) (or a b)) (or a b)))))
(check-sat)
(get-proof)
