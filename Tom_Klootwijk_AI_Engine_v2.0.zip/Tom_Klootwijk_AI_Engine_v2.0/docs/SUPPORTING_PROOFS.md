**Tom Klootwijk AI Engine 2.0.0**  
**Author: Tom Klootwijk · NL200678942 · 10-07-1990**

# Twelve supporting lemmas and proofs

**Lemma L1** (Word algebra, pairing and finite replay). Pair exchange preserves pair parity and canonicalization. Symbol exchange $X\leftrightarrow Y$, together with $+\leftrightarrow-$, is an involution commuting with the grammar. At generation $g$, $$N_X+N_Y=2\,3^g,\quad N_X-N_Y=N_X(0)-N_Y(0),\quad |w_g|=5\,3^g+1.$$ With reflected initial pose, the exchanged word emits the reflected segment sequence. Complete deterministic initialization and transitions imply unique finite replay.

Proof. XOR is addition in $\mathbb{F}_2$, and sorting a pair is exchange-invariant and idempotent. Inspection of the two productions gives $P(Jw)=J(Pw)$, where this $J$ denotes token exchange. The count vector is multiplied by $\left(\begin{smallmatrix}2&1\\1&2\end{smallmatrix}\right)$; its sum triples and its difference is unchanged. Initially $|w_0|=6$. Each draw token is replaced by six tokens, so $|w_{g+1}|-|w_g|=5(2\,3^g)$, yielding the stated formula. Turn reversal under spatial reflection, with stack save/restore, proves interpreter covariance by induction on tokens. Induction on deterministic time steps proves replay. These statements do not make the seed-to-output map injective. ◻

**Lemma L2** (Set semantics, Lipschitz closure and the conditional fold). Finite minima encode closed-set unions, maxima encode intersections, and finite min/max compositions of 1-Lipschitz fields are 1-Lipschitz. For the paired arcs, a near-side fold is valid when the translated right arc lies wholly in $x\geq0$; $h\geq R\sin\alpha$ suffices. Composite membership does not imply exact interior signed distance.

Proof. $\min(f,g)\leq0$ iff $f\leq0$ or $g\leq0$; the analogous maximum gives "and". If both $f$ and $g$ change by at most $e$ between two points, their minimum and maximum also change by at most $e$. Induction proves the finite statement. For a query $x\geq0$ and any right-arc point with horizontal coordinate $u\geq0$, $(x-u)^2\leq(x+u)^2$, so the corresponding reflected point is never closer. Taking minima proves the fold in that regime.

For a counterexample outside it, take $R=1$, $h=0.5$, $\alpha=\pi/2$, thickness $0.1$ and query $(0.5,0)$. The explicit union field is $-0.1$ but the fold gives $0.9$. For a separate metric counterexample, two unit disks centered at $(\pm0.5,0)$ give minimum signed distance $-0.5$ at the origin, while the actual signed distance to the union boundary is $-\sqrt{3}/2$. Correct membership and a Lipschitz bound therefore do not imply exact negative distance magnitude. Conservative distance reasoning is standard context, not a consciousness result. [\[E2\]] ◻

**Lemma L3** (Rigid hinges preserve geometry, not a forced bit flip). For Euclidean isometry $T(x)=Qx+b$, $Q^TQ=I$, $d_{T\Omega}(Tx)=d_\Omega(x)$. A reflection can reverse orientation while preserving occupancy. A global change of frame preserves consistently transformed observations; arbitrary resampling on a fixed Cartesian raster is a separate operation.

Proof. $\left\lVert Tx-Ty\right\rVert=\left\lVert Q(x-y)\right\rVert=\left\lVert x-y\right\rVert$. Taking the infimum over the set or its boundary preserves distances, and the bijection preserves interior membership. Orientation is determined by $\det Q$, while occupancy depends on membership; neither determines the other. Covariance of vector projections follows by transforming both vectors by $Q$. A grid after an arbitrary rotation is usually not the original node set, so no exact raster permutation is supplied by the continuous identity alone. ◻

**Lemma L4** (Chart metric, event roots and bracket error). The log-polar metric and roots in Sections 3--4 follow from the declared coordinate and trajectory maps. A sign-changing continuous function on a finite bracket has a zero in it; $n$ bisections reduce bracket width by $2^{-n}$. A tangent zero need not be detected by opposite-sign tests.

Proof. Differentiate $x=r_0e^\rho(\cos\theta,\sin\theta)$: the two coordinate derivatives are orthogonal with equal length $r_0e^\rho$, giving the metric. In Eq. (17), a product vanishes exactly when a factor does. Solving those factors yields the stated $\rho$ roots, with no second-factor root when its sine coefficient is zero. Substitution into $\rho=\log(c_s(t-t_0)/r_0)$ gives Eq. (19). Exponent pairs multiply to one in normalized delay. The intermediate value theorem preserves a root-containing sign bracket, and each chosen half has half its width. The example $f(t)=(t-a)^2$ proves why a zero need not change sign. ◻

**Lemma L5** (Closed graph transport and dissipative diffusion). A finite column generator $Q$ with nonnegative off-diagonal entries and zero column sums gives a nonnegative column-stochastic $P=I+\delta t Q$ whenever $\delta t\max(-Q_{ii})\leq1$. It preserves mass, nonnegativity and is nonexpansive in $\ell^1$. For symmetric diffusion, $$x^TL_hx=-\sum_{\{i,j\}\in E}w_{ij}(x_i-x_j)^2\leq0.$$

Proof. The step bound makes every diagonal of $P$ nonnegative; off-diagonals already are. Its columns sum to one. Therefore $P\mu\geq0$ for $\mu\geq0$ and $\mathbf{1}^TP\mu=\mathbf{1}^T\mu$. For any signed vector $x$, the triangle inequality gives $\sum_i|\sum_jP_{ij}x_j|\leq\sum_j|x_j|\sum_iP_{ij}=\left\lVert x\right\rVert_1$. For symmetric edge weights, collect the contributions of the two endpoints of each edge in $x^TL_hx$ to obtain $-w_{ij}(x_i-x_j)^2$. Constants lie in the kernel; disconnected components supply additional constant modes. ◻

**Lemma L6** (Positive, locally conservative reaction). The reversible conversion step of Section 5 preserves $u_i+v_i$ at each node and maps nonnegative pairs to nonnegative pairs under the stated step bound. Products of such substeps have the same properties.

Proof. All four reaction-matrix entries are nonnegative and each column sums to one. Matrix multiplication therefore preserves the nonnegative cone and the left invariant $(1,1)$. A product of column-stochastic nonnegative matrices remains in that class. If arbitrary nonlinear reactions are substituted, these premises must be re-established; the theorem is not inherited merely by naming a reaction function. ◻

**Lemma L7** (Conservative geometry changes). A nonnegative column-stochastic remap $\Pi$ preserves nonnegative total mass across domains of different sizes. With cell-volume matrices $V,V'$, $c'=(V')^{-1}\Pi Vc$ preserves integrated concentration. Deleting outside samples without transferring their mass is not this operation.

Proof. Let $\mu=Vc$. Then $\mu'=\Pi\mu\geq0$ and $\mathbf{1}^T\mu'=\mathbf{1}^T\mu$. The concentration formula is just the positive diagonal change of representation. In the nearest-node implementation, each old node's mass has one destination, including itself when retained; each remap column contains one unit entry. A finite index tie rule makes the result deterministic. An arbitrary relabeling must transform that priority rule as well, or tie covariance can fail. ◻

**Lemma L8** (Bounded state and mutable memory). The recurrent laws in Eq. (32) leave the cube $[-1,1]^{2d}$ invariant. More generally, if $m_{n+1}=(1-\eta)m_n+\eta\psi_n$ with $\left\lVert \psi_n\right\rVert_\infty\leq B$, then $$\left\lVert m_n\right\rVert_\infty\leq(1-\eta)^n\left\lVert m_0\right\rVert_\infty+
[1-(1-\eta)^n]B.$$

Proof. Each scalar $\tanh$ lies between $-1$ and $1$. A convex combination of values in that interval stays in it. For the more general bound, repeatedly substitute the affine recurrence and bound its geometric series. Memory in this model is a mutable state variable whose influence can decay or change. Boundedness neither implies permanent storage nor identifies the physical substrate of human memory. ◻

**Lemma L9** (One-bit error, parity and Hadamard structure). The integer accumulator satisfies U1(e). If input coverage $a_n\in[0,1]$ is rounded to $k_n/D_c$ by nearest-half-up, then in ideal real arithmetic $$\left|\sum_{j<n}q_j-\sum_{j<n}a_j\right|
<1+\frac{n}{2D_c}.$$ Parity is addition modulo two. The normalized Walsh--Hadamard transform is a real orthogonal involution, not a one-bit XOR reduction.

Proof. The residual induction and telescoping identity are given in U1. The rounding error of each input is at most $1/(2D_c)$; add these errors to the strict dyadic prefix bound. The implementation's integer certificate is exact for its emitted $k_n$ values; the separate conversion from arbitrary floating-point coverage remains part of numerical arithmetic.

For set indicators, $\mathbf{1}_{A\triangle B}=\mathbf{1}_A\oplus\mathbf{1}_B$ pointwise. Appending the XOR of a finite payload makes total parity zero. Odd numbers of flipped bits are detected; even numbers can evade this check. This does not recover lost distances or encrypt a payload.

For binary indices $a,b\in\mathbb{F}_2^r$, set $H_{ab}=(-1)^{a\cdot b}$. Distinct rows sum to zero in their inner product by pairing indices on a differing bit; identical rows have squared norm $2^r$. Thus $HH^T=2^rI$ and $U=2^{-r/2}H$ is orthogonal with $U^2=I$. The parity appears inside an exponent that defines real matrix entries. The complete transform retains dimensions and accepts asymmetric vectors; it does not imply a quantum electron-memory mechanism. ◻

**Lemma L10** (Observational and semantic non-identification). An interpretation label absent from the transition and observation laws cannot change observable histories under identical numerical inputs. A finite occupancy record does not identify the full field, and model traces alone do not select an unmeasured consciousness ontology.

Proof. If the label does not enter any map, equal states and inputs produce equal next states and outputs regardless of label. Induction proves equality of histories. Likewise, two different positive values have the same outside bit; finitely many such signs leave infinitely many compatible field assignments. The numerical invariants therefore cannot identify an interpretation that has not been linked to distinct observations. This proves a measurement limitation, not the falsity or truth of any spiritual interpretation. ◻

**Lemma L11** (Conditional recurrent contraction). For a fixed generation, common prescribed probes and no state-dependent chemistry difference, suppose the observation law has memory Lipschitz constant $L_y$. In the joint infinity norm, a sufficient contraction factor for Eq. (32) is $$\begin{aligned}
q=\max\{&1-\alpha+\alpha(\left\lVert A\right\rVert_\infty+\left\lVert B\right\rVert_\infty+\left\lVert C\right\rVert_\infty L_y),\\
&1-\eta+\eta(\left\lVert D\right\rVert_\infty+\left\lVert E\right\rVert_\infty L_y)\}.
\end{aligned}$$ If $q<1$, two such trajectories contract by at most $q$ per step. This is not an unconditional contraction claim for the hybrid growth/transport system.

Proof. $\tanh$ is 1-Lipschitz. Subtract the state equations, apply the induced matrix infinity norm, and bound both state differences by their joint maximum. The resulting two nonnegative row bounds give $q$. Iteration gives $q^n$ times initial separation. A fixed-point conclusion additionally needs a time-independent self-map. If masks, gates, chemistry or trigger decisions change differently between the trajectories, the observation bound used in this argument is not supplied. The retained auxiliary geometry-only model has $L_y=0.04$ and $q=0.94464$; that numeric factor must not be transferred to the v2 coupled chemical loop. ◻

**Lemma L12** (Perturbation margins and limits of pattern claims). For finite sample sites $p_i$, if $\epsilon<\min_i|F(p_i)|$ and $|\widetilde F(p_i)-F(p_i)|\leq\epsilon$, then the two sampled masks coincide. In the fixed, symmetric diffusion-only graph with positive reversible reaction rates and nonnegative diffusivities, the two-species reaction has no diffusion-driven growing eigenmode.

Proof. A perturbation smaller than the distance of a scalar sample from zero cannot change its sign, proving the mask claim. If a sample lies exactly on the boundary, its margin is zero and the claim gives no protection. Consequently, a seed-bit change does not necessarily change topology or a pattern.

For a Laplacian eigenmode with $L_hx=-\lambda x$, $\lambda\geq0$, the reaction--diffusion mode matrix is $$M_\lambda=\begin{pmatrix}-a-D_U\lambda&b\\a&-b-D_V\lambda\end{pmatrix}.$$ Its trace is negative and its determinant is $(aD_V+bD_U)\lambda+D_UD_V\lambda^2\geq0$. The eigenvalues therefore have nonpositive real parts. The zero spatial mode has a conserved direction. This minimal model can redistribute an initial pattern and react to geometry changes, but it is not evidence that a seed necessarily generates self-organized Turing patterns. That stronger corpus statement would require a different reaction law and an instability analysis. [\[C4, pp. 14--15\]] ◻


See the full manuscript for definitions, source audit and verification limits.
