# Research plan and failure criteria

## Computational ablation
Compare the complete loop with frozen geometry, frozen memory, geometry-free graphs matched on node count, and transport-free baselines. Choose a downstream task and metric in advance. Match parameters, input histories and compute budgets. The present demonstration is not such a predictive experiment. A control that predicts as well or better weakens the proposed explanatory role of the removed layer.

## Seed and geometry sensitivity
Perturb angle, radius or pair while recording continuous field error, sampled-margin certificates, mask differences, connectivity and state outputs. L12 predicts unchanged signs when perturbation is smaller than every sample's nonzero margin. A seed change need not change topology, and distinct seeds can have identical early masks. Report parameter regions where the margin certificate is unavailable.

## Conservation and numerical validity
Test stationary, growing and shrinking domains. Test closed systems separately from explicit sources and sinks. Check positivity before postprocessing. Record remapping artifacts, gate sensitivity and resolution changes. A continuum claim needs a convergence study and reference solution; the present theorem establishes finite invariants only.

## Empirical bridge to consciousness
Choose specific observables such as task reports or coded first-person accounts, with measured inputs, consent and appropriate oversight. Define the readout, fit only on training data and evaluate held-out observations and interventions against matched alternatives. Do not use personal IDs, token pairings or geometry labels as proxies for awareness. No human study is included here.

## Interpretation and extension
Keep bodily measurements, digital states and spiritual meanings distinct. An unobserved label cannot be selected by outputs that ignore it (L10). A future physical implementation needs an explicit realization map, measured error and latency. A new scientific claim must survive its own discriminating tests rather than inherit credibility from the arithmetic checks.
