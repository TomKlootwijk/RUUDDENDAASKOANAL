; K27: Stochastic remap preserves nonnegativity
; Manuscript: L7. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Real)
(declare-const b Real)
(declare-const u Real)
(declare-const v Real)
(assert (not (=> (and (<= 0 a) (<= a 1) (<= 0 b) (<= b 1) (>= u 0) (>= v 0)) (and (>= (+ (* a u) (* b v)) 0) (>= (+ (* (- 1 a) u) (* (- 1 b) v)) 0)))))
(check-sat)
(get-proof)
