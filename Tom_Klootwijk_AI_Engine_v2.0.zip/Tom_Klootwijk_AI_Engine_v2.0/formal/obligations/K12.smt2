; K12: XOR equals integer sum modulo two
; Manuscript: L9. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const a Bool)
(declare-const b Bool)
(assert (not (= (ite (xor a b) 1 0) (mod (+ (ite a 1 0) (ite b 1 0)) 2))))
(check-sat)
(get-proof)
