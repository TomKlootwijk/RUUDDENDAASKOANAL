"""Run SMT-LIB obligations using Z3 executable or the installed Z3 C library.

No solver binary is bundled. Install Z3 separately to rerun. This adapter uses
only official C entry points through ctypes; it does not reinterpret proofs.
"""
from pathlib import Path
import ctypes
import ctypes.util
import json
import os
import re
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

def library_runner():
    name=os.environ.get('Z3_LIBRARY') or ctypes.util.find_library('z3')
    if not name:raise RuntimeError('Install Z3 or set Z3_LIBRARY to its shared library path')
    lib=ctypes.CDLL(name);p=ctypes.c_void_p;s=ctypes.c_char_p
    for fn,args,res in [('Z3_mk_config',[],p),('Z3_mk_context',[p],p),('Z3_del_config',[p],None),('Z3_del_context',[p],None),('Z3_eval_smtlib2_string',[p,s],s),('Z3_get_full_version',[],s)]:
        f=getattr(lib,fn);f.argtypes=args;f.restype=res
    def run(text):
        cfg=lib.Z3_mk_config();ctx=lib.Z3_mk_context(cfg);lib.Z3_del_config(cfg)
        try:return lib.Z3_eval_smtlib2_string(ctx,text.encode()).decode()
        finally:lib.Z3_del_context(ctx)
    return run,lib.Z3_get_full_version().decode()

def main():
    exe=shutil.which('z3')
    if exe:
        version=subprocess.check_output([exe,'-version'],text=True).strip()
        def run(text):
            p=subprocess.run([exe,'-in'],input=text,text=True,capture_output=True,timeout=20)
            if p.returncode:raise RuntimeError(p.stderr or p.stdout)
            return p.stdout
    else:run,version=library_runner()
    out=ROOT/'results'/'formal';out.mkdir(parents=True,exist_ok=True)
    entries=[]
    for f in sorted((ROOT/'formal'/'obligations').glob('*.smt2')):
        output=run(f.read_text())
        (out/(f.stem+'.proof.txt')).write_text(output)
        statuses=re.findall(r'^(unsat|sat|unknown)\s*$',output,re.M)
        ok=statuses==['unsat'] and '(proof' in output and '(error' not in output
        entries.append({'id':f.stem,'result':statuses,'proof_log_present':'(proof' in output,'passed':ok})
        print(f'{f.stem}: {"PASS" if ok else "FAIL"} ({",".join(statuses)})')
    report={'solver':'Z3','version':version,'scope':'SMT obligations only; neither the full Python implementation nor consciousness is machine-proved','obligations':entries,'passed':bool(entries) and all(x['passed'] for x in entries)}
    (ROOT/'results'/'formal_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Z3',version,'; passed',sum(x['passed'] for x in entries),'of',len(entries))
    return 0 if report['passed'] else 1
if __name__=='__main__':sys.exit(main())
