; K39: A causal latch multiplier keeps permeability within bounds
; Manuscript: U3(g). Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const g Real)
(declare-const l Real)
(declare-const b Bool)
(define-fun h () Real (* g (+ l (* (- 1 l) (ite b 1 0)))))
(assert (not (=> (and (<= 0 g) (<= g 1) (<= 0 l) (<= l 1)) (and (<= 0 h) (<= h 1)))))
(check-sat)
(get-proof)
