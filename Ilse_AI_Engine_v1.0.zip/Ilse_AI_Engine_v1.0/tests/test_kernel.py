"""Numerical and discrete regression tests. These do not prove human consciousness."""
import math
import unittest
from fractions import Fraction
import numpy as np
from kernel.core import *
from kernel.spatial import CapsuleBVH

class PairTests(unittest.TestCase):
    def test_pair_parity_table(self):
        self.assertEqual([Pair.parse(x).parity for x in ['XX','XY','YX','YY']],[0,1,1,0])
    def test_canonical_exchange(self):
        self.assertEqual(Pair.parse('XY').canonical,Pair.parse('YX').canonical)
    def test_pair_invalid(self):
        for x in ['Z','XZ','XXX','']:
            with self.assertRaises(ValueError):Pair.parse(x)
    def test_exact_mixing_law(self):
        self.assertEqual(mix_pairs(Pair.parse('XX'),Pair.parse('XY')),{'XX':Fraction(1,2),'XY':Fraction(1,2)})
    def test_pair_order_retained(self):
        self.assertNotEqual(Pair.parse('XY').axiom,Pair.parse('YX').axiom)

class GrowthTests(unittest.TestCase):
    def test_parallel_not_inplace(self):self.assertEqual(rewrite('XY'),'X[+X]YY[-Y]X')
    def test_count_theorem(self):
        for pair in ['XX','XY','YX','YY']:
            d0=pair.count('X')-pair.count('Y')
            for n in range(7):
                w=grow(Pair.parse(pair),n)
                self.assertEqual(w.count('X')+w.count('Y'),2*3**n)
                self.assertEqual(w.count('X')-w.count('Y'),d0)
                self.assertEqual(len(w),5*3**n+1)
    def test_mirror_rewrite_commutes(self):
        w=grow(Pair.parse('XY'),3)
        self.assertEqual(swap_word(rewrite(w)),rewrite(swap_word(w)))
    def test_involution(self):self.assertEqual(swap_word(swap_word('X[+Y]X')),'X[+Y]X')
    def test_turtle_reflection(self):
        w=grow(Pair.parse('XX'),3)
        np.testing.assert_allclose(turtle(swap_word(w)),turtle(w)*[-1,1],atol=2e-14)
    def test_balanced_brackets(self):
        for p in ['XX','XY']:
            s=turtle(grow(Pair.parse(p),4));self.assertEqual(s.shape,(162,2,2))
        for w in ['X]','[X']:
            with self.assertRaises(ValueError):turtle(w)
    def test_growth_budget(self):
        with self.assertRaises(ValueError):grow(Pair.parse('XY'),8,1000)
    def test_invalid_generation(self):
        with self.assertRaises(ValueError):grow(Pair.parse('XY'),-1)

class FieldTests(unittest.TestCase):
    def test_segment_distance(self):np.testing.assert_allclose(distance_segment([[.5,1],[-1,0],[2,0]],[0,0],[1,0]),[1,1,1])
    def test_degenerate_segment(self):self.assertEqual(float(distance_segment([3,4],[0,0],[0,0])),5)
    def test_arc_landmarks(self):np.testing.assert_allclose(distance_arc([[0,1],[1,0],[0,0],[0,-1]]),[0,0,1,math.sqrt(2)],atol=1e-12)
    def test_arc_against_dense_centerline(self):
        rng=np.random.default_rng(9);p=rng.uniform(-2,2,(80,2));a=.8
        t=np.linspace(-a,a,20001);curve=np.stack([np.sin(t),np.cos(t)],-1)
        brute=np.linalg.norm(p[:,None,:]-curve[None,:,:],axis=-1).min(axis=1)
        np.testing.assert_allclose(distance_arc(p,aperture=a),brute,atol=8e-5)
    def test_fold_valid_regime(self):
        p=np.random.default_rng(3).normal(size=(300,2))
        np.testing.assert_allclose(paired_arcs(p,spacing=1.1),paired_arcs(p,spacing=1.1,folded=True),atol=2e-14)
    def test_fold_counterexample(self):
        p=[.5,0]
        self.assertAlmostEqual(float(paired_arcs(p,spacing=.5,thickness=.1)),-.1)
        self.assertAlmostEqual(float(paired_arcs(p,spacing=.5,thickness=.1,folded=True)),.9)
    def test_clipping(self):self.assertGreater(float(m_field([0,-.01])),0)
    def test_membership_closed(self):np.testing.assert_array_equal(occupancy([-1,0,1]),[1,1,0])
    def test_mirror_not_bit_flip(self):
        p=np.random.default_rng(4).normal(size=(100,2))
        np.testing.assert_array_equal(occupancy(m_field(p)),occupancy(m_field(p*[-1,1])))
    def test_one_lipschitz(self):
        rng=np.random.default_rng(5);p=rng.normal(size=(1000,2));q=rng.normal(size=(1000,2))
        self.assertTrue(np.all(np.abs(m_field(p)-m_field(q))<=np.linalg.norm(p-q,axis=-1)+1e-12))
    def test_union_not_exact_signed_distance(self):
        component_min=-.5;true_union=-math.sqrt(.75)
        self.assertGreater(abs(component_min-true_union),.3)
    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError):m_field([float('nan'),0])

class ChartAndRootTests(unittest.TestCase):
    def test_chart_roundtrip(self):
        p=np.array([[.3,.4],[-2,.1],[1,-3]])
        np.testing.assert_allclose(inverse_log_polar(log_polar(p,reference=.2),reference=.2),p,atol=1e-12)
    def test_origin_rejected(self):
        with self.assertRaises(ValueError):log_polar([0,0])
    def test_lut_error_certificate(self):
        lut=LogPolarLUT.build(m_field)
        q=np.random.default_rng(7).uniform([-.8,-math.pi],[1,math.pi],(120,2))
        p=inverse_log_polar(q);v,e=lut.query(p)
        self.assertTrue(np.all(np.abs(v-m_field(p))<=e+1e-12))
    def test_lut_angular_seam(self):
        lut=LogPolarLUT.build(m_field)
        v,_=lut.query([[1,1e-10],[1,-1e-10]])
        self.assertLess(abs(v[0]-v[1]),1e-8)
    def test_lut_domain_rejection(self):
        with self.assertRaises(ValueError):LogPolarLUT.build(m_field).query([8,0])
    def test_bisection_root_and_certificate(self):
        r=bisect_root(lambda t:t*t-2,1,2)
        self.assertTrue(r.lower<=math.sqrt(2)<=r.upper)
        self.assertLessEqual(abs(r.value-math.sqrt(2)),(r.upper-r.lower)/2+1e-15)
    def test_bisection_endpoint(self):self.assertEqual(bisect_root(lambda t:t,0,2).value,0)
    def test_no_bracket_rejected(self):
        with self.assertRaises(ValueError):bisect_root(lambda t:t*t+1,-1,1)
    def test_tangent_not_claimed_found(self):
        with self.assertRaises(ValueError):bisect_root(lambda t:(t-.1)**2,-1,1)

class CodingAndSensingTests(unittest.TestCase):
    def test_even_parity_all_bytes(self):
        for x in range(256):self.assertEqual(parity(append_even_parity([(x>>j)&1 for j in range(8)])),0)
    def test_single_fault_detected(self):
        b=list(append_even_parity([1,0,0,1]));b[2]^=1;self.assertEqual(parity(b),1)
    def test_two_faults_not_detected(self):
        b=list(append_even_parity([1,0,0,1]));b[1]^=1;b[2]^=1;self.assertEqual(parity(b),0)
    def test_bad_bit_rejected(self):
        with self.assertRaises(ValueError):parity([0,2])
    def test_dither_endpoint(self):np.testing.assert_array_equal(bernoulli_encode([0,1],np.random.default_rng(1)),[0,1])
    def test_dither_mean(self):
        b=bernoulli_encode(np.full(30000,.37),np.random.default_rng(8))
        self.assertLess(abs(b.mean()-.37),.01)
    def test_hadamard_involution(self):
        x=np.random.default_rng(8).normal(size=32);np.testing.assert_allclose(fwht(fwht(x)),x,atol=1e-12)
    def test_hadamard_energy(self):
        x=np.arange(8.);self.assertAlmostEqual(np.dot(fwht(x),fwht(x)),np.dot(x,x))
    def test_hadamard_size_rejected(self):
        with self.assertRaises(ValueError):fwht([1,2,3])
    def test_eye_separation(self):self.assertAlmostEqual(np.linalg.norm(np.diff(stereo_eyes(.064),axis=0)),.064)
    def test_itd_front_zero(self):self.assertAlmostEqual(itd_seconds([0,0,2],[-.09,0,0],[.09,0,0]),0)
    def test_itd_reverse_sign(self):
        l=[-.09,0,0];r=[.09,0,0];self.assertAlmostEqual(itd_seconds([2,0,1],l,r),-itd_seconds([-2,0,1],l,r))
    def test_itd_bound(self):
        v=itd_seconds([2,0,1],[-.09,0,0],[.09,0,0]);self.assertLessEqual(abs(v),.18/343)

class StateAndBVHTests(unittest.TestCase):
    def setUp(self):self.points=np.array([[.09,.31],[-.09,.31],[.04,.68]])
    def test_replay_identical(self):
        a=IlseKernel(Seed());b=IlseKernel(Seed());s=a.initial_state();t=b.initial_state()
        for _ in range(6):s,_=a.advance(s,self.points);t,_=b.advance(t,self.points)
        np.testing.assert_array_equal(s.z,t.z);np.testing.assert_array_equal(s.memory,t.memory)
        self.assertEqual(a.configuration_digest(),b.configuration_digest())
    def test_states_bounded(self):
        k=IlseKernel(Seed());s=State(np.array([1.,-1.,1.]),np.array([-1.,1.,-1.]))
        for _ in range(6):
            s,_=k.advance(s,self.points)
            self.assertTrue(np.all(np.abs(s.z)<=1));self.assertTrue(np.all(np.abs(s.memory)<=1))
    def test_closed_loop_contraction(self):
        k=IlseKernel(Seed());a=State(np.array([1.,-.3,.2]),np.array([-.5,.2,.4]));b=k.initial_state()
        q=k.contraction_bound();self.assertAlmostEqual(q,.94464)
        for _ in range(8):
            old=max(np.max(np.abs(a.z-b.z)),np.max(np.abs(a.memory-b.memory)))
            a,_=k.advance(a,self.points);b,_=k.advance(b,self.points)
            new=max(np.max(np.abs(a.z-b.z)),np.max(np.abs(a.memory-b.memory)))
            self.assertLessEqual(new,q*old+1e-14)
    def test_pair_changes_growth_field(self):
        a=IlseKernel(Seed(pair='XX'));b=IlseKernel(Seed(pair='XY'))
        pts=np.array([[.095,.6772],[.09,.67],[.10,.68]])
        self.assertGreater(np.max(np.abs(a.observation(a.initial_state(),pts)-b.observation(b.initial_state(),pts))),1e-4)
    def test_memory_changes_field(self):
        k=IlseKernel(Seed());a=k.initial_state();b=State(np.zeros(3),np.array([1.,0,0]))
        pts=np.array([[1,1.04],[1,1.1],[-1,1.05]])
        self.assertGreater(np.max(np.abs(k.observation(a,pts)-k.observation(b,pts))),.005)
    def test_bvh_matches_exhaustive(self):
        s=turtle(grow(Pair.parse('XY'),4));b=CapsuleBVH(s)
        for p in np.random.default_rng(42).uniform([-.7,-.2],[.7,1.6],(40,2)):
            value,count=b.query(p)
            self.assertAlmostEqual(value,float(capsule_field(p,s)),places=12)
            self.assertLessEqual(count,len(s))
    def test_bvh_degenerate_segment(self):
        b=CapsuleBVH([[[0,0],[0,0]]]);self.assertAlmostEqual(b.query([3,4])[0],4.97)
    def test_invalid_seed(self):
        with self.assertRaises(ValueError):Seed(thickness=.01,memory_geometry_gain=.02)

if __name__=='__main__':unittest.main(verbosity=2)
