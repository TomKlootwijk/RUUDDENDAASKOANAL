; K19: Convex slow-memory update preserves a bounded interval
; Manuscript: L8. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const m Real)
(declare-const v Real)
(declare-const eta Real)
(define-fun nxt () Real (+ (* (- 1 eta) m) (* eta v)))
(assert (not (=> (and (<= -1 m) (<= m 1) (<= -1 v) (<= v 1) (<= 0 eta) (<= eta 1)) (and (<= -1 nxt) (<= nxt 1)))))
(check-sat)
(get-proof)
