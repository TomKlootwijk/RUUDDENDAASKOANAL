; K18: Unnormalized two-point Hadamard squared is twice identity
; Manuscript: L9. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const x Real)
(declare-const y Real)
(assert (not (and (= (+ (+ x y) (- x y)) (* 2 x)) (= (- (+ x y) (- x y)) (* 2 y)))))
(check-sat)
(get-proof)
