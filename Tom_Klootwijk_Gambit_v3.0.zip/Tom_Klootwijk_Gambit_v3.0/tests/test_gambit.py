"""Edition 3.0 finite checks. Not empirical tests of consciousness."""
import dataclasses
import itertools
import json
import math
from pathlib import Path
import tempfile
import unittest
import numpy as np
from kernel.gambit import (ALPHABET,GambitSpec,GambitKernel,HingeSpec,latch_update,
                           replay_latch,certified_latch_trace)
from kernel.unified import ModelSpec,UnifiedKernel
from kernel.quotient import (FiniteMachine,analyse_quotient,quotient_machine,
                             minimum_state_bits,examples)
from kernel.editing import edit_word,translate_segments,reflection_closure
from kernel.core import Pair,turtle,grow,capsule_field,m_field

ROOT=Path(__file__).resolve().parents[1]

class AlphabetTests(unittest.TestCase):
    def test_alphabet_is_set(self):
        self.assertIsInstance(ALPHABET,frozenset);self.assertEqual(len(ALPHABET),6)
    def test_grammar_word_closure(self):
        for p in ['XX','XY','YX','YY']:
            for g in range(5):self.assertLessEqual(set(grow(Pair.parse(p),g)),ALPHABET)
    def test_pair_multiplicity_is_not_erased(self):
        self.assertEqual(len(Pair.parse('XX').word),2);self.assertNotEqual(Pair.parse('XX'),Pair.parse('XY'))
    def test_boolean_selector_is_not_complete_seed(self):
        self.assertGreater(len(GambitSpec().numeric_record()),2)
        self.assertNotEqual(GambitSpec(ModelSpec(pair='XX')),GambitSpec(ModelSpec(pair='XY')))

class HingeTests(unittest.TestCase):
    def test_inside_sets(self):self.assertEqual(latch_update(0,-.2,.1),(1,1))
    def test_outside_resets(self):self.assertEqual(latch_update(1,.2,.1),(0,1))
    def test_band_holds_both_states(self):
        for b in [0,1]:self.assertEqual(latch_update(b,0,.1),(b,0))
    def test_threshold_tie_policy(self):
        self.assertEqual(latch_update(0,-.1,.1),(1,1));self.assertEqual(latch_update(1,.1,.1),(0,1))
    def test_zero_is_not_automatically_an_event(self):
        self.assertEqual(replay_latch([0,0,0],.1,0),([0,0,0],[0,0,0]))
    def test_event_parity_telescopes(self):
        for xs in itertools.product([-.2,0,.2],repeat=5):
            for b0 in [0,1]:
                states,events=replay_latch(xs,.1,b0)
                self.assertEqual(sum(events)%2,b0^states[-1])
    def test_invalid_latch_inputs(self):
        for args in [(2,0,.1),(True,0,.1),(0,math.nan,.1),(0,0,0),(0,0,-1),(0,0,math.inf)]:
            with self.assertRaises(ValueError):latch_update(*args)
    def test_certified_margin(self):
        r=certified_latch_trace([-.3,-.04,.31,.03],[-.295,-.035,.315,.035],.1,.006)
        self.assertTrue(r['certified']);self.assertTrue(r['identical_events'])
    def test_boundary_margin_is_inconclusive(self):
        r=certified_latch_trace([-.1],[-.1],.1,0)
        self.assertFalse(r['certified']);self.assertTrue(r['identical_states'])
    def test_error_violation_not_certified(self):
        self.assertFalse(certified_latch_trace([-.3],[.3],.1,.01)['certified'])
    def test_continuous_dwell_example(self):
        t=np.linspace(0,20,2001);values=.2*np.sin(t)
        _,ev=replay_latch(values,.1,0);times=t[np.array(ev,dtype=bool)]
        self.assertTrue(np.all(np.diff(times)>=2*.1/.2))
    def test_hinge_spec_rejects_invalid(self):
        for kwargs in [dict(threshold=0),dict(initial_bits=(0,1,2)),dict(feedback=1),dict(gate_probe=3),
                       dict(leakage=-.1),dict(probe_amplitude=math.inf)]:
            with self.assertRaises(ValueError):HingeSpec(**kwargs)

class QuotientTests(unittest.TestCase):
    def setUp(self):
        self.machine=FiniteMachine(((1,2),(0,3),(3,0),(2,1)),(0,0,1,1));self.p=(0,0,1,1)
    def test_valid_reduction(self):
        r=analyse_quotient(self.machine,self.p);self.assertTrue(r['valid']);self.assertEqual(r['transitions'],[[0,1],[1,0]])
    def test_all_short_trace_examples(self):self.assertEqual(examples()['finite_example_traces_checked'],508)
    def test_transition_witness(self):
        r=examples()['incompatible'];self.assertFalse(r['valid']);self.assertEqual(r['witness']['kind'],'transition')
    def test_output_witness(self):
        m=FiniteMachine(self.machine.transitions,(0,2,1,1));r=analyse_quotient(m,self.p)
        self.assertEqual(r['witness']['kind'],'output')
    def test_identity_partition(self):self.assertTrue(analyse_quotient(self.machine,(0,1,2,3))['valid'])
    def test_constant_quotient(self):
        m=FiniteMachine(self.machine.transitions,(7,7,7,7));r=analyse_quotient(m,(0,0,0,0))
        self.assertTrue(r['valid']);self.assertEqual(r['transitions'],[[0,0]])
    def test_reject_invalid_partition(self):
        for p in [(0,0),(1,1,2,2),(0,-1,1,1),(0,True,1,1)]:
            with self.assertRaises(ValueError):analyse_quotient(self.machine,p)
    def test_reject_nontotal_machine(self):
        for t,o in [((),()),(((0,),()),(0,1)),(((2,),),(0,)),(((False,),),(0,))]:
            with self.assertRaises(ValueError):FiniteMachine(t,o)
    def test_invalid_quotient_construction(self):
        with self.assertRaises(ValueError):quotient_machine(self.machine,(0,0,0,0))
    def test_state_bit_bound(self):
        self.assertEqual([minimum_state_bits(x) for x in range(1,10)],[0,1,2,2,3,3,3,3,4])
    def test_continuous_counterexample(self):
        x,y=-2,-.5;f=lambda t:t+.75;b=lambda t:int(t<=0)
        self.assertEqual(b(x),b(y));self.assertNotEqual(b(f(x)),b(f(y)))

class EditingTests(unittest.TestCase):
    def test_valid_branch_deletion(self):
        w='X[+X]Y';e=edit_word(w,1,5,'');self.assertEqual(e,'XY');self.assertEqual(len(turtle(e)),2)
    def test_unknown_and_unbalanced_edits_rejected(self):
        for a,b,r in [(1,2,''),(0,1,'Q'),(0,6,'')]:
            with self.assertRaises(ValueError):edit_word('X[+X]Y',a,b,r)
    def test_translated_field_bound(self):
        s=turtle('X[+X]Y');shift=np.array([.013,-.024]);new=translate_segments(s,shift)
        rng=np.random.default_rng(730);p=rng.normal(size=(500,2))
        self.assertLessEqual(float(np.max(abs(capsule_field(p,s,.03)-capsule_field(p,new,.03)))),float(np.linalg.norm(shift))+1e-12)
    def test_local_edit_does_not_collapse_composite(self):
        before=turtle('X[+X]Y');after=turtle(edit_word('X[+X]Y',1,5,''));p=np.array([[0,0],[0,.1],[1,1]])
        f=np.minimum(m_field(p),capsule_field(p,after,.02))
        self.assertTrue(np.all(np.isfinite(f)));self.assertLess(len(after),len(before))
    def test_reflection_closed_edit_set(self):
        points=reflection_closure([[.1,.3],[.2,.4]])
        self.assertEqual(set(map(tuple,points)),set(map(tuple,points*np.array([-1,1]))))
    def test_union_does_not_fill_gap(self):
        # Disk and stem are disjoint; union is evaluated by min, not a bridge.
        p=np.array([[0,.5]]);dot=np.linalg.norm(p-np.array([0,1]),axis=1)-.1
        stem=capsule_field(p,np.array([[[0,0],[0,.2]]]),.05)
        self.assertGreater(float(np.minimum(dot,stem)[0]),0)

class GambitIntegrationTests(unittest.TestCase):
    def test_default_seed_files(self):
        for p in ['xx','xy']:self.assertEqual(GambitSpec.load(ROOT/f'config/seed_{p}.json').model.pair,p.upper())
    def test_roundtrip(self):
        s=GambitSpec()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';s.save(p);self.assertEqual(GambitSpec.load(p),s)
    def test_duplicate_fields_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';p.write_text('{"schema":1,"schema":2}')
            with self.assertRaises(ValueError):GambitSpec.load(p)
    def test_unknown_field_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';GambitSpec().save(p);x=json.loads(p.read_text());x['unexpected']=1;p.write_text(json.dumps(x))
            with self.assertRaises(ValueError):GambitSpec.load(p)
    def test_metadata_and_interpretation_noninterference(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'s.json';GambitSpec(ModelSpec(steps=3)).save(p);a=GambitSpec.load(p)
            x=json.loads(p.read_text());x['author']={'name':'another label'};x['interpretation']='different meaning';p.write_text(json.dumps(x));b=GambitSpec.load(p)
            self.assertEqual(GambitKernel(a).fingerprint(),GambitKernel(b).fingerprint())
            self.assertEqual(GambitKernel(a).run()[1],GambitKernel(b).run()[1])
    def test_numerical_change_affects_fingerprint(self):
        a=GambitKernel(GambitSpec());b=GambitKernel(GambitSpec(hinge=HingeSpec(threshold=.02)))
        self.assertNotEqual(a.fingerprint(),b.fingerprint())
    def test_same_environment_replay(self):
        s=GambitSpec(ModelSpec(steps=10));a=GambitKernel(s);b=GambitKernel(s)
        aa,ha=a.run();bb,hb=b.run();self.assertEqual(ha,hb);np.testing.assert_array_equal(aa.u,bb.u)
    def test_full_invariant_run(self):
        k=GambitKernel(GambitSpec());s0=k.initial_state();s,h=k.run();m0=float(sum(s0.u+s0.v))
        self.assertTrue(all(x['codec_certificate'] and x['frame_even'] for x in h))
        self.assertLess(max(abs(x['mass']-m0) for x in h),1e-12)
        self.assertTrue(all(x['min_mass']>=0 and x['z_max']<=1 and x['memory_max']<=1 for x in h))
        self.assertTrue(all(all(b in [0,1] for b in x['latches']) for x in h))
    def test_one_step_causal_gate(self):
        k=GambitKernel(GambitSpec(ModelSpec(steps=2)));s=k.initial_state();n,r=k.advance(s)
        self.assertEqual(r['gate_multiplier'],.2)
        _,r2=k.advance(n);self.assertEqual(r2['gate_multiplier'],.2+.8*n.latches[0])
    def test_feedback_disabled(self):
        k=GambitKernel(GambitSpec(ModelSpec(steps=2),HingeSpec(feedback=False)))
        _,h=k.run();self.assertTrue(all(x['gate_multiplier']==1 for x in h))
    def test_input_state_not_mutated(self):
        k=GambitKernel(GambitSpec(ModelSpec(steps=2)));s=k.initial_state();old=s.copy();k.advance(s)
        np.testing.assert_array_equal(s.u,old.u);self.assertEqual(s.latches,old.latches);self.assertEqual(s.accumulator,old.accumulator)
    def test_gate_multiplier_validation(self):
        k=UnifiedKernel(ModelSpec(steps=2));s=k.initial_state()
        for g in [-1,1.1,math.nan]:
            with self.assertRaises(ValueError):k.advance(s,g)
    def test_payload_has_five_bits_and_separate_parity(self):
        _,rows=GambitKernel(GambitSpec(ModelSpec(steps=3))).run()
        self.assertTrue(all(len(r['payload'])==5 and r['parity'] in (0,1) for r in rows))

if __name__=='__main__':unittest.main()
