; K36: Separated thresholds set and reset the latch
; Manuscript: L14. Prove by unsatisfiability of its negation.
(set-option :produce-proofs true)
(set-option :timeout 10000)
(set-logic ALL)
(declare-const b Bool)
(declare-const x Real)
(declare-const d Real)
(define-fun lat ((v Real) (old Bool)) Bool (ite (<= v (- d)) true (ite (>= v d) false old)))
(assert (not (=> (> d 0) (and (lat (- d) b) (not (lat d b))))))
(check-sat)
(get-proof)
