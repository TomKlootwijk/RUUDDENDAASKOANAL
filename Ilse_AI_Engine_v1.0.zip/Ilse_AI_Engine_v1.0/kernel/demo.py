"""Reproduce figures and numerical demonstrations. No human data are included."""
from pathlib import Path
import csv
import json
import math
import platform
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from .core import *
from .spatial import CapsuleBVH
ROOT=Path(__file__).resolve().parents[1]

def savefig(fig,name):
    fig.tight_layout()
    for suffix in ['pdf','png','svg']:
        target=ROOT/'manuscript'/'figures'/f'{name}.{suffix}'
        fig.savefig(target,dpi=160,bbox_inches='tight',metadata={'Creator':'Ilse AI Engine'} if suffix in ['pdf','png','svg'] else None)
    plt.close(fig)

def csv_save(name,header,rows):
    with (ROOT/'results'/name).open('w',newline='') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)

def main():
    (ROOT/'results').mkdir(exist_ok=True);(ROOT/'manuscript'/'figures').mkdir(parents=True,exist_ok=True)
    seed=Seed.load(ROOT/'config'/'seed_xy.json');engine=IlseKernel(seed)
    counts=[]
    for text in ['XX','XY']:
        p=Pair.parse(text);word=grow(p,seed.generations);segs=turtle(word)
        (ROOT/'results'/f'word_{text.lower()}.txt').write_text(word+'\n')
        csv_save(f'segments_{text.lower()}.csv',['ax','ay','bx','by'],segs.reshape(-1,4))
        for n in range(7):
            w=grow(p,n);counts.append([text,n,w.count('X'),w.count('Y'),len(w)])
        fig,ax=plt.subplots(figsize=(6.3,4.2))
        ax.add_collection(LineCollection(segs,linewidths=1.2));ax.autoscale();ax.set_aspect('equal')
        ax.set_title(f'{text} seed: {len(segs)} interpreted growth strokes')
        ax.set_xlabel('x (simulation units)');ax.set_ylabel('y (simulation units)')
        savefig(fig,f'growth_{text.lower()}')
    csv_save('growth_counts.csv',['pair','generation','X','Y','total_tokens'],counts)
    x,y=np.meshgrid(np.linspace(-2.3,2.3,421),np.linspace(-.22,1.32,161));p=np.stack([x,y],-1)
    phi=m_field(p)
    fig,ax=plt.subplots(figsize=(8.0,3.4))
    ax.contour(x,y,phi,levels=[-.04,0,.08,.16],linewidths=[.7,1.6,.7,.7])
    ax.set_aspect('equal');ax.set_xlabel('x (simulation units)');ax.set_ylabel('y (simulation units)')
    ax.set_title('Double arcs + bounded baseline, clipped to y >= 0')
    savefig(fig,'double_arc_field')
    fig,ax=plt.subplots(figsize=(7.5,3.8))
    gridx,gridy=np.meshgrid(np.linspace(-.30,.30,221),np.linspace(.0,.92,231));pt=np.stack([gridx,gridy],-1)
    combined=np.maximum(np.minimum(m_field(pt),capsule_field(pt,engine.embedded_segments,.018)),-gridy)
    ax.contour(gridx,gridy,combined,levels=[0],linewidths=1.2)
    ax.set_aspect('equal');ax.set_title('XY growth capsules enter the central field')
    ax.set_xlabel('x (simulation units)');ax.set_ylabel('y (simulation units)')
    savefig(fig,'kernel_field')
    # Shared environment sequence; two initial conditions, identical seed and update laws.
    state=State(np.array([.9,-.7,.5]),np.array([-.6,.4,-.2]))
    other=engine.initial_state();initial=max(np.max(np.abs(state.z)),np.max(np.abs(state.memory)))
    q=engine.contraction_bound();trajectory=[]
    for t in range(181):
        sep=max(np.max(np.abs(state.z-other.z)),np.max(np.abs(state.memory-other.memory)))
        trajectory.append([t,*state.z,*state.memory,sep,initial*q**t])
        pts=np.array([[.095+.015*math.sin(.07*t),.6772],[-.10,.50+.1*math.cos(.05*t)],[1.0,1.04+.04*math.sin(.03*t)]])
        state,out=engine.advance(state,pts);other,_=engine.advance(other,pts)
    trajectory=np.array(trajectory)
    csv_save('state_trajectory.csv',['step','z0','z1','z2','m0','m1','m2','separation_inf','bound'],trajectory)
    fig,ax=plt.subplots(figsize=(7.2,3.7))
    ax.semilogy(trajectory[:,0],trajectory[:,7],label='Computed state separation')
    ax.semilogy(trajectory[:,0],trajectory[:,8],linestyle='--',label='Theorem bound: initial * q^t')
    ax.set_xlabel('Update step (not biological time)');ax.set_ylabel('Infinity-norm separation');ax.set_title(f'Closed-loop contraction; q = {q:.5f}');ax.legend(fontsize=9)
    savefig(fig,'contraction')
    fig,ax=plt.subplots(figsize=(7.2,3.7))
    ax.plot(trajectory[:,0],trajectory[:,1],label='Fast state z[0]')
    ax.plot(trajectory[:,0],trajectory[:,4],label='Slow state m[0]')
    ax.set_xlabel('Update step');ax.set_ylabel('Dimensionless model state');ax.set_title('Fast activity and a slower memory coordinate');ax.legend()
    savefig(fig,'state_memory')
    # Independent threshold coding, not XOR noise on pre-existing bits.
    rng=np.random.Generator(np.random.PCG64(seed.random_seed+1));quant=[]
    for u in np.linspace(0,1,11):
        bits=bernoulli_encode(np.full(25000,u),rng);quant.append([u,float(bits.mean()),25000])
    csv_save('quantization.csv',['coverage','sample_mean','samples'],quant)
    fig,ax=plt.subplots(figsize=(6.2,3.8))
    arr=np.asarray(quant);ax.plot(arr[:,0],arr[:,1],marker='o',label='Empirical bit density')
    ax.plot([0,1],[0,1],linestyle='--',label='Expected density')
    ax.set_xlabel('Input coverage u');ax.set_ylabel('Output fraction of 1 bits');ax.set_title('Seeded threshold quantization');ax.legend()
    savefig(fig,'quantization')
    # LUT approximation bound is evaluated on the declared annulus.
    lut=LogPolarLUT.build(m_field);test_rng=np.random.default_rng(91)
    chart=test_rng.uniform([math.log(.05),-math.pi],[math.log(4),math.pi],(1000,2));pts=inverse_log_polar(chart)
    approx,error_bound=lut.query(pts);exact=m_field(pts);error=np.abs(approx-exact)
    csv_save('lut_queries.csv',['x','y','exact_field','interpolated_field','absolute_error','certificate'],np.column_stack([pts,exact,approx,error,error_bound]))
    np.savez_compressed(ROOT/'results'/'log_polar_lut.npz',values=lut.values,rho_min=lut.rho_min,rho_max=lut.rho_max,reference=lut.reference)
    # BVH is checked against exhaustive capsule evaluation, not benchmarked for latency.
    bvh=CapsuleBVH(engine.segments);bv=[]
    for p in test_rng.uniform([-.5,-.2],[.5,1.6],(100,2)):
        value,count=bvh.query(p);ex=float(capsule_field(p,engine.segments));bv.append([*p,value,ex,count])
    csv_save('bvh_queries.csv',['x','y','bvh_field','exhaustive_field','primitive_evaluations'],bv)
    root=bisect_root(lambda t:t*t-2,1,2)
    metrics={'version':VERSION,'synthetic_only':True,'python':sys.version.split()[0],'numpy':np.__version__,'matplotlib':matplotlib.__version__,'platform':platform.system(),
             'configuration_digest':engine.configuration_digest(),'growth_generation':seed.generations,'growth_strokes_per_pair':len(engine.segments),'word_length_per_pair':len(engine.word),
             'contraction_q':q,'initial_state_separation':initial,'final_state_separation':float(trajectory[-1,7]),'final_contraction_bound':float(trajectory[-1,8]),
             'lut_max_abs_error':float(error.max()),'lut_max_certificate':float(error_bound.max()),'lut_certificate_violations':int(np.sum(error>error_bound+1e-12)),
             'bvh_max_abs_difference':float(np.max(np.abs(np.array(bv)[:,2]-np.array(bv)[:,3]))),'bvh_median_leaf_evaluations':float(np.median(np.array(bv)[:,4])),
             'quantization_max_mean_error':float(np.max(np.abs(arr[:,1]-arr[:,0]))),'root':root.__dict__,
             'fold_counterexample':{'R':1,'h':.5,'thickness':.1,'point':[.5,0],'explicit_union':float(paired_arcs([.5,0],spacing=.5,thickness=.1)),'folded':float(paired_arcs([.5,0],spacing=.5,thickness=.1,folded=True))}}
    (ROOT/'results'/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    print(json.dumps(metrics,indent=2))
if __name__=='__main__':main()
